Profile:        CIBMTRVitalSignsVariables
Parent:         us-core-vital-signs 
Id:             cibmtr-vital-signs
Title:          "CIBMTR Vital Signs Results Profile (us-core)"
Description:    "Place Holder for CIBMTR Vital Signs Results Profile (us-core)"
* insert MetaSecurityRules
* effective[x] 1..1
* value[x] only Quantity or CodeableConcept
* code.coding from VitalSigns (extensible)


// --------------------------------------------------------------------------

Profile:    CIBMTRVitalSignsHeight
Parent:     us-core-body-height 
Id:         cibmtr-vital-signs-height
Title:      "CIBMTR Vital Signs-Height Profile"
Description:    "Place Holder for Vital Signs-Height Profile"
* insert MetaSecurityRules



// --------------------------------------------------------------------------

Profile:    CIBMTRVitalSignsWeight
Parent:     us-core-body-weight 
Id:         cibmtr-vital-signs-weight
Title:      "CIBMTR Vital Signs-Weight Profile"
Description:    "Place Holder for Vital Signs-Weight Profile"
* insert MetaSecurityRules



