# CBC W Auto Differential panel - Blood (57021-8) - CIBMTR Reporting Implementation Guide v0.1.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CBC W Auto Differential panel - Blood (57021-8)**

## ValueSet: CBC W Auto Differential panel - Blood (57021-8) (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/cbc-w-auto-differential-blood-vs | *Version*:0.1.10 |
| Draft as of 2026-04-23 | *Computable Name*:CBCWAutoDifferentialBloodVS |

 
CBC W Auto Differential panel - Blood (57021-8) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "cbc-w-auto-differential-blood-vs",
  "url" : "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/cbc-w-auto-differential-blood-vs",
  "version" : "0.1.10",
  "name" : "CBCWAutoDifferentialBloodVS",
  "title" : "CBC W Auto Differential panel - Blood (57021-8)",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-04-23T10:10:52-05:00",
  "publisher" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
  "contact" : [
    {
      "name" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://www.cibmtr.org"
        }
      ]
    },
    {
      "name" : "Bob Milius",
      "telecom" : [
        {
          "system" : "email",
          "value" : "bmilius@nmdp.org"
        }
      ]
    }
  ],
  "description" : "CBC W Auto Differential panel - Blood (57021-8)",
  "compose" : {
    "include" : [
      {
        "valueSet" : [
          "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/cbc-blood-automated-vs"
        ]
      },
      {
        "valueSet" : [
          "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/auto-differential-blood-vs"
        ]
      }
    ]
  }
}

```
