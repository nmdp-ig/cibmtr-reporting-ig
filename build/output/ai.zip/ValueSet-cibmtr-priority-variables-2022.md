# CIBMTR Priority Variables Value Set (FY22) - CIBMTR Reporting Implementation Guide v0.1.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CIBMTR Priority Variables Value Set (FY22)**

## ValueSet: CIBMTR Priority Variables Value Set (FY22) 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/cibmtr-priority-variables-2022 | *Version*:0.1.11 |
| Draft as of 2026-06-22 | *Computable Name*:PriorityVariables2022 |

 
Priority Variables for CIBMTR (FY22) 

 **References** 

* [CIBMTR Observation Laboratory Results: Priority Variables](StructureDefinition-cibmtr-obs-priority-variables.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "cibmtr-priority-variables-2022",
  "url" : "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/cibmtr-priority-variables-2022",
  "version" : "0.1.11",
  "name" : "PriorityVariables2022",
  "title" : "CIBMTR Priority Variables Value Set (FY22)",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-06-22T08:51:47-05:00",
  "publisher" : "The Medical College of Wisconsin, Inc. and the NMDP",
  "contact" : [
    {
      "name" : "The Medical College of Wisconsin, Inc. and the NMDP",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://www.cibmtr.org"
        }
      ]
    },
    {
      "name" : "Bob Milius",
      "telecom" : [
        {
          "system" : "email",
          "value" : "bmilius@nmdp.org"
        }
      ]
    }
  ],
  "description" : "Priority Variables for CIBMTR (FY22)",
  "compose" : {
    "include" : [
      {
        "system" : "http://loinc.org",
        "concept" : [
          {
            "code" : "50190-8",
            "display" : "Iron and Iron binding capacity panel - Serum or Plasma"
          },
          {
            "code" : "14800-7",
            "display" : "Iron binding capacity [Moles/volume] in Serum or Plasma"
          },
          {
            "code" : "2500-7",
            "display" : "Iron binding capacity [Mass/volume] in Serum or Plasma"
          },
          {
            "code" : "22753-8",
            "display" : "Iron binding capacity.unsaturated [Moles/volume] in Serum or Plasma"
          },
          {
            "code" : "2501-5",
            "display" : "Iron binding capacity.unsaturated [Mass/volume] in Serum or Plasma"
          },
          {
            "code" : "14801-5",
            "display" : "Iron saturation [Molar fraction] in Serum or Plasma"
          },
          {
            "code" : "2502-3",
            "display" : "Iron saturation [Mass Fraction] in Serum or Plasma"
          },
          {
            "code" : "2498-4",
            "display" : "Iron [Mass/volume] in Serum or Plasma"
          },
          {
            "code" : "44326-7",
            "display" : "Iron [Presence] in Serum or Plasma"
          },
          {
            "code" : "14798-3",
            "display" : "Iron [Moles/volume] in Serum or Plasma"
          },
          {
            "code" : "34442-4",
            "display" : "Bilirubin.conjugated/Bilirubin.total in Serum or Plasma"
          },
          {
            "code" : "35672-5",
            "display" : "Bilirubin.direct/Bilirubin.total in Serum or Plasma"
          },
          {
            "code" : "14631-6",
            "display" : "Bilirubin.total [Moles/volume] in Serum or Plasma"
          },
          {
            "code" : "1975-2",
            "display" : "Bilirubin.total [Mass/volume] in Serum or Plasma"
          },
          {
            "code" : "77137-8",
            "display" : "Bilirubin.total [Moles/volume] in Serum, Plasma or Blood"
          },
          {
            "code" : "50189-0",
            "display" : "Neonatal bilirubin panel [Mass/volume] - Serum or Plasma"
          },
          {
            "code" : "78961-0",
            "display" : "IgG clearance/Albumin clearance [Ratio] in Urine and Serum or Plasma"
          },
          {
            "code" : "1754-1",
            "display" : "Albumin [Mass/volume] in Urine"
          },
          {
            "code" : "1753-3",
            "display" : "Albumin [Presence] in Urine"
          },
          {
            "code" : "50949-7",
            "display" : "Albumin [Presence] in Urine by Test strip"
          },
          {
            "code" : "6942-7",
            "display" : "Albumin [Mass/volume] in Urine by Electrophoresis"
          },
          {
            "code" : "77158-4",
            "display" : "Albumin [Moles/volume] in Urine by Detection limit <= 3.0 mg/L"
          },
          {
            "code" : "14957-5",
            "display" : "Microalbumin [Mass/volume] in Urine"
          },
          {
            "code" : "53531-0",
            "display" : "Microalbumin [Mass/volume] in Urine by Detection limit <= 1.0 mg/L"
          },
          {
            "code" : "11218-5",
            "display" : "Microalbumin [Mass/volume] in Urine by Test strip"
          },
          {
            "code" : "95232-5",
            "display" : "Microalbumin [Presence] in Urine by Test strip"
          },
          {
            "code" : "1755-8",
            "display" : "Albumin [Mass/time] in 24 hour Urine"
          },
          {
            "code" : "89999-7",
            "display" : "Albumin [Mass/volume] in Urine by Detection limit <= 3.0 mg/L"
          },
          {
            "code" : "9318-7",
            "display" : "Albumin/Creatinine [Mass Ratio] in Urine"
          },
          {
            "code" : "1916-6",
            "display" : "Aspartate aminotransferase/Alanine aminotransferase [Enzymatic activity ratio] in Serum or Plasma"
          },
          {
            "code" : "16325-3",
            "display" : "Alanine aminotransferase/Aspartate aminotransferase [Enzymatic activity ratio] in Serum or Plasma"
          },
          {
            "code" : "2325-9",
            "display" : "Gamma glutamyl transferase/Aspartate aminotransferase [Enzymatic activity ratio] in Serum or Plasma"
          },
          {
            "code" : "1920-8",
            "display" : "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "44786-2",
            "display" : "Aspartate aminotransferase [Enzymatic activity/volume] (Maximum value during study) in Serum or Plasma"
          },
          {
            "code" : "30239-8",
            "display" : "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma by With P-5'-P"
          },
          {
            "code" : "88112-8",
            "display" : "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma by No addition of P-5'-P"
          },
          {
            "code" : "48136-6",
            "display" : "Aspartate aminotransferase.macromolecular [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "54500-4",
            "display" : "Aspartate aminotransferase.macromolecular/Aspartate aminotransferase.total in Serum or Plasma"
          },
          {
            "code" : "76625-3",
            "display" : "Alanine aminotransferase [Enzymatic activity/volume] in Blood"
          },
          {
            "code" : "16324-6",
            "display" : "Alanine aminotransferase [Enzymatic activity/volume] in Red Blood Cells"
          },
          {
            "code" : "96586-3",
            "display" : "Alanine aminotransferase [Enzymatic activity/volume] in DBS"
          },
          {
            "code" : "77144-4",
            "display" : "Alanine aminotransferase [Enzymatic activity/volume] in Serum, Plasma or Blood"
          },
          {
            "code" : "48134-1",
            "display" : "Alanine aminotransferase.macromolecular [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "1742-6",
            "display" : "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "1743-4",
            "display" : "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma by With P-5'-P"
          },
          {
            "code" : "1744-2",
            "display" : "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma by No addition of P-5'-P"
          },
          {
            "code" : "44785-4",
            "display" : "Alanine aminotransferase [Enzymatic activity/volume] (Maximum value during study) in Serum or Plasma by No addition of P-5'-P"
          },
          {
            "code" : "14119-2",
            "display" : "Lactate dehydrogenase 1/Lactate dehydrogenase 2 [Enzymatic activity ratio] in Serum or Plasma"
          },
          {
            "code" : "2540-3",
            "display" : "Lactate dehydrogenase 2 [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "2549-4",
            "display" : "Lactate dehydrogenase 5 [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "2537-9",
            "display" : "Lactate dehydrogenase 1 [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "2543-7",
            "display" : "Lactate dehydrogenase 3 [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "2546-0",
            "display" : "Lactate dehydrogenase 4 [Enzymatic activity/volume] in Serum or Plasma"
          },
          {
            "code" : "14804-9",
            "display" : "Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma by Lactate to pyruvate reaction"
          },
          {
            "code" : "14805-6",
            "display" : "Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma by Pyruvate to lactate reaction"
          },
          {
            "code" : "2541-1",
            "display" : "Lactate dehydrogenase 3 [Enzymatic activity/volume] in Serum or Plasma by Chemical separation"
          },
          {
            "code" : "2544-5",
            "display" : "Lactate dehydrogenase 4 [Enzymatic activity/volume] in Serum or Plasma by Chemical separation"
          },
          {
            "code" : "2547-8",
            "display" : "Lactate dehydrogenase 5 [Enzymatic activity/volume] in Serum or Plasma by Chemical separation"
          },
          {
            "code" : "2535-3",
            "display" : "Lactate dehydrogenase 1 [Enzymatic activity/volume] in Serum or Plasma by Chemical separation"
          },
          {
            "code" : "2538-7",
            "display" : "Lactate dehydrogenase 2 [Enzymatic activity/volume] in Serum or Plasma by Chemical separation"
          },
          {
            "code" : "19248-4",
            "display" : "Lactate dehydrogenase 2 [Enzymatic activity/volume] in Serum or Plasma by Electrophoresis"
          },
          {
            "code" : "93905-8",
            "display" : "ABO group [Type] in Blood--during infancy"
          },
          {
            "code" : "883-9",
            "display" : "ABO group [Type] in Blood"
          },
          {
            "code" : "14580-5",
            "display" : "ABO group [Type] in Blood from Newborn"
          },
          {
            "code" : "882-1",
            "display" : "ABO and Rh group [Type] in Blood"
          },
          {
            "code" : "57743-7",
            "display" : "ABO group [Type] in Blood by Confirmatory method"
          },
          {
            "code" : "51892-8",
            "display" : "ABO group [Type] in Cord blood"
          },
          {
            "code" : "93906-6",
            "display" : "ABO and Rh group [Type] in Blood--during infancy"
          },
          {
            "code" : "44086-7",
            "display" : "ABO and Rh group [Interpretation] in Blood from Newborn"
          },
          {
            "code" : "77397-8",
            "display" : "ABO and Rh group [Type] in Blood by Confirmatory method"
          },
          {
            "code" : "19057-9",
            "display" : "ABO and Rh group [Type] in Blood from Newborn"
          },
          {
            "code" : "884-7",
            "display" : "ABO and Rh group [Type] in Capillary blood"
          },
          {
            "code" : "54417-1",
            "display" : "ABO and Rh group [Type] in Blood from Fetus"
          },
          {
            "code" : "34474-7",
            "display" : "ABO and Rh group [Type] in Cord blood"
          },
          {
            "code" : "1303-7",
            "display" : "Reverse ABO group [Type]"
          },
          {
            "code" : "54416-3",
            "display" : "Rh [Type] in Blood from Fetus"
          },
          {
            "code" : "14906-2",
            "display" : "Rh [Type] in Cord blood"
          },
          {
            "code" : "13225-8",
            "display" : "Cytomegalovirus IgG Ab [Units/volume] in Serum or Plasma --1st specimen"
          },
          {
            "code" : "16714-8",
            "display" : "Cytomegalovirus Ab [Units/volume] in Serum by Latex agglutination"
          },
          {
            "code" : "16715-5",
            "display" : "Cytomegalovirus IgG Ab [Units/volume] in Serum or Plasma by Immunofluorescence"
          },
          {
            "code" : "16716-3",
            "display" : "Cytomegalovirus IgG Ab [Units/volume] in Serum or Plasma by Immunoassay --2nd specimen"
          },
          {
            "code" : "22241-4",
            "display" : "Cytomegalovirus Ab [Titer] in Serum or Plasma"
          },
          {
            "code" : "22246-3",
            "display" : "Cytomegalovirus IgG Ab [Titer] in Serum or Plasma"
          },
          {
            "code" : "22247-1",
            "display" : "Cytomegalovirus IgG Ab [Units/volume] in Serum or Plasma --2nd specimen"
          },
          {
            "code" : "22249-7",
            "display" : "Cytomegalovirus IgM Ab [Titer] in Serum or Plasma"
          },
          {
            "code" : "29590-7",
            "display" : "Cytomegalovirus DNA [Mass/volume] (viral load) in Blood by Probe"
          },
          {
            "code" : "29604-6",
            "display" : "Cytomegalovirus DNA [#/volume] (viral load) in Blood by NAA with probe detection"
          },
          {
            "code" : "30247-1",
            "display" : "Cytomegalovirus DNA [#/volume] (viral load) in Serum or Plasma by NAA with probe detection"
          },
          {
            "code" : "32170-3",
            "display" : "Cytomegalovirus Ab [Titer] in Serum or Plasma by Immunofluorescence"
          },
          {
            "code" : "49349-4",
            "display" : "Cytomegalovirus DNA [#/volume] (viral load) in Bronchoalveolar lavage by NAA with probe detection"
          },
          {
            "code" : "5121-9",
            "display" : "Cytomegalovirus Ab [Titer] in Serum or Plasma by Latex agglutination"
          },
          {
            "code" : "5122-7",
            "display" : "Cytomegalovirus Ab [Units/volume] in Serum or Plasma by Immunofluorescence"
          },
          {
            "code" : "5124-3",
            "display" : "Cytomegalovirus IgG Ab [Units/volume] in Serum or Plasma by Immunoassay"
          },
          {
            "code" : "5125-0",
            "display" : "Cytomegalovirus IgG Ab [Titer] in Serum or Plasma by Immunofluorescence"
          },
          {
            "code" : "5126-8",
            "display" : "Cytomegalovirus IgM Ab [Units/volume] in Serum or Plasma by Immunoassay"
          },
          {
            "code" : "5127-6",
            "display" : "Cytomegalovirus IgM Ab [Titer] in Serum or Plasma by Immunofluorescence"
          },
          {
            "code" : "52976-8",
            "display" : "Cytomegalovirus Ab [Units/volume] in Serum by Complement fixation"
          },
          {
            "code" : "54206-8",
            "display" : "Cytomegalovirus DNA [Log #/volume] (viral load) in Serum or Plasma by NAA with probe detection"
          },
          {
            "code" : "72493-0",
            "display" : "Cytomegalovirus DNA [Units/volume] (viral load) in Plasma by NAA with probe detection"
          },
          {
            "code" : "72494-8",
            "display" : "Cytomegalovirus DNA [log units/volume] (viral load) in Plasma by NAA with probe detection"
          },
          {
            "code" : "7851-9",
            "display" : "Cytomegalovirus Ab [Units/volume] in Serum or Plasma"
          },
          {
            "code" : "7852-7",
            "display" : "Cytomegalovirus IgG Ab [Units/volume] in Serum or Plasma"
          },
          {
            "code" : "7853-5",
            "display" : "Cytomegalovirus IgM Ab [Units/volume] in Serum or Plasma"
          },
          {
            "code" : "88545-9",
            "display" : "Cytomegalovirus DNA [#/volume] (viral load) in DBS by NAA with probe detection"
          },
          {
            "code" : "9513-3",
            "display" : "Cytomegalovirus Ab [Titer] in Serum by Complement fixation"
          },
          {
            "code" : "32791-6",
            "display" : "Cytomegalovirus IgG Ab [Ratio] in Serum or Plasma by Immunoassay --1st specimen/2nd specimen"
          },
          {
            "code" : "32835-1",
            "display" : "Cytomegalovirus IgG Ab [Ratio] in Serum or Plasma --1st specimen/2nd specimen"
          },
          {
            "code" : "52984-2",
            "display" : "Cytomegalovirus IgG Ab avidity [Ratio] in Serum or Plasma by Immunoassay"
          },
          {
            "code" : "78445-4",
            "display" : "Cytomegalovirus IgG Ab avidity [Presence] in Serum or Plasma by Immunoassay"
          },
          {
            "code" : "67805-2",
            "display" : "Cytomegalovirus Ag [Presence] in Isolate by Immunofluorescence"
          },
          {
            "code" : "59838-3",
            "display" : "Cytomegalovirus Ab [Presence] in Serum or Plasma by Latex agglutination"
          },
          {
            "code" : "30325-5",
            "display" : "Cytomegalovirus IgM Ab [Presence] in Serum or Plasma"
          },
          {
            "code" : "13949-3",
            "display" : "Cytomegalovirus IgG Ab [Presence] in Serum or Plasma by Immunoassay"
          },
          {
            "code" : "22239-8",
            "display" : "Cytomegalovirus Ab [Presence] in Serum or Plasma"
          },
          {
            "code" : "24119-0",
            "display" : "Cytomegalovirus IgM Ab [Presence] in Serum or Plasma by Immunoassay"
          },
          {
            "code" : "6377-6",
            "display" : "Cytomegalovirus Ag [Presence] in Serum or Plasma by Immunofluorescence"
          },
          {
            "code" : "6376-8",
            "display" : "Cytomegalovirus Ag [Presence] in Serum or Plasma by Immunoassay"
          },
          {
            "code" : "5835-4",
            "display" : "Cytomegalovirus [Presence] in Blood by Organism specific culture"
          },
          {
            "code" : "54164-9",
            "display" : "Cytomegalovirus immediate-early Ag [Presence] in Blood"
          },
          {
            "code" : "4996-5",
            "display" : "Cytomegalovirus DNA [Presence] in Blood by NAA with probe detection"
          },
          {
            "code" : "49539-0",
            "display" : "Cytomegalovirus IgM Ab [Presence] in Serum or Plasma by Immunofluorescence"
          },
          {
            "code" : "43703-8",
            "display" : "Cytomegalovirus [Presence] in Blood by Shell vial culture"
          },
          {
            "code" : "31795-8",
            "display" : "Cytomegalovirus Ag [Presence] in Serum or Plasma"
          },
          {
            "code" : "30246-3",
            "display" : "Cytomegalovirus DNA [Presence] in Serum or Plasma by NAA with probe detection"
          },
          {
            "code" : "15377-5",
            "display" : "Cytomegalovirus Ab [Presence] in Serum by Latex agglutination"
          },
          {
            "code" : "16718-9",
            "display" : "Cytomegalovirus Ag [Presence] in Blood"
          },
          {
            "code" : "22244-8",
            "display" : "Cytomegalovirus IgG Ab [Presence] in Serum or Plasma"
          },
          {
            "code" : "28008-1",
            "display" : "Cytomegalovirus DNA [Presence] in Blood by Probe with signal amplification"
          },
          {
            "code" : "20475-0",
            "display" : "Cytomegalovirus IgG Ab [Interpretation] in Serum or Plasma"
          },
          {
            "code" : "87424-8",
            "display" : "Cytomegalovirus IgG and IgM panel - Serum or Plasma Qualitative"
          },
          {
            "code" : "88535-0",
            "display" : "Cytomegalovirus DNA [Presence] in DBS by NAA with probe detection"
          },
          {
            "code" : "95184-8",
            "display" : "Cytomegalovirus T-cell immunodeficiency panel - Blood by Flow cytometry (FC)"
          },
          {
            "code" : "78006-4",
            "display" : "Isotopic Glomerular filtration rate/1.73 sq M [Volume Rate/Area] in Urine and Serum or Plasma"
          },
          {
            "code" : "96591-3",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted among blacks [Volume Rate/Area] in DBS"
          },
          {
            "code" : "69405-9",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood"
          },
          {
            "code" : "96592-1",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted among non-blacks [Volume Rate/Area] in DBS"
          },
          {
            "code" : "50384-7",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (Schwartz)"
          },
          {
            "code" : "50210-4",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Cystatin-based formula"
          },
          {
            "code" : "62238-1",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (CKD-EPI)"
          },
          {
            "code" : "77147-7",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)"
          },
          {
            "code" : "88293-6",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted among blacks [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (CKD-EPI)"
          },
          {
            "code" : "48643-1",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted among blacks [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)"
          },
          {
            "code" : "50044-7",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted among females [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)"
          },
          {
            "code" : "70969-1",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted among males [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)"
          },
          {
            "code" : "88294-4",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted among non-blacks [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (CKD-EPI)"
          },
          {
            "code" : "48642-3",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted among non-blacks [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)"
          },
          {
            "code" : "87430-5",
            "display" : "Cystatin C and Glomerular filtration rate by Cystatin-based formula panel - Serum or Plasma"
          },
          {
            "code" : "45066-8",
            "display" : "Creatinine and Glomerular filtration rate.predicted panel - Serum, Plasma or Blood"
          },
          {
            "code" : "94677-2",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine and Cystatin C-based formula (CKD-EPI)"
          },
          {
            "code" : "98979-8",
            "display" : "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (CKD-EPI 2021)"
          },
          {
            "code" : "2164-2",
            "display" : "Creatinine renal clearance in 24 hour Urine and Serum or Plasma"
          },
          {
            "code" : "6690-2",
            "display" : "Leukocytes [#/volume] in Blood by Automated count"
          },
          {
            "code" : "804-5",
            "display" : "Leukocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "26464-8",
            "display" : "Leukocytes [#/volume] in Blood"
          },
          {
            "code" : "49498-9",
            "display" : "Leukocytes [#/volume] in Blood by Estimate"
          },
          {
            "code" : "789-8",
            "display" : "Erythrocytes [#/volume] in Blood by Automated count"
          },
          {
            "code" : "26453-1",
            "display" : "Erythrocytes [#/volume] in Blood"
          },
          {
            "code" : "790-6",
            "display" : "Erythrocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "93846-4",
            "display" : "Hemoglobin [Moles/volume] in Venous blood"
          },
          {
            "code" : "718-7",
            "display" : "Hemoglobin [Mass/volume] in Blood"
          },
          {
            "code" : "30313-1",
            "display" : "Hemoglobin [Mass/volume] in Arterial blood"
          },
          {
            "code" : "30350-3",
            "display" : "Hemoglobin [Mass/volume] in Venous blood"
          },
          {
            "code" : "14775-1",
            "display" : "Hemoglobin [Mass/volume] in Arterial blood by Oximetry"
          },
          {
            "code" : "30351-1",
            "display" : "Hemoglobin [Mass/volume] in Mixed venous blood"
          },
          {
            "code" : "20509-6",
            "display" : "Hemoglobin [Mass/volume] in Blood by calculation"
          },
          {
            "code" : "75928-2",
            "display" : "Hemoglobin [Moles/volume] in Arterial blood"
          },
          {
            "code" : "55782-7",
            "display" : "Hemoglobin [Mass/volume] in Blood by Oximetry"
          },
          {
            "code" : "59260-0",
            "display" : "Hemoglobin [Moles/volume] in Blood"
          },
          {
            "code" : "76768-1",
            "display" : "Hemoglobin [Mass/volume] in Mixed venous blood by Oximetry"
          },
          {
            "code" : "76769-9",
            "display" : "Hemoglobin [Mass/volume] in Venous blood by Oximetry"
          },
          {
            "code" : "4633-4",
            "display" : "Hemoglobin F/Hemoglobin.total in Blood by Kleihauer-Betke method"
          },
          {
            "code" : "4576-5",
            "display" : "Hemoglobin F/Hemoglobin.total in Blood"
          },
          {
            "code" : "42246-9",
            "display" : "Hemoglobin F/Hemoglobin.total in Blood by HPLC"
          },
          {
            "code" : "32682-7",
            "display" : "Hemoglobin F/Hemoglobin.total in Blood by Electrophoresis"
          },
          {
            "code" : "38524-5",
            "display" : "Hemoglobin F/Hemoglobin.total in Blood by Electrophoresis alkaline (pH 8.9)"
          },
          {
            "code" : "71863-5",
            "display" : "Hemoglobin F/Hemoglobin.total [Pure mass fraction] in Blood by Kleihauer-Betke method"
          },
          {
            "code" : "71864-3",
            "display" : "Hemoglobin F/Hemoglobin.total [Pure mass fraction] in Blood by HPLC"
          },
          {
            "code" : "71865-0",
            "display" : "Hemoglobin F/Hemoglobin.total [Pure mass fraction] in Blood by Electrophoresis"
          },
          {
            "code" : "20570-8",
            "display" : "Hematocrit [Volume Fraction] of Blood"
          },
          {
            "code" : "31100-1",
            "display" : "Hematocrit [Volume Fraction] of Blood by Impedance"
          },
          {
            "code" : "4545-0",
            "display" : "Hematocrit [Volume Fraction] of Blood by Centrifugation"
          },
          {
            "code" : "4544-3",
            "display" : "Hematocrit [Volume Fraction] of Blood by Automated count"
          },
          {
            "code" : "42908-4",
            "display" : "Hematocrit [Volume Fraction] of Capillary blood"
          },
          {
            "code" : "41654-5",
            "display" : "Hematocrit [Volume Fraction] of Venous blood"
          },
          {
            "code" : "48703-3",
            "display" : "Hematocrit [Volume Fraction] of Blood by Estimated"
          },
          {
            "code" : "71829-6",
            "display" : "Hematocrit [Pure volume fraction] of Venous blood"
          },
          {
            "code" : "71831-2",
            "display" : "Hematocrit [Pure volume fraction] of Capillary blood"
          },
          {
            "code" : "71833-8",
            "display" : "Hematocrit [Pure volume fraction] of Blood by Automated count"
          },
          {
            "code" : "26515-7",
            "display" : "Platelets [#/volume] in Blood"
          },
          {
            "code" : "778-1",
            "display" : "Platelets [#/volume] in Blood by Manual count"
          },
          {
            "code" : "777-3",
            "display" : "Platelets [#/volume] in Blood by Automated count"
          },
          {
            "code" : "49497-1",
            "display" : "Platelets [#/volume] in Blood by Estimate"
          },
          {
            "code" : "28542-9",
            "display" : "Platelet mean volume [Entitic volume] in Blood"
          },
          {
            "code" : "32623-1",
            "display" : "Platelet mean volume [Entitic volume] in Blood by Automated count"
          },
          {
            "code" : "732-8",
            "display" : "Lymphocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "731-0",
            "display" : "Lymphocytes [#/volume] in Blood by Automated count"
          },
          {
            "code" : "26474-7",
            "display" : "Lymphocytes [#/volume] in Blood"
          },
          {
            "code" : "26478-8",
            "display" : "Lymphocytes/100 leukocytes in Blood"
          },
          {
            "code" : "736-9",
            "display" : "Lymphocytes/100 leukocytes in Blood by Automated count"
          },
          {
            "code" : "737-7",
            "display" : "Lymphocytes/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "26484-6",
            "display" : "Monocytes [#/volume] in Blood"
          },
          {
            "code" : "742-7",
            "display" : "Monocytes [#/volume] in Blood by Automated count"
          },
          {
            "code" : "743-5",
            "display" : "Monocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "5905-5",
            "display" : "Monocytes/100 leukocytes in Blood by Automated count"
          },
          {
            "code" : "26485-3",
            "display" : "Monocytes/100 leukocytes in Blood"
          },
          {
            "code" : "744-3",
            "display" : "Monocytes/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "751-8",
            "display" : "Neutrophils [#/volume] in Blood by Automated count"
          },
          {
            "code" : "753-4",
            "display" : "Neutrophils [#/volume] in Blood by Manual count"
          },
          {
            "code" : "26499-4",
            "display" : "Neutrophils [#/volume] in Blood"
          },
          {
            "code" : "770-8",
            "display" : "Neutrophils/100 leukocytes in Blood by Automated count"
          },
          {
            "code" : "26511-6",
            "display" : "Neutrophils/100 leukocytes in Blood"
          },
          {
            "code" : "23761-0",
            "display" : "Neutrophils/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "26508-2",
            "display" : "Band form neutrophils/100 leukocytes in Blood"
          },
          {
            "code" : "764-1",
            "display" : "Band form neutrophils/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "35332-6",
            "display" : "Band form neutrophils/100 leukocytes in Blood by Automated count"
          },
          {
            "code" : "32200-8",
            "display" : "Segmented neutrophils/100 leukocytes in Blood by Automated count"
          },
          {
            "code" : "26505-8",
            "display" : "Segmented neutrophils/100 leukocytes in Blood"
          },
          {
            "code" : "769-0",
            "display" : "Segmented neutrophils/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "709-6",
            "display" : "Blasts/100 leukocytes in Blood"
          },
          {
            "code" : "26446-5",
            "display" : "Blasts/100 leukocytes in Blood"
          },
          {
            "code" : "707-0",
            "display" : "Basophils/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "706-2",
            "display" : "Basophils/100 leukocytes in Blood by Automated count"
          },
          {
            "code" : "30180-4",
            "display" : "Basophils/100 leukocytes in Blood"
          },
          {
            "code" : "712-0",
            "display" : "Eosinophils [#/volume] in Blood by Manual count"
          },
          {
            "code" : "26449-9",
            "display" : "Eosinophils [#/volume] in Blood"
          },
          {
            "code" : "711-2",
            "display" : "Eosinophils [#/volume] in Blood by Automated count"
          },
          {
            "code" : "26450-7",
            "display" : "Eosinophils/100 leukocytes in Blood"
          },
          {
            "code" : "713-8",
            "display" : "Eosinophils/100 leukocytes in Blood by Automated count"
          },
          {
            "code" : "714-6",
            "display" : "Eosinophils/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "30458-4",
            "display" : "Plasma cells [#/volume] in Blood"
          },
          {
            "code" : "24103-4",
            "display" : "Plasma cells [#/volume] in Blood by Manual count"
          },
          {
            "code" : "13047-6",
            "display" : "Plasma cells/100 leukocytes in Blood"
          },
          {
            "code" : "79426-3",
            "display" : "Plasma cells/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "33855-8",
            "display" : "Promonocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "34926-6",
            "display" : "Promonocytes [#/volume] in Blood"
          },
          {
            "code" : "13599-6",
            "display" : "Promonocytes/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "30466-7",
            "display" : "Promonocytes/100 leukocytes in Blood"
          },
          {
            "code" : "26523-1",
            "display" : "Promyelocytes [#/volume] in Blood"
          },
          {
            "code" : "781-5",
            "display" : "Promyelocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "783-1",
            "display" : "Promyelocytes/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "71666-2",
            "display" : "Promyelocytes/Leukocytes [Pure number fraction] in Blood by Manual count"
          },
          {
            "code" : "26524-9",
            "display" : "Promyelocytes/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "30444-4",
            "display" : "Myeloblasts [#/volume] in Blood"
          },
          {
            "code" : "746-8",
            "display" : "Myeloblasts [#/volume] in Blood by Manual count"
          },
          {
            "code" : "30445-1",
            "display" : "Myeloblasts/100 leukocytes in Blood"
          },
          {
            "code" : "747-6",
            "display" : "Myeloblasts/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "748-4",
            "display" : "Myelocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "30446-9",
            "display" : "Myelocytes [#/volume] in Blood"
          },
          {
            "code" : "26498-6",
            "display" : "Myelocytes/100 leukocytes in Blood"
          },
          {
            "code" : "749-2",
            "display" : "Myelocytes/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "71667-0",
            "display" : "Myelocytes/Leukocytes [Pure number fraction] in Blood by Manual count"
          },
          {
            "code" : "739-3",
            "display" : "Metamyelocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "30433-7",
            "display" : "Metamyelocytes [#/volume] in Blood"
          },
          {
            "code" : "740-1",
            "display" : "Metamyelocytes/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "28541-1",
            "display" : "Metamyelocytes/100 leukocytes in Blood"
          },
          {
            "code" : "71668-8",
            "display" : "Metamyelocytes/Leukocytes [Pure number fraction] in Blood by Manual count"
          },
          {
            "code" : "6746-2",
            "display" : "Prolymphocytes/100 leukocytes in Blood by Manual count"
          },
          {
            "code" : "30465-9",
            "display" : "Prolymphocytes/100 leukocytes in Blood"
          },
          {
            "code" : "14196-0",
            "display" : "Reticulocytes [#/volume] in Blood"
          },
          {
            "code" : "40665-2",
            "display" : "Reticulocytes [#/volume] in Blood by Manual count"
          },
          {
            "code" : "60474-4",
            "display" : "Reticulocytes [#/volume] in Blood by Automated count"
          },
          {
            "code" : "31112-6",
            "display" : "Reticulocytes/100 erythrocytes in Blood by Manual"
          },
          {
            "code" : "17849-1",
            "display" : "Reticulocytes/100 erythrocytes in Blood by Automated count"
          },
          {
            "code" : "4679-7",
            "display" : "Reticulocytes/100 erythrocytes in Blood"
          },
          {
            "code" : "1751-7",
            "display" : "Albumin [Mass/volume] in Serum or Plasma"
          },
          {
            "code" : "2862-1",
            "display" : "Albumin [Mass/volume] in Serum or Plasma by Electrophoresis"
          },
          {
            "code" : "61151-7",
            "display" : "Albumin [Mass/volume] in Serum or Plasma by Bromocresol green (BCG) dye binding method"
          },
          {
            "code" : "61152-5",
            "display" : "Albumin [Mass/volume] in Serum or Plasma by Bromocresol purple (BCP) dye binding method"
          },
          {
            "code" : "1952-1",
            "display" : "Beta-2-Microglobulin [Mass/volume] in Serum or Plasma"
          },
          {
            "code" : "76484-5",
            "display" : "Beta-2-Microglobulin [Moles/volume] in Serum or Plasma"
          },
          {
            "code" : "2276-4",
            "display" : "Ferritin [Mass/volume] in Serum or Plasma"
          },
          {
            "code" : "24373-3",
            "display" : "Ferritin [Mass/volume] in Blood"
          },
          {
            "code" : "20567-4",
            "display" : "Ferritin [Mass/volume] in Serum or Plasma by Immunoassay"
          },
          {
            "code" : "11150-0",
            "display" : "Blasts/100 cells in Bone marrow"
          },
          {
            "code" : "57028-3",
            "display" : "Iron [Mass/mass] in Liver"
          },
          {
            "code" : "2160-0",
            "display" : "Creatinine [Mass/volume] in Serum or Plasma"
          },
          {
            "code" : "14682-9",
            "display" : "Creatinine [Moles/volume] in Serum or Plasma"
          },
          {
            "code" : "77140-2",
            "display" : "Creatinine [Moles/volume] in Serum, Plasma or Blood"
          }
        ]
      }
    ]
  }
}

```
