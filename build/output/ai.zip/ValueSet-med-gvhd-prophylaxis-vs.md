# RxNorm - GVHD Prophylaxis - CIBMTR Reporting Implementation Guide v0.1.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RxNorm - GVHD Prophylaxis**

## ValueSet: RxNorm - GVHD Prophylaxis (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/med-gvhd-prophylaxis-vs | *Version*:0.1.11 |
| Draft as of 2026-06-21 | *Computable Name*:RxNormGVHDProphylaxisVS |

 
RxNorm codes for GVHD Prophylaxis 

 **References** 

* Included into [RxNormAll2400VS](ValueSet-med-all-form2400-vs.md)
* [CIBMTR GVHD Prophylaxis Medication](StructureDefinition-cibmtr-gvhd-prophylaxis-medication.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "med-gvhd-prophylaxis-vs",
  "url" : "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/med-gvhd-prophylaxis-vs",
  "version" : "0.1.11",
  "name" : "RxNormGVHDProphylaxisVS",
  "title" : "RxNorm - GVHD Prophylaxis",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-06-21T22:38:39-05:00",
  "publisher" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
  "contact" : [
    {
      "name" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://www.cibmtr.org"
        }
      ]
    },
    {
      "name" : "Bob Milius",
      "telecom" : [
        {
          "system" : "email",
          "value" : "bmilius@nmdp.org"
        }
      ]
    }
  ],
  "description" : "RxNorm codes for GVHD Prophylaxis",
  "compose" : {
    "include" : [
      {
        "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
        "concept" : [
          {
            "code" : "105585",
            "display" : "methotrexate 2.5 MG Oral Tablet"
          },
          {
            "code" : "105586",
            "display" : "methotrexate 10 MG Oral Tablet"
          },
          {
            "code" : "105589",
            "display" : "methotrexate 100 MG/ML Injectable Solution"
          },
          {
            "code" : "108513",
            "display" : "tacrolimus 1 MG Oral Capsule [Prograf]"
          },
          {
            "code" : "108514",
            "display" : "tacrolimus 5 MG Oral Capsule [Prograf]"
          },
          {
            "code" : "108515",
            "display" : "1 ML tacrolimus 5 MG/ML Injection [Prograf]"
          },
          {
            "code" : "1093172",
            "display" : "cyclosporine 0.002 MG/MG"
          },
          {
            "code" : "1093173",
            "display" : "cyclosporine Ophthalmic Ointment"
          },
          {
            "code" : "1093174",
            "display" : "cyclosporine 0.002 MG/MG Ophthalmic Ointment"
          },
          {
            "code" : "1093175",
            "display" : "Optimmune"
          },
          {
            "code" : "1093176",
            "display" : "cyclosporine 0.002 MG/MG [Optimmune]"
          },
          {
            "code" : "1093177",
            "display" : "cyclosporine Ophthalmic Ointment [Optimmune]"
          },
          {
            "code" : "1093178",
            "display" : "cyclosporine 0.002 MG/MG Ophthalmic Ointment [Optimmune]"
          },
          {
            "code" : "1145927",
            "display" : "abatacept 125 MG/ML"
          },
          {
            "code" : "1145928",
            "display" : "abatacept Prefilled Syringe"
          },
          {
            "code" : "1145929",
            "display" : "1 ML abatacept 125 MG/ML Prefilled Syringe"
          },
          {
            "code" : "1145930",
            "display" : "abatacept 125 MG/ML [Orencia]"
          },
          {
            "code" : "1145931",
            "display" : "abatacept Prefilled Syringe [Orencia]"
          },
          {
            "code" : "1145932",
            "display" : "1 ML abatacept 125 MG/ML Prefilled Syringe [Orencia]"
          },
          {
            "code" : "1151834",
            "display" : "daclizumab Injectable Product"
          },
          {
            "code" : "1156181",
            "display" : "cyclophosphamide Injectable Product"
          },
          {
            "code" : "1156182",
            "display" : "cyclophosphamide Oral Product"
          },
          {
            "code" : "1156183",
            "display" : "cyclophosphamide Pill"
          },
          {
            "code" : "1156186",
            "display" : "cyclosporine Injectable Product"
          },
          {
            "code" : "1156187",
            "display" : "cyclosporine Ophthalmic Product"
          },
          {
            "code" : "1156188",
            "display" : "cyclosporine Oral Liquid Product"
          },
          {
            "code" : "1156189",
            "display" : "cyclosporine Oral Product"
          },
          {
            "code" : "1156190",
            "display" : "cyclosporine Pill"
          },
          {
            "code" : "1157869",
            "display" : "mycophenolate mofetil Injectable Product"
          },
          {
            "code" : "1157870",
            "display" : "mycophenolate mofetil Oral Liquid Product"
          },
          {
            "code" : "1157871",
            "display" : "mycophenolate mofetil Oral Product"
          },
          {
            "code" : "1157872",
            "display" : "mycophenolate mofetil Pill"
          },
          {
            "code" : "1158757",
            "display" : "sirolimus Oral Liquid Product"
          },
          {
            "code" : "1158758",
            "display" : "sirolimus Oral Product"
          },
          {
            "code" : "1158759",
            "display" : "sirolimus Pill"
          },
          {
            "code" : "1161488",
            "display" : "temsirolimus Injectable Product"
          },
          {
            "code" : "1162235",
            "display" : "methotrexate Injectable Product"
          },
          {
            "code" : "1162236",
            "display" : "methotrexate Oral Product"
          },
          {
            "code" : "1162237",
            "display" : "methotrexate Pill"
          },
          {
            "code" : "1162729",
            "display" : "tocilizumab Injectable Product"
          },
          {
            "code" : "1163066",
            "display" : "abatacept Injectable Product"
          },
          {
            "code" : "1163075",
            "display" : "bortezomib Injectable Product"
          },
          {
            "code" : "1163655",
            "display" : "tacrolimus Injectable Product"
          },
          {
            "code" : "1164202",
            "display" : "tacrolimus Oral Product"
          },
          {
            "code" : "1164203",
            "display" : "tacrolimus Pill"
          },
          {
            "code" : "1164204",
            "display" : "tacrolimus Topical Product"
          },
          {
            "code" : "1165075",
            "display" : "maraviroc Oral Product"
          },
          {
            "code" : "1165076",
            "display" : "maraviroc Pill"
          },
          {
            "code" : "1166213",
            "display" : "Cellcept Injectable Product"
          },
          {
            "code" : "1166214",
            "display" : "Cellcept Oral Liquid Product"
          },
          {
            "code" : "1166215",
            "display" : "Cellcept Oral Product"
          },
          {
            "code" : "1166216",
            "display" : "Cellcept Pill"
          },
          {
            "code" : "1169167",
            "display" : "Actemra Injectable Product"
          },
          {
            "code" : "1169824",
            "display" : "Gengraf Oral Liquid Product"
          },
          {
            "code" : "1169825",
            "display" : "Gengraf Oral Product"
          },
          {
            "code" : "1169826",
            "display" : "Gengraf Pill"
          },
          {
            "code" : "1172882",
            "display" : "Atopica Oral Product"
          },
          {
            "code" : "1172883",
            "display" : "Atopica Pill"
          },
          {
            "code" : "1177701",
            "display" : "Rapamune Oral Liquid Product"
          },
          {
            "code" : "1177702",
            "display" : "Rapamune Oral Product"
          },
          {
            "code" : "1177703",
            "display" : "Rapamune Pill"
          },
          {
            "code" : "1178366",
            "display" : "Selzentry Oral Product"
          },
          {
            "code" : "1178367",
            "display" : "Selzentry Pill"
          },
          {
            "code" : "1179677",
            "display" : "Trexall Oral Product"
          },
          {
            "code" : "1179678",
            "display" : "Trexall Pill"
          },
          {
            "code" : "1180662",
            "display" : "Prograf Injectable Product"
          },
          {
            "code" : "1180663",
            "display" : "Prograf Oral Product"
          },
          {
            "code" : "1180664",
            "display" : "Prograf Pill"
          },
          {
            "code" : "1181672",
            "display" : "Neoral Oral Liquid Product"
          },
          {
            "code" : "1181673",
            "display" : "Neoral Oral Product"
          },
          {
            "code" : "1181674",
            "display" : "Neoral Pill"
          },
          {
            "code" : "1182342",
            "display" : "Optimmune Ophthalmic Product"
          },
          {
            "code" : "1182458",
            "display" : "Protopic Topical Product"
          },
          {
            "code" : "1182527",
            "display" : "Restasis Ophthalmic Product"
          },
          {
            "code" : "1183963",
            "display" : "Orencia Injectable Product"
          },
          {
            "code" : "1185408",
            "display" : "Sandimmune Injectable Product"
          },
          {
            "code" : "1185409",
            "display" : "Sandimmune Oral Liquid Product"
          },
          {
            "code" : "1185410",
            "display" : "Sandimmune Oral Product"
          },
          {
            "code" : "1185411",
            "display" : "Sandimmune Pill"
          },
          {
            "code" : "1187756",
            "display" : "Velcade Injectable Product"
          },
          {
            "code" : "1193325",
            "display" : "ruxolitinib phosphate"
          },
          {
            "code" : "1193326",
            "display" : "ruxolitinib"
          },
          {
            "code" : "1193327",
            "display" : "ruxolitinib 10 MG"
          },
          {
            "code" : "1193328",
            "display" : "ruxolitinib Oral Product"
          },
          {
            "code" : "1193329",
            "display" : "ruxolitinib Pill"
          },
          {
            "code" : "1193330",
            "display" : "ruxolitinib Oral Tablet"
          },
          {
            "code" : "1193331",
            "display" : "ruxolitinib 10 MG Oral Tablet"
          },
          {
            "code" : "1193332",
            "display" : "Jakafi"
          },
          {
            "code" : "1193333",
            "display" : "ruxolitinib 10 MG [Jakafi]"
          },
          {
            "code" : "1193334",
            "display" : "ruxolitinib Oral Tablet [Jakafi]"
          },
          {
            "code" : "1193335",
            "display" : "Jakafi Oral Product"
          },
          {
            "code" : "1193336",
            "display" : "Jakafi Pill"
          },
          {
            "code" : "1193337",
            "display" : "ruxolitinib 10 MG Oral Tablet [Jakafi]"
          },
          {
            "code" : "1193338",
            "display" : "ruxolitinib 5 MG"
          },
          {
            "code" : "1193339",
            "display" : "ruxolitinib 5 MG Oral Tablet"
          },
          {
            "code" : "1193340",
            "display" : "ruxolitinib 5 MG [Jakafi]"
          },
          {
            "code" : "1193341",
            "display" : "ruxolitinib 5 MG Oral Tablet [Jakafi]"
          },
          {
            "code" : "1193342",
            "display" : "ruxolitinib 15 MG"
          },
          {
            "code" : "1193343",
            "display" : "ruxolitinib 15 MG Oral Tablet"
          },
          {
            "code" : "1193344",
            "display" : "ruxolitinib 15 MG [Jakafi]"
          },
          {
            "code" : "1193345",
            "display" : "ruxolitinib 15 MG Oral Tablet [Jakafi]"
          },
          {
            "code" : "1193346",
            "display" : "ruxolitinib 20 MG"
          },
          {
            "code" : "1193347",
            "display" : "ruxolitinib 20 MG Oral Tablet"
          },
          {
            "code" : "1193348",
            "display" : "ruxolitinib 20 MG [Jakafi]"
          },
          {
            "code" : "1193349",
            "display" : "ruxolitinib 20 MG Oral Tablet [Jakafi]"
          },
          {
            "code" : "1193350",
            "display" : "ruxolitinib 25 MG"
          },
          {
            "code" : "1193351",
            "display" : "ruxolitinib 25 MG Oral Tablet"
          },
          {
            "code" : "1193352",
            "display" : "ruxolitinib 25 MG [Jakafi]"
          },
          {
            "code" : "1193353",
            "display" : "ruxolitinib 25 MG Oral Tablet [Jakafi]"
          },
          {
            "code" : "1233905",
            "display" : "cyclosporine, modified 100 MG/ML [Atopica]"
          },
          {
            "code" : "1233906",
            "display" : "cyclosporine Oral Solution [Atopica]"
          },
          {
            "code" : "1233907",
            "display" : "Atopica Oral Liquid Product"
          },
          {
            "code" : "1233908",
            "display" : "cyclosporine, modified 100 MG/ML Oral Solution [Atopica]"
          },
          {
            "code" : "1431970",
            "display" : "tacrolimus Extended Release Oral Capsule"
          },
          {
            "code" : "1431971",
            "display" : "24 HR tacrolimus 0.5 MG Extended Release Oral Capsule"
          },
          {
            "code" : "1431972",
            "display" : "Astagraf"
          },
          {
            "code" : "1431973",
            "display" : "tacrolimus 0.5 MG [Astagraf]"
          },
          {
            "code" : "1431974",
            "display" : "tacrolimus Extended Release Oral Capsule [Astagraf]"
          },
          {
            "code" : "1431975",
            "display" : "Astagraf Oral Product"
          },
          {
            "code" : "1431976",
            "display" : "Astagraf Pill"
          },
          {
            "code" : "1431977",
            "display" : "24 HR tacrolimus 0.5 MG Extended Release Oral Capsule [Astagraf]"
          },
          {
            "code" : "1431980",
            "display" : "24 HR tacrolimus 1 MG Extended Release Oral Capsule"
          },
          {
            "code" : "1431981",
            "display" : "tacrolimus 1 MG [Astagraf]"
          },
          {
            "code" : "1431982",
            "display" : "24 HR tacrolimus 1 MG Extended Release Oral Capsule [Astagraf]"
          },
          {
            "code" : "1431985",
            "display" : "24 HR tacrolimus 5 MG Extended Release Oral Capsule"
          },
          {
            "code" : "1431986",
            "display" : "tacrolimus 5 MG [Astagraf]"
          },
          {
            "code" : "1431987",
            "display" : "24 HR tacrolimus 5 MG Extended Release Oral Capsule [Astagraf]"
          },
          {
            "code" : "1437967",
            "display" : "cyclophosphamide Oral Capsule"
          },
          {
            "code" : "1437968",
            "display" : "cyclophosphamide 25 MG Oral Capsule"
          },
          {
            "code" : "1437969",
            "display" : "cyclophosphamide 50 MG Oral Capsule"
          },
          {
            "code" : "1441402",
            "display" : "0.4 ML methotrexate 25 MG/ML Auto-Injector"
          },
          {
            "code" : "1441403",
            "display" : "Otrexup"
          },
          {
            "code" : "1441404",
            "display" : "methotrexate 25 MG/ML [Otrexup]"
          },
          {
            "code" : "1441406",
            "display" : "Otrexup Injectable Product"
          },
          {
            "code" : "1441407",
            "display" : "0.4 ML methotrexate 25 MG/ML Auto-Injector [Otrexup]"
          },
          {
            "code" : "1441410",
            "display" : "methotrexate 37.5 MG/ML"
          },
          {
            "code" : "1441411",
            "display" : "0.4 ML methotrexate 37.5 MG/ML Auto-Injector"
          },
          {
            "code" : "1441412",
            "display" : "methotrexate 37.5 MG/ML [Otrexup]"
          },
          {
            "code" : "1441413",
            "display" : "0.4 ML methotrexate 37.5 MG/ML Auto-Injector [Otrexup]"
          },
          {
            "code" : "1441416",
            "display" : "0.4 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1441417",
            "display" : "methotrexate 50 MG/ML [Otrexup]"
          },
          {
            "code" : "1441418",
            "display" : "0.4 ML methotrexate 50 MG/ML Auto-Injector [Otrexup]"
          },
          {
            "code" : "1441421",
            "display" : "methotrexate 62.5 MG/ML"
          },
          {
            "code" : "1441422",
            "display" : "0.4 ML methotrexate 62.5 MG/ML Auto-Injector"
          },
          {
            "code" : "1441423",
            "display" : "methotrexate 62.5 MG/ML [Otrexup]"
          },
          {
            "code" : "1441424",
            "display" : "0.4 ML methotrexate 62.5 MG/ML Auto-Injector [Otrexup]"
          },
          {
            "code" : "1441525",
            "display" : "tocilizumab 180 MG/ML"
          },
          {
            "code" : "1441526",
            "display" : "tocilizumab Prefilled Syringe"
          },
          {
            "code" : "1441527",
            "display" : "0.9 ML tocilizumab 180 MG/ML Prefilled Syringe"
          },
          {
            "code" : "1441528",
            "display" : "tocilizumab 180 MG/ML [Actemra]"
          },
          {
            "code" : "1441529",
            "display" : "tocilizumab Prefilled Syringe [Actemra]"
          },
          {
            "code" : "1441530",
            "display" : "0.9 ML tocilizumab 180 MG/ML Prefilled Syringe [Actemra]"
          },
          {
            "code" : "152633",
            "display" : "Cellcept"
          },
          {
            "code" : "1544378",
            "display" : "0.2 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1544379",
            "display" : "Rasuvo"
          },
          {
            "code" : "1544380",
            "display" : "methotrexate 50 MG/ML [Rasuvo]"
          },
          {
            "code" : "1544382",
            "display" : "Rasuvo Injectable Product"
          },
          {
            "code" : "1544383",
            "display" : "0.2 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1544385",
            "display" : "0.25 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1544386",
            "display" : "0.25 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1544387",
            "display" : "0.3 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1544388",
            "display" : "0.3 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1544389",
            "display" : "0.35 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1544390",
            "display" : "0.35 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1544394",
            "display" : "0.4 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1544395",
            "display" : "0.45 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1544396",
            "display" : "0.45 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1544397",
            "display" : "0.5 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1544398",
            "display" : "0.5 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1544401",
            "display" : "0.6 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1544402",
            "display" : "0.6 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1544403",
            "display" : "0.15 ML methotrexate 50 MG/ML Auto-Injector"
          },
          {
            "code" : "1544404",
            "display" : "0.15 ML methotrexate 50 MG/ML Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1545988",
            "display" : "cyclophosphamide anhydrous"
          },
          {
            "code" : "1655203",
            "display" : "methotrexate Auto-Injector"
          },
          {
            "code" : "1655205",
            "display" : "methotrexate Auto-Injector [Otrexup]"
          },
          {
            "code" : "1655252",
            "display" : "methotrexate Auto-Injector [Rasuvo]"
          },
          {
            "code" : "1655955",
            "display" : "methotrexate Injection"
          },
          {
            "code" : "1655956",
            "display" : "40 ML methotrexate 25 MG/ML Injection"
          },
          {
            "code" : "1655959",
            "display" : "10 ML methotrexate 25 MG/ML Injection"
          },
          {
            "code" : "1655960",
            "display" : "2 ML methotrexate 25 MG/ML Injection"
          },
          {
            "code" : "1655967",
            "display" : "4 ML methotrexate 25 MG/ML Injection"
          },
          {
            "code" : "1655968",
            "display" : "8 ML methotrexate 25 MG/ML Injection"
          },
          {
            "code" : "1656681",
            "display" : "methotrexate 1000 MG"
          },
          {
            "code" : "1657973",
            "display" : "tocilizumab Injection"
          },
          {
            "code" : "1657974",
            "display" : "4 ML tocilizumab 20 MG/ML Injection"
          },
          {
            "code" : "1657975",
            "display" : "tocilizumab Injection [Actemra]"
          },
          {
            "code" : "1657976",
            "display" : "4 ML tocilizumab 20 MG/ML Injection [Actemra]"
          },
          {
            "code" : "1657979",
            "display" : "10 ML tocilizumab 20 MG/ML Injection"
          },
          {
            "code" : "1657980",
            "display" : "10 ML tocilizumab 20 MG/ML Injection [Actemra]"
          },
          {
            "code" : "1657981",
            "display" : "20 ML tocilizumab 20 MG/ML Injection"
          },
          {
            "code" : "1657982",
            "display" : "20 ML tocilizumab 20 MG/ML Injection [Actemra]"
          },
          {
            "code" : "1659771",
            "display" : "abatacept 250 MG"
          },
          {
            "code" : "1659772",
            "display" : "abatacept Injection"
          },
          {
            "code" : "1659774",
            "display" : "abatacept 250 MG [Orencia]"
          },
          {
            "code" : "1659775",
            "display" : "abatacept Injection [Orencia]"
          },
          {
            "code" : "1664432",
            "display" : "tacrolimus 4 MG"
          },
          {
            "code" : "1664433",
            "display" : "tacrolimus Extended Release Oral Tablet"
          },
          {
            "code" : "1664434",
            "display" : "24 HR tacrolimus 4 MG Extended Release Oral Tablet"
          },
          {
            "code" : "1664435",
            "display" : "Envarsus"
          },
          {
            "code" : "1664436",
            "display" : "tacrolimus 4 MG [Envarsus]"
          },
          {
            "code" : "1664437",
            "display" : "tacrolimus Extended Release Oral Tablet [Envarsus]"
          },
          {
            "code" : "1664438",
            "display" : "Envarsus Oral Product"
          },
          {
            "code" : "1664439",
            "display" : "Envarsus Pill"
          },
          {
            "code" : "1664440",
            "display" : "24 HR tacrolimus 4 MG Extended Release Oral Tablet [Envarsus]"
          },
          {
            "code" : "1664455",
            "display" : "tacrolimus 0.75 MG"
          },
          {
            "code" : "1664456",
            "display" : "24 HR tacrolimus 0.75 MG Extended Release Oral Tablet"
          },
          {
            "code" : "1664457",
            "display" : "tacrolimus 0.75 MG [Envarsus]"
          },
          {
            "code" : "1664458",
            "display" : "24 HR tacrolimus 0.75 MG Extended Release Oral Tablet [Envarsus]"
          },
          {
            "code" : "1664461",
            "display" : "24 HR tacrolimus 1 MG Extended Release Oral Tablet"
          },
          {
            "code" : "1664462",
            "display" : "tacrolimus 1 MG [Envarsus]"
          },
          {
            "code" : "1664463",
            "display" : "24 HR tacrolimus 1 MG Extended Release Oral Tablet [Envarsus]"
          },
          {
            "code" : "1724304",
            "display" : "temsirolimus Injection"
          },
          {
            "code" : "1724306",
            "display" : "temsirolimus Injection [Torisel]"
          },
          {
            "code" : "1726176",
            "display" : "mycophenolate mofetil Injection"
          },
          {
            "code" : "1726179",
            "display" : "mycophenolate mofetil Injection [Cellcept]"
          },
          {
            "code" : "1732364",
            "display" : "cyclosporine Injection"
          },
          {
            "code" : "1732366",
            "display" : "cyclosporine Injection [Sandimmune]"
          },
          {
            "code" : "1734915",
            "display" : "cyclophosphamide 500 MG"
          },
          {
            "code" : "1734916",
            "display" : "cyclophosphamide Injection"
          },
          {
            "code" : "1734917",
            "display" : "cyclophosphamide 500 MG Injection"
          },
          {
            "code" : "1734918",
            "display" : "cyclophosphamide 1000 MG"
          },
          {
            "code" : "1734919",
            "display" : "cyclophosphamide 1000 MG Injection"
          },
          {
            "code" : "1734920",
            "display" : "cyclophosphamide 2000 MG"
          },
          {
            "code" : "1734921",
            "display" : "cyclophosphamide 2000 MG Injection"
          },
          {
            "code" : "1738334",
            "display" : "tacrolimus Injection"
          },
          {
            "code" : "1738336",
            "display" : "tacrolimus Injection [Prograf]"
          },
          {
            "code" : "1747178",
            "display" : "methotrexate 31.3 MG/ML"
          },
          {
            "code" : "1747179",
            "display" : "0.4 ML methotrexate 31.3 MG/ML Auto-Injector"
          },
          {
            "code" : "1747180",
            "display" : "methotrexate 31.3 MG/ML [Otrexup]"
          },
          {
            "code" : "1747181",
            "display" : "0.4 ML methotrexate 31.3 MG/ML Auto-Injector [Otrexup]"
          },
          {
            "code" : "1747184",
            "display" : "methotrexate 43.8 MG/ML"
          },
          {
            "code" : "1747185",
            "display" : "0.4 ML methotrexate 43.8 MG/ML Auto-Injector"
          },
          {
            "code" : "1747186",
            "display" : "methotrexate 43.8 MG/ML [Otrexup]"
          },
          {
            "code" : "1747187",
            "display" : "0.4 ML methotrexate 43.8 MG/ML Auto-Injector [Otrexup]"
          },
          {
            "code" : "1747191",
            "display" : "methotrexate 56.3 MG/ML"
          },
          {
            "code" : "1747192",
            "display" : "0.4 ML methotrexate 56.3 MG/ML Auto-Injector"
          },
          {
            "code" : "1747193",
            "display" : "methotrexate 56.3 MG/ML [Otrexup]"
          },
          {
            "code" : "1747194",
            "display" : "0.4 ML methotrexate 56.3 MG/ML Auto-Injector [Otrexup]"
          },
          {
            "code" : "1799227",
            "display" : "abatacept Auto-Injector"
          },
          {
            "code" : "1799228",
            "display" : "1 ML abatacept 125 MG/ML Auto-Injector"
          },
          {
            "code" : "1799229",
            "display" : "abatacept Auto-Injector [Orencia]"
          },
          {
            "code" : "1799230",
            "display" : "1 ML abatacept 125 MG/ML Auto-Injector [Orencia]"
          },
          {
            "code" : "1804993",
            "display" : "bortezomib 3.5 MG"
          },
          {
            "code" : "1804994",
            "display" : "bortezomib Injection"
          },
          {
            "code" : "1804996",
            "display" : "bortezomib 3.5 MG [Velcade]"
          },
          {
            "code" : "1804997",
            "display" : "bortezomib Injection [Velcade]"
          },
          {
            "code" : "1857910",
            "display" : "maraviroc 25 MG"
          },
          {
            "code" : "1857911",
            "display" : "maraviroc 25 MG Oral Tablet"
          },
          {
            "code" : "1857912",
            "display" : "maraviroc 25 MG [Selzentry]"
          },
          {
            "code" : "1857913",
            "display" : "maraviroc 25 MG Oral Tablet [Selzentry]"
          },
          {
            "code" : "1857914",
            "display" : "maraviroc 75 MG"
          },
          {
            "code" : "1857915",
            "display" : "maraviroc 75 MG Oral Tablet"
          },
          {
            "code" : "1857916",
            "display" : "maraviroc 75 MG [Selzentry]"
          },
          {
            "code" : "1857917",
            "display" : "maraviroc 75 MG Oral Tablet [Selzentry]"
          },
          {
            "code" : "1857918",
            "display" : "maraviroc 20 MG/ML"
          },
          {
            "code" : "1857919",
            "display" : "maraviroc Oral Liquid Product"
          },
          {
            "code" : "1857920",
            "display" : "maraviroc Oral Solution"
          },
          {
            "code" : "1857921",
            "display" : "maraviroc 20 MG/ML Oral Solution"
          },
          {
            "code" : "1857922",
            "display" : "maraviroc 20 MG/ML [Selzentry]"
          },
          {
            "code" : "1857923",
            "display" : "maraviroc Oral Solution [Selzentry]"
          },
          {
            "code" : "1857924",
            "display" : "Selzentry Oral Liquid Product"
          },
          {
            "code" : "1857925",
            "display" : "maraviroc 20 MG/ML Oral Solution [Selzentry]"
          },
          {
            "code" : "190353",
            "display" : "daclizumab"
          },
          {
            "code" : "1921590",
            "display" : "methotrexate Oral Liquid Product"
          },
          {
            "code" : "1921591",
            "display" : "methotrexate Oral Solution"
          },
          {
            "code" : "1921592",
            "display" : "methotrexate 2.5 MG/ML Oral Solution"
          },
          {
            "code" : "1921593",
            "display" : "Xatmep"
          },
          {
            "code" : "1921594",
            "display" : "methotrexate 2.5 MG/ML [Xatmep]"
          },
          {
            "code" : "1921595",
            "display" : "methotrexate Oral Solution [Xatmep]"
          },
          {
            "code" : "1921596",
            "display" : "Xatmep Oral Liquid Product"
          },
          {
            "code" : "1921597",
            "display" : "Xatmep Oral Product"
          },
          {
            "code" : "1921598",
            "display" : "methotrexate 2.5 MG/ML Oral Solution [Xatmep]"
          },
          {
            "code" : "1925254",
            "display" : "0.4 ML abatacept 125 MG/ML Prefilled Syringe"
          },
          {
            "code" : "1925255",
            "display" : "0.4 ML abatacept 125 MG/ML Prefilled Syringe [Orencia]"
          },
          {
            "code" : "1925256",
            "display" : "0.7 ML abatacept 125 MG/ML Prefilled Syringe"
          },
          {
            "code" : "1925257",
            "display" : "0.7 ML abatacept 125 MG/ML Prefilled Syringe [Orencia]"
          },
          {
            "code" : "1946772",
            "display" : "methotrexate 25 MG/ML Injectable Solution"
          },
          {
            "code" : "196463",
            "display" : "Prograf"
          },
          {
            "code" : "197549",
            "display" : "cyclophosphamide 25 MG Oral Tablet"
          },
          {
            "code" : "197550",
            "display" : "cyclophosphamide 50 MG Oral Tablet"
          },
          {
            "code" : "197552",
            "display" : "cyclosporine 100 MG Oral Capsule [Sandimmune]"
          },
          {
            "code" : "197553",
            "display" : "cyclosporine 25 MG Oral Capsule"
          },
          {
            "code" : "198377",
            "display" : "tacrolimus 1 MG Oral Capsule"
          },
          {
            "code" : "198378",
            "display" : "tacrolimus 5 MG Oral Capsule"
          },
          {
            "code" : "198379",
            "display" : "1 ML tacrolimus 5 MG/ML Injection"
          },
          {
            "code" : "199058",
            "display" : "mycophenolate mofetil 250 MG Oral Capsule"
          },
          {
            "code" : "200060",
            "display" : "mycophenolate mofetil 500 MG Oral Tablet"
          },
          {
            "code" : "202816",
            "display" : "Sandimmune"
          },
          {
            "code" : "202817",
            "display" : "Neoral"
          },
          {
            "code" : "205168",
            "display" : "cyclosporine 50 MG Oral Capsule"
          },
          {
            "code" : "205175",
            "display" : "5 ML cyclosporine 50 MG/ML Injection"
          },
          {
            "code" : "2052503",
            "display" : "tacrolimus 0.2 MG"
          },
          {
            "code" : "2052603",
            "display" : "tacrolimus Granule Product"
          },
          {
            "code" : "2052604",
            "display" : "tacrolimus Granules for Oral Suspension"
          },
          {
            "code" : "2052605",
            "display" : "tacrolimus 0.2 MG Granules for Oral Suspension"
          },
          {
            "code" : "2052606",
            "display" : "tacrolimus 0.2 MG [Prograf]"
          },
          {
            "code" : "2052607",
            "display" : "tacrolimus Granules for Oral Suspension [Prograf]"
          },
          {
            "code" : "2052608",
            "display" : "Prograf Granule Product"
          },
          {
            "code" : "2052609",
            "display" : "tacrolimus 0.2 MG Granules for Oral Suspension [Prograf]"
          },
          {
            "code" : "2052703",
            "display" : "tacrolimus 1 MG Granules for Oral Suspension"
          },
          {
            "code" : "2052704",
            "display" : "tacrolimus 1 MG Granules for Oral Suspension [Prograf]"
          },
          {
            "code" : "2055019",
            "display" : "cyclosporine 0.9 MG/ML"
          },
          {
            "code" : "2055020",
            "display" : "cyclosporine Ophthalmic Solution"
          },
          {
            "code" : "2055021",
            "display" : "cyclosporine 0.9 MG/ML Ophthalmic Solution"
          },
          {
            "code" : "2055022",
            "display" : "Cequa"
          },
          {
            "code" : "2055023",
            "display" : "cyclosporine 0.9 MG/ML [Cequa]"
          },
          {
            "code" : "2055024",
            "display" : "cyclosporine Ophthalmic Solution [Cequa]"
          },
          {
            "code" : "2055025",
            "display" : "Cequa Ophthalmic Product"
          },
          {
            "code" : "2055026",
            "display" : "cyclosporine 0.9 MG/ML Ophthalmic Solution [Cequa]"
          },
          {
            "code" : "2106072",
            "display" : "tocilizumab Auto-Injector"
          },
          {
            "code" : "2106073",
            "display" : "0.9 ML tocilizumab 180 MG/ML Auto-Injector"
          },
          {
            "code" : "2106074",
            "display" : "tocilizumab Auto-Injector [Actemra]"
          },
          {
            "code" : "2106075",
            "display" : "0.9 ML tocilizumab 180 MG/ML Auto-Injector [Actemra]"
          },
          {
            "code" : "212810",
            "display" : "cyclosporine 25 MG Oral Capsule [Sandimmune]"
          },
          {
            "code" : "212844",
            "display" : "5 ML cyclosporine 50 MG/ML Injection [Sandimmune]"
          },
          {
            "code" : "212957",
            "display" : "cyclosporine 100 MG/ML Oral Solution [Sandimmune]"
          },
          {
            "code" : "213394",
            "display" : "mycophenolate mofetil 500 MG Injection [Cellcept]"
          },
          {
            "code" : "221085",
            "display" : "cyclophosphamide lyophilized"
          },
          {
            "code" : "235991",
            "display" : "anhydrous tacrolimus"
          },
          {
            "code" : "236077",
            "display" : "cyclosporine, modified"
          },
          {
            "code" : "237112",
            "display" : "mycophenolate mofetil hydrochloride"
          },
          {
            "code" : "2377332",
            "display" : "methotrexate Prefilled Syringe"
          },
          {
            "code" : "2377333",
            "display" : "0.4 ML methotrexate 25 MG/ML Prefilled Syringe"
          },
          {
            "code" : "2377334",
            "display" : "Reditrex"
          },
          {
            "code" : "2377335",
            "display" : "methotrexate 25 MG/ML [Reditrex]"
          },
          {
            "code" : "2377336",
            "display" : "methotrexate Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2377337",
            "display" : "Reditrex Injectable Product"
          },
          {
            "code" : "2377338",
            "display" : "0.4 ML methotrexate 25 MG/ML Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2377341",
            "display" : "0.5 ML methotrexate 25 MG/ML Prefilled Syringe"
          },
          {
            "code" : "2377342",
            "display" : "0.5 ML methotrexate 25 MG/ML Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2377343",
            "display" : "0.6 ML methotrexate 25 MG/ML Prefilled Syringe"
          },
          {
            "code" : "2377344",
            "display" : "0.6 ML methotrexate 25 MG/ML Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2377345",
            "display" : "0.7 ML methotrexate 25 MG/ML Prefilled Syringe"
          },
          {
            "code" : "2377346",
            "display" : "0.7 ML methotrexate 25 MG/ML Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2377347",
            "display" : "0.8 ML methotrexate 25 MG/ML Prefilled Syringe"
          },
          {
            "code" : "2377348",
            "display" : "0.8 ML methotrexate 25 MG/ML Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2377349",
            "display" : "0.9 ML methotrexate 25 MG/ML Prefilled Syringe"
          },
          {
            "code" : "2377350",
            "display" : "0.9 ML methotrexate 25 MG/ML Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2377351",
            "display" : "1 ML methotrexate 25 MG/ML Prefilled Syringe"
          },
          {
            "code" : "2377352",
            "display" : "1 ML methotrexate 25 MG/ML Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2377353",
            "display" : "0.3 ML methotrexate 25 MG/ML Prefilled Syringe"
          },
          {
            "code" : "2377354",
            "display" : "0.3 ML methotrexate 25 MG/ML Prefilled Syringe [Reditrex]"
          },
          {
            "code" : "2386858",
            "display" : "cyclophosphamide 200 MG/ML"
          },
          {
            "code" : "2386859",
            "display" : "cyclophosphamide 200 MG/ML Injectable Solution"
          },
          {
            "code" : "241834",
            "display" : "cyclosporine, modified 100 MG Oral Capsule"
          },
          {
            "code" : "2470532",
            "display" : "Cyclavance"
          },
          {
            "code" : "2470533",
            "display" : "cyclosporine, modified 100 MG/ML [Cyclavance]"
          },
          {
            "code" : "2470534",
            "display" : "cyclosporine Oral Solution [Cyclavance]"
          },
          {
            "code" : "2470535",
            "display" : "Cyclavance Oral Liquid Product"
          },
          {
            "code" : "2470536",
            "display" : "Cyclavance Oral Product"
          },
          {
            "code" : "2470537",
            "display" : "cyclosporine, modified 100 MG/ML Oral Solution [Cyclavance]"
          },
          {
            "code" : "2568661",
            "display" : "5 ML cyclophosphamide 200 MG/ML Injection"
          },
          {
            "code" : "2568663",
            "display" : "2.5 ML cyclophosphamide 200 MG/ML Injection"
          },
          {
            "code" : "2570749",
            "display" : "ruxolitinib 15 MG/ML"
          },
          {
            "code" : "2570750",
            "display" : "ruxolitinib Topical Product"
          },
          {
            "code" : "2570751",
            "display" : "ruxolitinib Topical Cream"
          },
          {
            "code" : "2570752",
            "display" : "ruxolitinib 15 MG/ML Topical Cream"
          },
          {
            "code" : "2570753",
            "display" : "Opzelura"
          },
          {
            "code" : "2570754",
            "display" : "ruxolitinib 15 MG/ML [Opzelura]"
          },
          {
            "code" : "2570755",
            "display" : "Opzelura Topical Product"
          },
          {
            "code" : "2570756",
            "display" : "ruxolitinib Topical Cream [Opzelura]"
          },
          {
            "code" : "2570757",
            "display" : "ruxolitinib 15 MG/ML Topical Cream [Opzelura]"
          },
          {
            "code" : "2572292",
            "display" : "0.4 ML cyclosporine 0.5 MG/ML Ophthalmic Suspension"
          },
          {
            "code" : "2572293",
            "display" : "0.4 ML cyclosporine 0.5 MG/ML Ophthalmic Suspension [Restasis]"
          },
          {
            "code" : "258355",
            "display" : "Rapamune"
          },
          {
            "code" : "2586860",
            "display" : "sirolimus 100 MG"
          },
          {
            "code" : "2586861",
            "display" : "sirolimus Injectable Product"
          },
          {
            "code" : "2586862",
            "display" : "sirolimus Injection"
          },
          {
            "code" : "2586863",
            "display" : "sirolimus 100 MG Injection"
          },
          {
            "code" : "2586864",
            "display" : "Fyarro"
          },
          {
            "code" : "2586865",
            "display" : "sirolimus 100 MG [Fyarro]"
          },
          {
            "code" : "2586866",
            "display" : "Fyarro Injectable Product"
          },
          {
            "code" : "2586867",
            "display" : "sirolimus Injection [Fyarro]"
          },
          {
            "code" : "2586868",
            "display" : "sirolimus 100 MG Injection [Fyarro]"
          },
          {
            "code" : "2590607",
            "display" : "cyclosporine 1 MG/ML"
          },
          {
            "code" : "2590608",
            "display" : "cyclosporine 1 MG/ML Ophthalmic Suspension"
          },
          {
            "code" : "2590609",
            "display" : "Verkazia"
          },
          {
            "code" : "2590610",
            "display" : "cyclosporine 1 MG/ML [Verkazia]"
          },
          {
            "code" : "2590611",
            "display" : "Verkazia Ophthalmic Product"
          },
          {
            "code" : "2590612",
            "display" : "cyclosporine Ophthalmic Suspension [Verkazia]"
          },
          {
            "code" : "2590613",
            "display" : "cyclosporine 1 MG/ML Ophthalmic Suspension [Verkazia]"
          },
          {
            "code" : "2596861",
            "display" : "sirolimus 0.002 MG/MG"
          },
          {
            "code" : "2596862",
            "display" : "sirolimus Topical Product"
          },
          {
            "code" : "2596863",
            "display" : "sirolimus Topical Gel"
          },
          {
            "code" : "2596864",
            "display" : "sirolimus 0.002 MG/MG Topical Gel"
          },
          {
            "code" : "2596865",
            "display" : "Hyftor"
          },
          {
            "code" : "2596866",
            "display" : "sirolimus 0.002 MG/MG [Hyftor]"
          },
          {
            "code" : "2596867",
            "display" : "Hyftor Topical Product"
          },
          {
            "code" : "2596868",
            "display" : "sirolimus Topical Gel [Hyftor]"
          },
          {
            "code" : "2596869",
            "display" : "sirolimus 0.002 MG/MG Topical Gel [Hyftor]"
          },
          {
            "code" : "2601541",
            "display" : "bortezomib 1 MG"
          },
          {
            "code" : "2601542",
            "display" : "bortezomib 1 MG Injection"
          },
          {
            "code" : "2601543",
            "display" : "bortezomib 2.5 MG"
          },
          {
            "code" : "2601544",
            "display" : "bortezomib 2.5 MG Injection"
          },
          {
            "code" : "261134",
            "display" : "tacrolimus 0.5 MG Oral Capsule [Prograf]"
          },
          {
            "code" : "261530",
            "display" : "Gengraf"
          },
          {
            "code" : "283510",
            "display" : "methotrexate 15 MG Oral Tablet"
          },
          {
            "code" : "283511",
            "display" : "methotrexate 5 MG Oral Tablet"
          },
          {
            "code" : "283671",
            "display" : "methotrexate 7.5 MG Oral Tablet"
          },
          {
            "code" : "284520",
            "display" : "tacrolimus 0.001 MG/MG Topical Ointment [Protopic]"
          },
          {
            "code" : "284521",
            "display" : "tacrolimus 0.0003 MG/MG Topical Ointment [Protopic]"
          },
          {
            "code" : "284592",
            "display" : "methotrexate 5 MG Oral Tablet [Trexall]"
          },
          {
            "code" : "284593",
            "display" : "methotrexate 10 MG Oral Tablet [Trexall]"
          },
          {
            "code" : "284594",
            "display" : "methotrexate 7.5 MG Oral Tablet [Trexall]"
          },
          {
            "code" : "284595",
            "display" : "methotrexate 15 MG Oral Tablet [Trexall]"
          },
          {
            "code" : "284848",
            "display" : "Protopic"
          },
          {
            "code" : "284900",
            "display" : "Trexall"
          },
          {
            "code" : "287734",
            "display" : "methotrexate sodium"
          },
          {
            "code" : "3002",
            "display" : "cyclophosphamide"
          },
          {
            "code" : "3008",
            "display" : "cyclosporine"
          },
          {
            "code" : "309632",
            "display" : "cyclosporine 100 MG/ML Oral Solution"
          },
          {
            "code" : "311625",
            "display" : "methotrexate 1000 MG Injection"
          },
          {
            "code" : "311880",
            "display" : "mycophenolate mofetil 200 MG/ML Oral Suspension"
          },
          {
            "code" : "311881",
            "display" : "mycophenolate mofetil 500 MG Injection"
          },
          {
            "code" : "313189",
            "display" : "tacrolimus 0.0003 MG/MG Topical Ointment"
          },
          {
            "code" : "313190",
            "display" : "tacrolimus 0.5 MG Oral Capsule"
          },
          {
            "code" : "314230",
            "display" : "sirolimus 1 MG/ML Oral Solution"
          },
          {
            "code" : "314266",
            "display" : "tacrolimus 0.001 MG/MG Topical Ointment"
          },
          {
            "code" : "315148",
            "display" : "methotrexate 2.5 MG/ML Injectable Solution"
          },
          {
            "code" : "315746",
            "display" : "cyclophosphamide 25 MG"
          },
          {
            "code" : "315747",
            "display" : "cyclophosphamide 50 MG"
          },
          {
            "code" : "315749",
            "display" : "cyclosporine 100 MG"
          },
          {
            "code" : "315750",
            "display" : "cyclosporine 100 MG/ML"
          },
          {
            "code" : "315751",
            "display" : "cyclosporine 25 MG"
          },
          {
            "code" : "315752",
            "display" : "cyclosporine 50 MG"
          },
          {
            "code" : "315753",
            "display" : "cyclosporine 50 MG/ML"
          },
          {
            "code" : "316316",
            "display" : "mycophenolate mofetil 250 MG"
          },
          {
            "code" : "316317",
            "display" : "mycophenolate mofetil 500 MG"
          },
          {
            "code" : "316758",
            "display" : "tacrolimus 1 MG"
          },
          {
            "code" : "316759",
            "display" : "tacrolimus 5 MG"
          },
          {
            "code" : "317510",
            "display" : "tacrolimus 5 MG/ML"
          },
          {
            "code" : "328160",
            "display" : "cyclosporine 100 MG Oral Capsule"
          },
          {
            "code" : "328404",
            "display" : "methotrexate 50 MG/ML"
          },
          {
            "code" : "328406",
            "display" : "methotrexate 25 MG/ML"
          },
          {
            "code" : "328407",
            "display" : "methotrexate 2.5 MG"
          },
          {
            "code" : "330028",
            "display" : "methotrexate 2.5 MG/ML"
          },
          {
            "code" : "330404",
            "display" : "tacrolimus 0.5 MG"
          },
          {
            "code" : "331549",
            "display" : "tacrolimus 0.001 MG/MG"
          },
          {
            "code" : "331550",
            "display" : "tacrolimus 0.0003 MG/MG"
          },
          {
            "code" : "331568",
            "display" : "methotrexate 10 MG"
          },
          {
            "code" : "331569",
            "display" : "methotrexate 15 MG"
          },
          {
            "code" : "331587",
            "display" : "mycophenolate mofetil 200 MG/ML"
          },
          {
            "code" : "332454",
            "display" : "methotrexate 5 MG"
          },
          {
            "code" : "332455",
            "display" : "methotrexate 7.5 MG"
          },
          {
            "code" : "333296",
            "display" : "sirolimus 1 MG/ML"
          },
          {
            "code" : "334294",
            "display" : "cyclosporine, modified 100 MG"
          },
          {
            "code" : "349208",
            "display" : "sirolimus 1 MG Oral Tablet"
          },
          {
            "code" : "350512",
            "display" : "sirolimus 1 MG"
          },
          {
            "code" : "351291",
            "display" : "cyclosporine 0.5 MG/ML Ophthalmic Suspension"
          },
          {
            "code" : "351901",
            "display" : "sirolimus 1 MG/ML Oral Solution [Rapamune]"
          },
          {
            "code" : "351989",
            "display" : "sirolimus 1 MG Oral Tablet [Rapamune]"
          },
          {
            "code" : "352951",
            "display" : "Restasis"
          },
          {
            "code" : "35302",
            "display" : "sirolimus"
          },
          {
            "code" : "353400",
            "display" : "cyclosporine 0.5 MG/ML"
          },
          {
            "code" : "356733",
            "display" : "Velcade"
          },
          {
            "code" : "358258",
            "display" : "bortezomib"
          },
          {
            "code" : "360110",
            "display" : "sirolimus 2 MG Oral Tablet"
          },
          {
            "code" : "360318",
            "display" : "sirolimus 2 MG"
          },
          {
            "code" : "360547",
            "display" : "methotrexate 100 MG/ML"
          },
          {
            "code" : "363914",
            "display" : "cyclosporine Oral Solution [Gengraf]"
          },
          {
            "code" : "363942",
            "display" : "cyclosporine Oral Solution [Neoral]"
          },
          {
            "code" : "364904",
            "display" : "sirolimus Oral Solution [Rapamune]"
          },
          {
            "code" : "366173",
            "display" : "cyclosporine Oral Capsule [Gengraf]"
          },
          {
            "code" : "366273",
            "display" : "tacrolimus Oral Capsule [Prograf]"
          },
          {
            "code" : "366479",
            "display" : "cyclosporine Oral Capsule [Neoral]"
          },
          {
            "code" : "366488",
            "display" : "cyclosporine Oral Capsule [Sandimmune]"
          },
          {
            "code" : "367339",
            "display" : "tacrolimus Topical Ointment [Protopic]"
          },
          {
            "code" : "368138",
            "display" : "methotrexate Oral Tablet [Trexall]"
          },
          {
            "code" : "368672",
            "display" : "sirolimus Oral Tablet [Rapamune]"
          },
          {
            "code" : "371664",
            "display" : "cyclophosphamide Oral Tablet"
          },
          {
            "code" : "371666",
            "display" : "cyclosporine Oral Capsule"
          },
          {
            "code" : "371667",
            "display" : "cyclosporine Oral Solution"
          },
          {
            "code" : "372835",
            "display" : "methotrexate Injectable Solution"
          },
          {
            "code" : "372836",
            "display" : "methotrexate Oral Tablet"
          },
          {
            "code" : "374015",
            "display" : "tacrolimus Oral Capsule"
          },
          {
            "code" : "374667",
            "display" : "mycophenolate mofetil Oral Tablet"
          },
          {
            "code" : "374670",
            "display" : "mycophenolate mofetil Oral Suspension"
          },
          {
            "code" : "375278",
            "display" : "sirolimus Oral Solution"
          },
          {
            "code" : "376666",
            "display" : "cyclophosphamide Injectable Solution"
          },
          {
            "code" : "378277",
            "display" : "sirolimus Oral Tablet"
          },
          {
            "code" : "378766",
            "display" : "cyclosporine Ophthalmic Suspension"
          },
          {
            "code" : "379060",
            "display" : "mycophenolate mofetil Oral Capsule"
          },
          {
            "code" : "379082",
            "display" : "tacrolimus Topical Ointment"
          },
          {
            "code" : "402092",
            "display" : "cyclosporine 0.5 MG/ML Ophthalmic Suspension [Restasis]"
          },
          {
            "code" : "402243",
            "display" : "bortezomib 3.5 MG Injection"
          },
          {
            "code" : "402244",
            "display" : "bortezomib 3.5 MG Injection [Velcade]"
          },
          {
            "code" : "402330",
            "display" : "cyclosporine Ophthalmic Suspension [Restasis]"
          },
          {
            "code" : "404432",
            "display" : "sirolimus 2 MG Oral Tablet [Rapamune]"
          },
          {
            "code" : "42316",
            "display" : "tacrolimus"
          },
          {
            "code" : "484288",
            "display" : "tacrolimus monohydrate"
          },
          {
            "code" : "484788",
            "display" : "cyclosporine microemulsion"
          },
          {
            "code" : "486331",
            "display" : "cyclosporine 100 MG/ML [Sandimmune]"
          },
          {
            "code" : "539497",
            "display" : "Atopica"
          },
          {
            "code" : "539499",
            "display" : "cyclosporine Oral Capsule [Atopica]"
          },
          {
            "code" : "564557",
            "display" : "tacrolimus 1 MG [Prograf]"
          },
          {
            "code" : "564558",
            "display" : "tacrolimus 5 MG [Prograf]"
          },
          {
            "code" : "564559",
            "display" : "tacrolimus 5 MG/ML [Prograf]"
          },
          {
            "code" : "565430",
            "display" : "cyclosporine 100 MG [Sandimmune]"
          },
          {
            "code" : "572889",
            "display" : "cyclosporine 25 MG [Sandimmune]"
          },
          {
            "code" : "572915",
            "display" : "cyclosporine 50 MG/ML [Sandimmune]"
          },
          {
            "code" : "574378",
            "display" : "tacrolimus 0.5 MG [Prograf]"
          },
          {
            "code" : "574948",
            "display" : "tacrolimus 0.001 MG/MG [Protopic]"
          },
          {
            "code" : "574949",
            "display" : "tacrolimus 0.0003 MG/MG [Protopic]"
          },
          {
            "code" : "575019",
            "display" : "methotrexate 5 MG [Trexall]"
          },
          {
            "code" : "575020",
            "display" : "methotrexate 10 MG [Trexall]"
          },
          {
            "code" : "575021",
            "display" : "methotrexate 7.5 MG [Trexall]"
          },
          {
            "code" : "575022",
            "display" : "methotrexate 15 MG [Trexall]"
          },
          {
            "code" : "575659",
            "display" : "sirolimus 1 MG/ML [Rapamune]"
          },
          {
            "code" : "575733",
            "display" : "sirolimus 1 MG [Rapamune]"
          },
          {
            "code" : "576100",
            "display" : "cyclosporine 0.5 MG/ML [Restasis]"
          },
          {
            "code" : "576390",
            "display" : "sirolimus 2 MG [Rapamune]"
          },
          {
            "code" : "612865",
            "display" : "tocilizumab"
          },
          {
            "code" : "614391",
            "display" : "abatacept"
          },
          {
            "code" : "616011",
            "display" : "Orencia"
          },
          {
            "code" : "616015",
            "display" : "abatacept 250 MG Injection"
          },
          {
            "code" : "616018",
            "display" : "abatacept 250 MG Injection [Orencia]"
          },
          {
            "code" : "616433",
            "display" : "mycophenolate mofetil 500 MG [Cellcept]"
          },
          {
            "code" : "616434",
            "display" : "mycophenolate mofetil Oral Tablet [Cellcept]"
          },
          {
            "code" : "616435",
            "display" : "mycophenolate mofetil 500 MG Oral Tablet [Cellcept]"
          },
          {
            "code" : "616442",
            "display" : "mycophenolate mofetil 200 MG/ML [Cellcept]"
          },
          {
            "code" : "616443",
            "display" : "mycophenolate mofetil Oral Suspension [Cellcept]"
          },
          {
            "code" : "616444",
            "display" : "mycophenolate mofetil 200 MG/ML Oral Suspension [Cellcept]"
          },
          {
            "code" : "616445",
            "display" : "mycophenolate mofetil 250 MG [Cellcept]"
          },
          {
            "code" : "616446",
            "display" : "mycophenolate mofetil Oral Capsule [Cellcept]"
          },
          {
            "code" : "616447",
            "display" : "mycophenolate mofetil 250 MG Oral Capsule [Cellcept]"
          },
          {
            "code" : "620216",
            "display" : "maraviroc"
          },
          {
            "code" : "657797",
            "display" : "temsirolimus"
          },
          {
            "code" : "68149",
            "display" : "mycophenolate mofetil"
          },
          {
            "code" : "6851",
            "display" : "methotrexate"
          },
          {
            "code" : "690313",
            "display" : "cyclophosphamide / mannitol"
          },
          {
            "code" : "722287",
            "display" : "temsirolimus 25 MG/ML"
          },
          {
            "code" : "722289",
            "display" : "1.2 ML temsirolimus 25 MG/ML Injection"
          },
          {
            "code" : "725106",
            "display" : "temsirolimus 25 MG/ML [Torisel]"
          },
          {
            "code" : "725108",
            "display" : "1.2 ML temsirolimus 25 MG/ML Injection [Torisel]"
          },
          {
            "code" : "728221",
            "display" : "maraviroc 150 MG"
          },
          {
            "code" : "728222",
            "display" : "maraviroc Oral Tablet"
          },
          {
            "code" : "728223",
            "display" : "maraviroc 150 MG Oral Tablet"
          },
          {
            "code" : "728224",
            "display" : "maraviroc 300 MG"
          },
          {
            "code" : "728225",
            "display" : "maraviroc 300 MG Oral Tablet"
          },
          {
            "code" : "728648",
            "display" : "Selzentry"
          },
          {
            "code" : "729199",
            "display" : "maraviroc 150 MG [Selzentry]"
          },
          {
            "code" : "729200",
            "display" : "maraviroc Oral Tablet [Selzentry]"
          },
          {
            "code" : "729201",
            "display" : "maraviroc 150 MG Oral Tablet [Selzentry]"
          },
          {
            "code" : "729202",
            "display" : "maraviroc 300 MG [Selzentry]"
          },
          {
            "code" : "729203",
            "display" : "maraviroc 300 MG Oral Tablet [Selzentry]"
          },
          {
            "code" : "835787",
            "display" : "cyclosporine, modified 100 MG [Gengraf]"
          },
          {
            "code" : "835835",
            "display" : "cyclosporine, modified 100 MG Oral Capsule [Gengraf]"
          },
          {
            "code" : "835885",
            "display" : "cyclosporine, modified 100 MG/ML"
          },
          {
            "code" : "835886",
            "display" : "cyclosporine, modified 100 MG/ML Oral Solution"
          },
          {
            "code" : "835887",
            "display" : "cyclosporine, modified 100 MG/ML [Gengraf]"
          },
          {
            "code" : "835892",
            "display" : "cyclosporine, modified 100 MG/ML Oral Solution [Gengraf]"
          },
          {
            "code" : "835893",
            "display" : "cyclosporine, modified 25 MG"
          },
          {
            "code" : "835894",
            "display" : "cyclosporine, modified 25 MG Oral Capsule"
          },
          {
            "code" : "835895",
            "display" : "cyclosporine, modified 25 MG [Gengraf]"
          },
          {
            "code" : "835896",
            "display" : "cyclosporine, modified 25 MG Oral Capsule [Gengraf]"
          },
          {
            "code" : "835897",
            "display" : "cyclosporine, modified 100 MG/ML [Neoral]"
          },
          {
            "code" : "835899",
            "display" : "cyclosporine, modified 100 MG/ML Oral Solution [Neoral]"
          },
          {
            "code" : "835900",
            "display" : "cyclosporine, modified 100 MG [Neoral]"
          },
          {
            "code" : "835901",
            "display" : "cyclosporine, modified 25 MG [Neoral]"
          },
          {
            "code" : "835909",
            "display" : "cyclosporine, modified 25 MG Oral Capsule [Neoral]"
          },
          {
            "code" : "835911",
            "display" : "cyclosporine, modified 100 MG Oral Capsule [Neoral]"
          },
          {
            "code" : "835916",
            "display" : "cyclosporine, modified 100 MG [Atopica]"
          },
          {
            "code" : "835917",
            "display" : "cyclosporine, modified 100 MG Oral Capsule [Atopica]"
          },
          {
            "code" : "835918",
            "display" : "cyclosporine, modified 10 MG"
          },
          {
            "code" : "835919",
            "display" : "cyclosporine, modified 10 MG Oral Capsule"
          },
          {
            "code" : "835920",
            "display" : "cyclosporine, modified 10 MG [Atopica]"
          },
          {
            "code" : "835921",
            "display" : "cyclosporine, modified 10 MG Oral Capsule [Atopica]"
          },
          {
            "code" : "835922",
            "display" : "cyclosporine, modified 25 MG [Atopica]"
          },
          {
            "code" : "835923",
            "display" : "cyclosporine, modified 25 MG Oral Capsule [Atopica]"
          },
          {
            "code" : "835924",
            "display" : "cyclosporine, modified 50 MG"
          },
          {
            "code" : "835925",
            "display" : "cyclosporine, modified 50 MG Oral Capsule"
          },
          {
            "code" : "835926",
            "display" : "cyclosporine, modified 50 MG [Atopica]"
          },
          {
            "code" : "835927",
            "display" : "cyclosporine, modified 50 MG Oral Capsule [Atopica]"
          },
          {
            "code" : "895758",
            "display" : "tocilizumab 20 MG/ML"
          },
          {
            "code" : "895761",
            "display" : "Actemra"
          },
          {
            "code" : "895762",
            "display" : "tocilizumab 20 MG/ML [Actemra]"
          },
          {
            "code" : "905157",
            "display" : "sirolimus 0.5 MG"
          },
          {
            "code" : "905158",
            "display" : "sirolimus 0.5 MG Oral Tablet"
          },
          {
            "code" : "905159",
            "display" : "sirolimus 0.5 MG [Rapamune]"
          },
          {
            "code" : "905160",
            "display" : "sirolimus 0.5 MG Oral Tablet [Rapamune]"
          },
          {
            "code" : "94035",
            "display" : "cyclosporine Oral Solution [Sandimmune]"
          }
        ]
      }
    ]
  }
}

```
