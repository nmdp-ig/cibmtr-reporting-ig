# RxNorm - Prep Regimen - CIBMTR Reporting Implementation Guide v0.1.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RxNorm - Prep Regimen**

## ValueSet: RxNorm - Prep Regimen (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/med-prep-regimen-vs | *Version*:0.1.11 |
| Draft as of 2026-06-21 | *Computable Name*:RxNormPrepRegimenVS |

 
RxNorm codes for Prep Regimen 

 **References** 

* Included into [RxNormAll2400VS](ValueSet-med-all-form2400-vs.md)
* [CIBMTR Prep Regimen Medication](StructureDefinition-cibmtr-prep-regimen-medication.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "med-prep-regimen-vs",
  "url" : "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/med-prep-regimen-vs",
  "version" : "0.1.11",
  "name" : "RxNormPrepRegimenVS",
  "title" : "RxNorm - Prep Regimen",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-06-21T23:16:04-05:00",
  "publisher" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
  "contact" : [
    {
      "name" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://www.cibmtr.org"
        }
      ]
    },
    {
      "name" : "Bob Milius",
      "telecom" : [
        {
          "system" : "email",
          "value" : "bmilius@nmdp.org"
        }
      ]
    }
  ],
  "description" : "RxNorm codes for Prep Regimen",
  "compose" : {
    "include" : [
      {
        "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
        "concept" : [
          {
            "code" : "1008080",
            "display" : "aspirin / methylprednisolone"
          },
          {
            "code" : "10473",
            "display" : "thiotepa"
          },
          {
            "code" : "105551",
            "display" : "busulfan 2 MG Oral Tablet [Myleran]"
          },
          {
            "code" : "105552",
            "display" : "carmustine 100 MG Injection [BiCNU]"
          },
          {
            "code" : "105562",
            "display" : "melphalan 2 MG Oral Tablet [Alkeran]"
          },
          {
            "code" : "105567",
            "display" : "treosulfan 250 MG Oral Capsule"
          },
          {
            "code" : "105607",
            "display" : "pentostatin 10 MG Injection [Nipent]"
          },
          {
            "code" : "106991",
            "display" : "lidocaine / methylprednisolone"
          },
          {
            "code" : "107005",
            "display" : "methylprednisolone / neomycin"
          },
          {
            "code" : "1100385",
            "display" : "methylprednisolone acetate 0.01 MG/MG"
          },
          {
            "code" : "1100386",
            "display" : "methylprednisolone Topical Gel"
          },
          {
            "code" : "1100387",
            "display" : "methylprednisolone acetate 0.01 MG/MG Topical Gel"
          },
          {
            "code" : "1100388",
            "display" : "HybriSil"
          },
          {
            "code" : "1100389",
            "display" : "methylprednisolone acetate 0.01 MG/MG [HybriSil]"
          },
          {
            "code" : "1100390",
            "display" : "methylprednisolone Topical Gel [HybriSil]"
          },
          {
            "code" : "1100391",
            "display" : "methylprednisolone acetate 0.01 MG/MG Topical Gel [HybriSil]"
          },
          {
            "code" : "1114693",
            "display" : "bendamustine hydrochloride"
          },
          {
            "code" : "1148918",
            "display" : "gemcitabine 38 MG/ML"
          },
          {
            "code" : "1151374",
            "display" : "busulfan Injectable Product"
          },
          {
            "code" : "1151375",
            "display" : "busulfan Oral Product"
          },
          {
            "code" : "1151376",
            "display" : "busulfan Pill"
          },
          {
            "code" : "1151413",
            "display" : "carmustine Drug Implant Product"
          },
          {
            "code" : "1151483",
            "display" : "cytarabine Injectable Product"
          },
          {
            "code" : "1151727",
            "display" : "carmustine Injectable Product"
          },
          {
            "code" : "1156104",
            "display" : "carboplatin Injectable Product"
          },
          {
            "code" : "1156181",
            "display" : "cyclophosphamide Injectable Product"
          },
          {
            "code" : "1156182",
            "display" : "cyclophosphamide Oral Product"
          },
          {
            "code" : "1156183",
            "display" : "cyclophosphamide Pill"
          },
          {
            "code" : "1156288",
            "display" : "ifosfamide Injectable Product"
          },
          {
            "code" : "1156487",
            "display" : "thiotepa Injectable Product"
          },
          {
            "code" : "1156710",
            "display" : "gemcitabine Injectable Product"
          },
          {
            "code" : "1157928",
            "display" : "etoposide Injectable Product"
          },
          {
            "code" : "1157929",
            "display" : "etoposide Oral Product"
          },
          {
            "code" : "1157930",
            "display" : "etoposide Pill"
          },
          {
            "code" : "1157967",
            "display" : "rituximab Injectable Product"
          },
          {
            "code" : "1159787",
            "display" : "melphalan Injectable Product"
          },
          {
            "code" : "1159788",
            "display" : "melphalan Oral Product"
          },
          {
            "code" : "1159789",
            "display" : "melphalan Pill"
          },
          {
            "code" : "1160009",
            "display" : "bendamustine Injectable Product"
          },
          {
            "code" : "1162765",
            "display" : "treosulfan Injectable Product"
          },
          {
            "code" : "1162766",
            "display" : "treosulfan Oral Product"
          },
          {
            "code" : "1162767",
            "display" : "treosulfan Pill"
          },
          {
            "code" : "1163485",
            "display" : "methylprednisolone / neomycin Topical Product"
          },
          {
            "code" : "1163486",
            "display" : "methylprednisolone Injectable Product"
          },
          {
            "code" : "1163488",
            "display" : "methylprednisolone Oral Product"
          },
          {
            "code" : "1163489",
            "display" : "methylprednisolone Pill"
          },
          {
            "code" : "1163491",
            "display" : "methylprednisolone Topical Product"
          },
          {
            "code" : "1163761",
            "display" : "clofarabine Injectable Product"
          },
          {
            "code" : "1164046",
            "display" : "lidocaine / methylprednisolone Injectable Product"
          },
          {
            "code" : "1165043",
            "display" : "fludarabine Injectable Product"
          },
          {
            "code" : "1165044",
            "display" : "fludarabine Oral Product"
          },
          {
            "code" : "1165045",
            "display" : "fludarabine Pill"
          },
          {
            "code" : "1165319",
            "display" : "lomustine Oral Product"
          },
          {
            "code" : "1165320",
            "display" : "lomustine Pill"
          },
          {
            "code" : "1165408",
            "display" : "pentostatin Injectable Product"
          },
          {
            "code" : "1165881",
            "display" : "A-MethaPred Injectable Product"
          },
          {
            "code" : "1167136",
            "display" : "Ifex Injectable Product"
          },
          {
            "code" : "1168702",
            "display" : "Busulfex Injectable Product"
          },
          {
            "code" : "1171232",
            "display" : "Gliadel Drug Implant Product"
          },
          {
            "code" : "1172713",
            "display" : "HybriSil Topical Product"
          },
          {
            "code" : "1173022",
            "display" : "Clolar Injectable Product"
          },
          {
            "code" : "1173110",
            "display" : "Depo-Medrol Injectable Product"
          },
          {
            "code" : "1173621",
            "display" : "BiCNU Injectable Product"
          },
          {
            "code" : "1176189",
            "display" : "Alkeran Injectable Product"
          },
          {
            "code" : "1176190",
            "display" : "Alkeran Oral Product"
          },
          {
            "code" : "1176191",
            "display" : "Alkeran Pill"
          },
          {
            "code" : "1178005",
            "display" : "Toposar Injectable Product"
          },
          {
            "code" : "1179668",
            "display" : "Treanda Injectable Product"
          },
          {
            "code" : "1182364",
            "display" : "Paraplatin Injectable Product"
          },
          {
            "code" : "1183796",
            "display" : "Medrol Oral Product"
          },
          {
            "code" : "1183797",
            "display" : "Medrol Pill"
          },
          {
            "code" : "1183920",
            "display" : "Nipent Injectable Product"
          },
          {
            "code" : "1184840",
            "display" : "Solu-Medrol Injectable Product"
          },
          {
            "code" : "1185345",
            "display" : "Rituxan Injectable Product"
          },
          {
            "code" : "1185666",
            "display" : "Myleran Oral Product"
          },
          {
            "code" : "1185667",
            "display" : "Myleran Pill"
          },
          {
            "code" : "121191",
            "display" : "rituximab"
          },
          {
            "code" : "12574",
            "display" : "gemcitabine"
          },
          {
            "code" : "134547",
            "display" : "bendamustine"
          },
          {
            "code" : "1357886",
            "display" : "methylprednisolone 2000 MG Injection"
          },
          {
            "code" : "1357888",
            "display" : "methylprednisolone 2000 MG Injection [Solu-Medrol]"
          },
          {
            "code" : "1358496",
            "display" : "methylprednisolone acetate 40 MG/ML"
          },
          {
            "code" : "1358497",
            "display" : "lidocaine / methylprednisolone Injectable Suspension"
          },
          {
            "code" : "1358498",
            "display" : "lidocaine hydrochloride 10 MG/ML / methylprednisolone acetate 40 MG/ML Injectable Suspension"
          },
          {
            "code" : "1358509",
            "display" : "methylprednisolone acetate 20 MG/ML"
          },
          {
            "code" : "1358510",
            "display" : "methylprednisolone acetate 20 MG/ML Injectable Suspension"
          },
          {
            "code" : "1358511",
            "display" : "methylprednisolone acetate 20 MG/ML [Depo-Medrol]"
          },
          {
            "code" : "1358512",
            "display" : "methylprednisolone acetate 20 MG/ML Injectable Suspension [Depo-Medrol]"
          },
          {
            "code" : "1358610",
            "display" : "methylprednisolone acetate 40 MG/ML Injectable Suspension"
          },
          {
            "code" : "1358611",
            "display" : "methylprednisolone acetate 40 MG/ML [Depo-Medrol]"
          },
          {
            "code" : "1358612",
            "display" : "methylprednisolone acetate 40 MG/ML Injectable Suspension [Depo-Medrol]"
          },
          {
            "code" : "1358616",
            "display" : "methylprednisolone acetate 80 MG/ML"
          },
          {
            "code" : "1358617",
            "display" : "methylprednisolone acetate 80 MG/ML Injectable Suspension"
          },
          {
            "code" : "1358618",
            "display" : "methylprednisolone acetate 80 MG/ML [Depo-Medrol]"
          },
          {
            "code" : "1358619",
            "display" : "methylprednisolone acetate 80 MG/ML Injectable Suspension [Depo-Medrol]"
          },
          {
            "code" : "1366537",
            "display" : "Tepadina"
          },
          {
            "code" : "1437967",
            "display" : "cyclophosphamide Oral Capsule"
          },
          {
            "code" : "1437968",
            "display" : "cyclophosphamide 25 MG Oral Capsule"
          },
          {
            "code" : "1437969",
            "display" : "cyclophosphamide 50 MG Oral Capsule"
          },
          {
            "code" : "151325",
            "display" : "Alkeran"
          },
          {
            "code" : "152115",
            "display" : "Nipent"
          },
          {
            "code" : "152200",
            "display" : "Paraplatin"
          },
          {
            "code" : "1545771",
            "display" : "Gleostine"
          },
          {
            "code" : "1545772",
            "display" : "lomustine 10 MG [Gleostine]"
          },
          {
            "code" : "1545773",
            "display" : "lomustine Oral Capsule [Gleostine]"
          },
          {
            "code" : "1545774",
            "display" : "Gleostine Oral Product"
          },
          {
            "code" : "1545775",
            "display" : "Gleostine Pill"
          },
          {
            "code" : "1545776",
            "display" : "lomustine 10 MG Oral Capsule [Gleostine]"
          },
          {
            "code" : "1545777",
            "display" : "lomustine 100 MG [Gleostine]"
          },
          {
            "code" : "1545778",
            "display" : "lomustine 100 MG Oral Capsule [Gleostine]"
          },
          {
            "code" : "1545779",
            "display" : "lomustine 40 MG [Gleostine]"
          },
          {
            "code" : "1545780",
            "display" : "lomustine 40 MG Oral Capsule [Gleostine]"
          },
          {
            "code" : "1545988",
            "display" : "cyclophosphamide anhydrous"
          },
          {
            "code" : "155323",
            "display" : "methylprednisolone acetate"
          },
          {
            "code" : "1657861",
            "display" : "rituximab Injection"
          },
          {
            "code" : "1657862",
            "display" : "10 ML rituximab 10 MG/ML Injection"
          },
          {
            "code" : "1657863",
            "display" : "rituximab Injection [Rituxan]"
          },
          {
            "code" : "1657864",
            "display" : "10 ML rituximab 10 MG/ML Injection [Rituxan]"
          },
          {
            "code" : "1657867",
            "display" : "50 ML rituximab 10 MG/ML Injection"
          },
          {
            "code" : "1657868",
            "display" : "50 ML rituximab 10 MG/ML Injection [Rituxan]"
          },
          {
            "code" : "1660002",
            "display" : "thiotepa 100 MG"
          },
          {
            "code" : "1660003",
            "display" : "thiotepa Injection"
          },
          {
            "code" : "1660004",
            "display" : "thiotepa 100 MG Injection"
          },
          {
            "code" : "1660008",
            "display" : "thiotepa 15 MG"
          },
          {
            "code" : "1660009",
            "display" : "thiotepa 15 MG Injection"
          },
          {
            "code" : "1718998",
            "display" : "gemcitabine 200 MG"
          },
          {
            "code" : "1718999",
            "display" : "gemcitabine Injection"
          },
          {
            "code" : "1719000",
            "display" : "gemcitabine 200 MG Injection"
          },
          {
            "code" : "1719002",
            "display" : "gemcitabine 1000 MG"
          },
          {
            "code" : "1719003",
            "display" : "gemcitabine 1000 MG Injection"
          },
          {
            "code" : "1719004",
            "display" : "gemcitabine 2000 MG"
          },
          {
            "code" : "1719005",
            "display" : "gemcitabine 2000 MG Injection"
          },
          {
            "code" : "1720734",
            "display" : "lomustine 5 MG"
          },
          {
            "code" : "1720735",
            "display" : "lomustine 5 MG Oral Capsule"
          },
          {
            "code" : "1720736",
            "display" : "lomustine 5 MG [Gleostine]"
          },
          {
            "code" : "1720737",
            "display" : "lomustine 5 MG Oral Capsule [Gleostine]"
          },
          {
            "code" : "1720960",
            "display" : "26.3 ML gemcitabine 38 MG/ML Injection"
          },
          {
            "code" : "1720975",
            "display" : "52.6 ML gemcitabine 38 MG/ML Injection"
          },
          {
            "code" : "1720977",
            "display" : "5.26 ML gemcitabine 38 MG/ML Injection"
          },
          {
            "code" : "1726096",
            "display" : "bendamustine hydrochloride 25 MG/ML"
          },
          {
            "code" : "1726097",
            "display" : "bendamustine hydrochloride 25 MG/ML Injectable Solution"
          },
          {
            "code" : "1726098",
            "display" : "Bendeka"
          },
          {
            "code" : "1726099",
            "display" : "bendamustine hydrochloride 25 MG/ML [Bendeka]"
          },
          {
            "code" : "1726100",
            "display" : "bendamustine Injectable Solution [Bendeka]"
          },
          {
            "code" : "1726101",
            "display" : "Bendeka Injectable Product"
          },
          {
            "code" : "1726102",
            "display" : "bendamustine hydrochloride 25 MG/ML Injectable Solution [Bendeka]"
          },
          {
            "code" : "1729351",
            "display" : "busulfan Injection"
          },
          {
            "code" : "1729353",
            "display" : "busulfan Injection [Busulfex]"
          },
          {
            "code" : "1729367",
            "display" : "carmustine 100 MG"
          },
          {
            "code" : "1729368",
            "display" : "carmustine Injection"
          },
          {
            "code" : "1729370",
            "display" : "carmustine 100 MG [BiCNU]"
          },
          {
            "code" : "1729371",
            "display" : "carmustine Injection [BiCNU]"
          },
          {
            "code" : "1731354",
            "display" : "cytarabine Injection"
          },
          {
            "code" : "1731355",
            "display" : "5 ML cytarabine 20 MG/ML Injection"
          },
          {
            "code" : "1734339",
            "display" : "etoposide Injection"
          },
          {
            "code" : "1734340",
            "display" : "etoposide 100 MG Injection"
          },
          {
            "code" : "1734342",
            "display" : "etoposide 100 MG [Etopophos]"
          },
          {
            "code" : "1734343",
            "display" : "etoposide Injection [Etopophos]"
          },
          {
            "code" : "1734344",
            "display" : "Etopophos Injectable Product"
          },
          {
            "code" : "1734915",
            "display" : "cyclophosphamide 500 MG"
          },
          {
            "code" : "1734916",
            "display" : "cyclophosphamide Injection"
          },
          {
            "code" : "1734917",
            "display" : "cyclophosphamide 500 MG Injection"
          },
          {
            "code" : "1734918",
            "display" : "cyclophosphamide 1000 MG"
          },
          {
            "code" : "1734919",
            "display" : "cyclophosphamide 1000 MG Injection"
          },
          {
            "code" : "1734920",
            "display" : "cyclophosphamide 2000 MG"
          },
          {
            "code" : "1734921",
            "display" : "cyclophosphamide 2000 MG Injection"
          },
          {
            "code" : "1740862",
            "display" : "fludarabine phosphate 50 MG"
          },
          {
            "code" : "1740863",
            "display" : "fludarabine Injection"
          },
          {
            "code" : "1740864",
            "display" : "fludarabine phosphate 50 MG Injection"
          },
          {
            "code" : "1740865",
            "display" : "2 ML fludarabine phosphate 25 MG/ML Injection"
          },
          {
            "code" : "1740948",
            "display" : "melphalan 50 MG"
          },
          {
            "code" : "1740949",
            "display" : "melphalan Injection"
          },
          {
            "code" : "1740951",
            "display" : "melphalan 50 MG [Alkeran]"
          },
          {
            "code" : "1740952",
            "display" : "melphalan Injection [Alkeran]"
          },
          {
            "code" : "1743702",
            "display" : "methylprednisolone 125 MG"
          },
          {
            "code" : "1743703",
            "display" : "methylprednisolone Injection"
          },
          {
            "code" : "1743704",
            "display" : "methylprednisolone 125 MG Injection"
          },
          {
            "code" : "1743705",
            "display" : "methylprednisolone 125 MG [Solu-Medrol]"
          },
          {
            "code" : "1743706",
            "display" : "methylprednisolone Injection [Solu-Medrol]"
          },
          {
            "code" : "1743707",
            "display" : "methylprednisolone 125 MG Injection [Solu-Medrol]"
          },
          {
            "code" : "1743719",
            "display" : "methylprednisolone 500 MG"
          },
          {
            "code" : "1743720",
            "display" : "methylprednisolone 500 MG Injection"
          },
          {
            "code" : "1743721",
            "display" : "methylprednisolone 500 MG [Solu-Medrol]"
          },
          {
            "code" : "1743722",
            "display" : "methylprednisolone 500 MG Injection [Solu-Medrol]"
          },
          {
            "code" : "1743725",
            "display" : "methylprednisolone 1000 MG"
          },
          {
            "code" : "1743726",
            "display" : "methylprednisolone 1000 MG Injection"
          },
          {
            "code" : "1743727",
            "display" : "methylprednisolone 1000 MG [Solu-Medrol]"
          },
          {
            "code" : "1743729",
            "display" : "methylprednisolone 1000 MG Injection [Solu-Medrol]"
          },
          {
            "code" : "1743779",
            "display" : "1 ML methylprednisolone acetate 40 MG/ML Injection"
          },
          {
            "code" : "1743780",
            "display" : "methylprednisolone Injection [Depo-Medrol]"
          },
          {
            "code" : "1743781",
            "display" : "1 ML methylprednisolone acetate 40 MG/ML Injection [Depo-Medrol]"
          },
          {
            "code" : "1743855",
            "display" : "1 ML methylprednisolone acetate 80 MG/ML Injection"
          },
          {
            "code" : "1743856",
            "display" : "1 ML methylprednisolone acetate 80 MG/ML Injection [Depo-Medrol]"
          },
          {
            "code" : "1744013",
            "display" : "methylprednisolone 2000 MG"
          },
          {
            "code" : "1744015",
            "display" : "methylprednisolone 2000 MG [Solu-Medrol]"
          },
          {
            "code" : "1744018",
            "display" : "methylprednisolone 40 MG [Solu-Medrol]"
          },
          {
            "code" : "1744020",
            "display" : "methylprednisolone 40 MG [A-MethaPred]"
          },
          {
            "code" : "1744021",
            "display" : "methylprednisolone Injection [A-MethaPred]"
          },
          {
            "code" : "1744024",
            "display" : "methylprednisolone 125 MG [A-MethaPred]"
          },
          {
            "code" : "1745086",
            "display" : "Evomela"
          },
          {
            "code" : "1745087",
            "display" : "melphalan 50 MG [Evomela]"
          },
          {
            "code" : "1745088",
            "display" : "melphalan Injection [Evomela]"
          },
          {
            "code" : "1745089",
            "display" : "Evomela Injectable Product"
          },
          {
            "code" : "1745090",
            "display" : "melphalan 50 MG Injection [Evomela]"
          },
          {
            "code" : "1791586",
            "display" : "ifosfamide 3000 MG"
          },
          {
            "code" : "1791587",
            "display" : "ifosfamide Injection"
          },
          {
            "code" : "1791588",
            "display" : "ifosfamide 3000 MG Injection"
          },
          {
            "code" : "1791589",
            "display" : "ifosfamide 3000 MG [Ifex]"
          },
          {
            "code" : "1791590",
            "display" : "ifosfamide Injection [Ifex]"
          },
          {
            "code" : "1791591",
            "display" : "ifosfamide 3000 MG Injection [Ifex]"
          },
          {
            "code" : "1791592",
            "display" : "ifosfamide 1000 MG"
          },
          {
            "code" : "1791593",
            "display" : "ifosfamide 1000 MG Injection"
          },
          {
            "code" : "1791594",
            "display" : "ifosfamide 1000 MG [Ifex]"
          },
          {
            "code" : "1791595",
            "display" : "ifosfamide 1000 MG Injection [Ifex]"
          },
          {
            "code" : "1791597",
            "display" : "60 ML ifosfamide 50 MG/ML Injection"
          },
          {
            "code" : "1791599",
            "display" : "20 ML ifosfamide 50 MG/ML Injection"
          },
          {
            "code" : "1794543",
            "display" : "pentostatin 10 MG"
          },
          {
            "code" : "1794544",
            "display" : "pentostatin Injection"
          },
          {
            "code" : "1794546",
            "display" : "pentostatin 10 MG [Nipent]"
          },
          {
            "code" : "1794547",
            "display" : "pentostatin Injection [Nipent]"
          },
          {
            "code" : "1804999",
            "display" : "bendamustine hydrochloride 100 MG"
          },
          {
            "code" : "1805000",
            "display" : "bendamustine Injection"
          },
          {
            "code" : "1805001",
            "display" : "bendamustine hydrochloride 100 MG Injection"
          },
          {
            "code" : "1805002",
            "display" : "bendamustine hydrochloride 100 MG [Treanda]"
          },
          {
            "code" : "1805003",
            "display" : "bendamustine Injection [Treanda]"
          },
          {
            "code" : "1805004",
            "display" : "bendamustine hydrochloride 100 MG Injection [Treanda]"
          },
          {
            "code" : "1805006",
            "display" : "bendamustine hydrochloride 25 MG"
          },
          {
            "code" : "1805007",
            "display" : "bendamustine hydrochloride 25 MG Injection"
          },
          {
            "code" : "1805008",
            "display" : "bendamustine hydrochloride 25 MG [Treanda]"
          },
          {
            "code" : "1805009",
            "display" : "bendamustine hydrochloride 25 MG Injection [Treanda]"
          },
          {
            "code" : "1806666",
            "display" : "clofarabine Injection"
          },
          {
            "code" : "1806668",
            "display" : "clofarabine Injection [Clolar]"
          },
          {
            "code" : "1828",
            "display" : "busulfan"
          },
          {
            "code" : "1919206",
            "display" : "thiotepa 100 MG [Tepadina]"
          },
          {
            "code" : "1919207",
            "display" : "thiotepa Injection [Tepadina]"
          },
          {
            "code" : "1919208",
            "display" : "Tepadina Injectable Product"
          },
          {
            "code" : "1919209",
            "display" : "thiotepa 100 MG Injection [Tepadina]"
          },
          {
            "code" : "1919210",
            "display" : "thiotepa 15 MG [Tepadina]"
          },
          {
            "code" : "1919211",
            "display" : "thiotepa 15 MG Injection [Tepadina]"
          },
          {
            "code" : "1927881",
            "display" : "rituximab 120 MG/ML"
          },
          {
            "code" : "1927882",
            "display" : "hyaluronidase / rituximab Injectable Product"
          },
          {
            "code" : "1927883",
            "display" : "hyaluronidase / rituximab Injection"
          },
          {
            "code" : "1927884",
            "display" : "hyaluronidase / rituximab"
          },
          {
            "code" : "1927885",
            "display" : "11.7 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection"
          },
          {
            "code" : "1927886",
            "display" : "Rituxan Hycela"
          },
          {
            "code" : "1927887",
            "display" : "hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML [Rituxan Hycela]"
          },
          {
            "code" : "1927888",
            "display" : "hyaluronidase / rituximab Injection [Rituxan Hycela]"
          },
          {
            "code" : "1927889",
            "display" : "Rituxan Hycela Injectable Product"
          },
          {
            "code" : "1927890",
            "display" : "11.7 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection [Rituxan Hycela]"
          },
          {
            "code" : "1927893",
            "display" : "13.4 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection"
          },
          {
            "code" : "1927894",
            "display" : "13.4 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection [Rituxan Hycela]"
          },
          {
            "code" : "1942738",
            "display" : "cytarabine liposome 100 MG"
          },
          {
            "code" : "1942743",
            "display" : "cytarabine liposome 100 MG / daunorubicin liposomal 44 MG Injection"
          },
          {
            "code" : "1942744",
            "display" : "Vyxeos"
          },
          {
            "code" : "1942745",
            "display" : "cytarabine liposome 100 MG / daunorubicin liposomal 44 MG [Vyxeos]"
          },
          {
            "code" : "1942747",
            "display" : "Vyxeos Injectable Product"
          },
          {
            "code" : "1942748",
            "display" : "cytarabine liposome 100 MG / daunorubicin liposomal 44 MG Injection [Vyxeos]"
          },
          {
            "code" : "197422",
            "display" : "busulfan 2 MG Oral Tablet"
          },
          {
            "code" : "197549",
            "display" : "cyclophosphamide 25 MG Oral Tablet"
          },
          {
            "code" : "197550",
            "display" : "cyclophosphamide 50 MG Oral Tablet"
          },
          {
            "code" : "197687",
            "display" : "etoposide 50 MG Oral Capsule"
          },
          {
            "code" : "197894",
            "display" : "lomustine 10 MG Oral Capsule"
          },
          {
            "code" : "197895",
            "display" : "lomustine 100 MG Oral Capsule"
          },
          {
            "code" : "197896",
            "display" : "lomustine 40 MG Oral Capsule"
          },
          {
            "code" : "197919",
            "display" : "melphalan 2 MG Oral Tablet"
          },
          {
            "code" : "197969",
            "display" : "methylprednisolone 2 MG Oral Tablet"
          },
          {
            "code" : "197971",
            "display" : "methylprednisolone 32 MG Oral Tablet"
          },
          {
            "code" : "197973",
            "display" : "methylprednisolone 8 MG Oral Tablet"
          },
          {
            "code" : "199315",
            "display" : "etoposide 100 MG Oral Capsule"
          },
          {
            "code" : "199771",
            "display" : "methylprednisolone 100 MG Oral Tablet"
          },
          {
            "code" : "1998781",
            "display" : "gemcitabine 100 MG/ML"
          },
          {
            "code" : "1998782",
            "display" : "gemcitabine Injectable Solution"
          },
          {
            "code" : "1998783",
            "display" : "gemcitabine 100 MG/ML Injectable Solution"
          },
          {
            "code" : "2017575",
            "display" : "cytarabine / daunorubicin"
          },
          {
            "code" : "202702",
            "display" : "Medrol"
          },
          {
            "code" : "203010",
            "display" : "Myleran"
          },
          {
            "code" : "203189",
            "display" : "methylprednisolone sodium succinate"
          },
          {
            "code" : "203856",
            "display" : "Solu-Medrol"
          },
          {
            "code" : "203857",
            "display" : "A-MethaPred"
          },
          {
            "code" : "2058857",
            "display" : "gemcitabine 10 MG/ML"
          },
          {
            "code" : "2058858",
            "display" : "120 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058859",
            "display" : "Infugem"
          },
          {
            "code" : "2058860",
            "display" : "gemcitabine 10 MG/ML [Infugem]"
          },
          {
            "code" : "2058861",
            "display" : "gemcitabine Injection [Infugem]"
          },
          {
            "code" : "2058862",
            "display" : "Infugem Injectable Product"
          },
          {
            "code" : "2058863",
            "display" : "120 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058866",
            "display" : "140 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058867",
            "display" : "140 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058880",
            "display" : "150 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058881",
            "display" : "150 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058882",
            "display" : "160 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058883",
            "display" : "160 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058890",
            "display" : "170 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058891",
            "display" : "170 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058892",
            "display" : "180 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058893",
            "display" : "180 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058894",
            "display" : "190 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058895",
            "display" : "190 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058912",
            "display" : "130 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058918",
            "display" : "130 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058927",
            "display" : "200 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058928",
            "display" : "200 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "2058933",
            "display" : "220 ML gemcitabine 10 MG/ML Injection"
          },
          {
            "code" : "2058934",
            "display" : "220 ML gemcitabine 10 MG/ML Injection [Infugem]"
          },
          {
            "code" : "206831",
            "display" : "etoposide 20 MG/ML Injectable Solution [Toposar]"
          },
          {
            "code" : "207136",
            "display" : "methylprednisolone 2 MG Oral Tablet [Medrol]"
          },
          {
            "code" : "207137",
            "display" : "methylprednisolone 8 MG Oral Tablet [Medrol]"
          },
          {
            "code" : "207138",
            "display" : "methylprednisolone 16 MG Oral Tablet [Medrol]"
          },
          {
            "code" : "207141",
            "display" : "methylprednisolone 32 MG Oral Tablet [Medrol]"
          },
          {
            "code" : "207190",
            "display" : "methylprednisolone 40 MG Injection [A-MethaPred]"
          },
          {
            "code" : "207191",
            "display" : "methylprednisolone 40 MG Injection [Solu-Medrol]"
          },
          {
            "code" : "207192",
            "display" : "methylprednisolone 125 MG Injection [A-MethaPred]"
          },
          {
            "code" : "207193",
            "display" : "methylprednisolone 62.5 MG/ML Injectable Solution [Solu-Medrol]"
          },
          {
            "code" : "2105",
            "display" : "carmustine"
          },
          {
            "code" : "2105824",
            "display" : "rituximab-abbs"
          },
          {
            "code" : "2105825",
            "display" : "rituximab-abbs 10 MG/ML"
          },
          {
            "code" : "2105826",
            "display" : "10 ML rituximab-abbs 10 MG/ML Injection"
          },
          {
            "code" : "2105827",
            "display" : "Truxima"
          },
          {
            "code" : "2105828",
            "display" : "rituximab-abbs 10 MG/ML [Truxima]"
          },
          {
            "code" : "2105829",
            "display" : "rituximab Injection [Truxima]"
          },
          {
            "code" : "2105830",
            "display" : "Truxima Injectable Product"
          },
          {
            "code" : "2105831",
            "display" : "10 ML rituximab-abbs 10 MG/ML Injection [Truxima]"
          },
          {
            "code" : "2105834",
            "display" : "50 ML rituximab-abbs 10 MG/ML Injection"
          },
          {
            "code" : "2105835",
            "display" : "50 ML rituximab-abbs 10 MG/ML Injection [Truxima]"
          },
          {
            "code" : "212994",
            "display" : "carmustine 7.7 MG Drug Implant [Gliadel]"
          },
          {
            "code" : "217357",
            "display" : "Gliadel"
          },
          {
            "code" : "217701",
            "display" : "Ifex"
          },
          {
            "code" : "2178262",
            "display" : "Belrapzo"
          },
          {
            "code" : "2178263",
            "display" : "bendamustine hydrochloride 25 MG/ML [Belrapzo]"
          },
          {
            "code" : "2178264",
            "display" : "bendamustine Injectable Solution [Belrapzo]"
          },
          {
            "code" : "2178265",
            "display" : "Belrapzo Injectable Product"
          },
          {
            "code" : "2178266",
            "display" : "bendamustine hydrochloride 25 MG/ML Injectable Solution [Belrapzo]"
          },
          {
            "code" : "220347",
            "display" : "Toposar"
          },
          {
            "code" : "221085",
            "display" : "cyclophosphamide lyophilized"
          },
          {
            "code" : "22584",
            "display" : "Depo-Medrol"
          },
          {
            "code" : "226719",
            "display" : "etoposide 100 MG Injection [Etopophos]"
          },
          {
            "code" : "226754",
            "display" : "Rituxan"
          },
          {
            "code" : "2273510",
            "display" : "rituximab-pvvr"
          },
          {
            "code" : "2273511",
            "display" : "rituximab-pvvr 10 MG/ML"
          },
          {
            "code" : "2273512",
            "display" : "10 ML rituximab-pvvr 10 MG/ML Injection"
          },
          {
            "code" : "2273513",
            "display" : "Ruxience"
          },
          {
            "code" : "2273514",
            "display" : "rituximab-pvvr 10 MG/ML [Ruxience]"
          },
          {
            "code" : "2273515",
            "display" : "rituximab Injection [Ruxience]"
          },
          {
            "code" : "2273516",
            "display" : "Ruxience Injectable Product"
          },
          {
            "code" : "2273517",
            "display" : "10 ML rituximab-pvvr 10 MG/ML Injection [Ruxience]"
          },
          {
            "code" : "2273520",
            "display" : "50 ML rituximab-pvvr 10 MG/ML Injection"
          },
          {
            "code" : "2273521",
            "display" : "50 ML rituximab-pvvr 10 MG/ML Injection [Ruxience]"
          },
          {
            "code" : "2285806",
            "display" : "cytarabine / daunorubicin Injection [Vyxeos]"
          },
          {
            "code" : "2285807",
            "display" : "cytarabine / daunorubicin Injection"
          },
          {
            "code" : "2285813",
            "display" : "cytarabine / daunorubicin Injectable Product"
          },
          {
            "code" : "234449",
            "display" : "iodine-131-tositumomab"
          },
          {
            "code" : "235857",
            "display" : "melphalan hydrochloride"
          },
          {
            "code" : "236234",
            "display" : "gemcitabine hydrochloride"
          },
          {
            "code" : "2386858",
            "display" : "cyclophosphamide 200 MG/ML"
          },
          {
            "code" : "2386859",
            "display" : "cyclophosphamide 200 MG/ML Injectable Solution"
          },
          {
            "code" : "240416",
            "display" : "cytarabine 20 MG/ML Injectable Solution"
          },
          {
            "code" : "240573",
            "display" : "pentostatin 10 MG Injection"
          },
          {
            "code" : "245255",
            "display" : "cytarabine 50 MG/ML Injectable Solution"
          },
          {
            "code" : "24614",
            "display" : "etoposide phosphate"
          },
          {
            "code" : "24698",
            "display" : "fludarabine"
          },
          {
            "code" : "2472325",
            "display" : "rituximab-arrx"
          },
          {
            "code" : "2472326",
            "display" : "rituximab-arrx 10 MG/ML"
          },
          {
            "code" : "2472327",
            "display" : "10 ML rituximab-arrx 10 MG/ML Injection"
          },
          {
            "code" : "2472328",
            "display" : "Riabni"
          },
          {
            "code" : "2472329",
            "display" : "rituximab-arrx 10 MG/ML [Riabni]"
          },
          {
            "code" : "2472330",
            "display" : "rituximab Injection [Riabni]"
          },
          {
            "code" : "2472331",
            "display" : "Riabni Injectable Product"
          },
          {
            "code" : "2472332",
            "display" : "10 ML rituximab-arrx 10 MG/ML Injection [Riabni]"
          },
          {
            "code" : "2472335",
            "display" : "50 ML rituximab-arrx 10 MG/ML Injection"
          },
          {
            "code" : "2472336",
            "display" : "50 ML rituximab-arrx 10 MG/ML Injection [Riabni]"
          },
          {
            "code" : "249364",
            "display" : "20 ML cytarabine 100 MG/ML Injection"
          },
          {
            "code" : "250758",
            "display" : "treosulfan 50 MG/ML Injectable Solution"
          },
          {
            "code" : "25102",
            "display" : "fludarabine phosphate"
          },
          {
            "code" : "253113",
            "display" : "10 ML busulfan 6 MG/ML Injection"
          },
          {
            "code" : "2531369",
            "display" : "melphalan flufenamide"
          },
          {
            "code" : "2531370",
            "display" : "melphalan flufenamide hydrochloride"
          },
          {
            "code" : "2531371",
            "display" : "melphalan flufenamide 20 MG"
          },
          {
            "code" : "2531372",
            "display" : "melphalan flufenamide Injectable Product"
          },
          {
            "code" : "2531373",
            "display" : "melphalan flufenamide Injection"
          },
          {
            "code" : "2531374",
            "display" : "melphalan flufenamide 20 MG Injection"
          },
          {
            "code" : "2531376",
            "display" : "melphalan flufenamide 20 MG [Pepaxto]"
          },
          {
            "code" : "2531377",
            "display" : "melphalan flufenamide Injection [Pepaxto]"
          },
          {
            "code" : "2531379",
            "display" : "melphalan flufenamide 20 MG Injection [Pepaxto]"
          },
          {
            "code" : "2568661",
            "display" : "5 ML cyclophosphamide 200 MG/ML Injection"
          },
          {
            "code" : "2568663",
            "display" : "2.5 ML cyclophosphamide 200 MG/ML Injection"
          },
          {
            "code" : "259966",
            "display" : "methylprednisolone 4 MG Oral Tablet"
          },
          {
            "code" : "260330",
            "display" : "methylprednisolone 4 MG Oral Tablet [Medrol]"
          },
          {
            "code" : "262323",
            "display" : "ibritumomab tiuxetan"
          },
          {
            "code" : "263010",
            "display" : "tositumomab"
          },
          {
            "code" : "274342",
            "display" : "Etopophos"
          },
          {
            "code" : "284425",
            "display" : "10 ML busulfan 6 MG/ML Injection [Busulfex]"
          },
          {
            "code" : "284676",
            "display" : "Busulfex"
          },
          {
            "code" : "29917",
            "display" : "methylprednisolone sodium phosphate"
          },
          {
            "code" : "3002",
            "display" : "cyclophosphamide"
          },
          {
            "code" : "3041",
            "display" : "cytarabine"
          },
          {
            "code" : "309012",
            "display" : "carmustine 100 MG Injection"
          },
          {
            "code" : "309013",
            "display" : "carmustine 7.7 MG Drug Implant"
          },
          {
            "code" : "310248",
            "display" : "etoposide 20 MG/ML Injectable Solution"
          },
          {
            "code" : "311487",
            "display" : "melphalan 50 MG Injection"
          },
          {
            "code" : "311659",
            "display" : "methylprednisolone 40 MG Injection"
          },
          {
            "code" : "314099",
            "display" : "methylprednisolone 62.5 MG/ML Injectable Solution"
          },
          {
            "code" : "315503",
            "display" : "busulfan 6 MG/ML"
          },
          {
            "code" : "315746",
            "display" : "cyclophosphamide 25 MG"
          },
          {
            "code" : "315747",
            "display" : "cyclophosphamide 50 MG"
          },
          {
            "code" : "315912",
            "display" : "etoposide 20 MG/ML"
          },
          {
            "code" : "315913",
            "display" : "etoposide 50 MG"
          },
          {
            "code" : "316160",
            "display" : "lomustine 10 MG"
          },
          {
            "code" : "316161",
            "display" : "lomustine 100 MG"
          },
          {
            "code" : "316162",
            "display" : "lomustine 40 MG"
          },
          {
            "code" : "316285",
            "display" : "methylprednisolone 2 MG"
          },
          {
            "code" : "316287",
            "display" : "methylprednisolone 32 MG"
          },
          {
            "code" : "316288",
            "display" : "methylprednisolone 8 MG"
          },
          {
            "code" : "316648",
            "display" : "rituximab 10 MG/ML"
          },
          {
            "code" : "317426",
            "display" : "methylprednisolone 16 MG"
          },
          {
            "code" : "317427",
            "display" : "methylprednisolone 4 MG"
          },
          {
            "code" : "317620",
            "display" : "busulfan 2 MG"
          },
          {
            "code" : "317646",
            "display" : "melphalan 2 MG"
          },
          {
            "code" : "328161",
            "display" : "methylprednisolone 16 MG Oral Tablet"
          },
          {
            "code" : "328431",
            "display" : "fludarabine phosphate 25 MG/ML"
          },
          {
            "code" : "329753",
            "display" : "etoposide 100 MG"
          },
          {
            "code" : "330037",
            "display" : "methylprednisolone 40 MG"
          },
          {
            "code" : "330459",
            "display" : "ifosfamide 50 MG/ML"
          },
          {
            "code" : "331779",
            "display" : "cytarabine 100 MG/ML"
          },
          {
            "code" : "332216",
            "display" : "methylprednisolone 100 MG"
          },
          {
            "code" : "332422",
            "display" : "cytarabine 20 MG/ML"
          },
          {
            "code" : "333668",
            "display" : "cytarabine 50 MG/ML"
          },
          {
            "code" : "336841",
            "display" : "treosulfan 250 MG"
          },
          {
            "code" : "340520",
            "display" : "carmustine 7.7 MG"
          },
          {
            "code" : "343027",
            "display" : "BiCNU"
          },
          {
            "code" : "346173",
            "display" : "methylprednisolone 62.5 MG/ML"
          },
          {
            "code" : "346209",
            "display" : "carboplatin 10 MG/ML"
          },
          {
            "code" : "352384",
            "display" : "ifosfamide / mesna"
          },
          {
            "code" : "362772",
            "display" : "methylprednisolone Injectable Solution [Solu-Medrol]"
          },
          {
            "code" : "362881",
            "display" : "etoposide Injectable Solution [Toposar]"
          },
          {
            "code" : "365570",
            "display" : "methylprednisolone Injectable Suspension [Depo-Medrol]"
          },
          {
            "code" : "368542",
            "display" : "busulfan Oral Tablet [Myleran]"
          },
          {
            "code" : "368772",
            "display" : "methylprednisolone Oral Tablet [Medrol]"
          },
          {
            "code" : "368873",
            "display" : "melphalan Oral Tablet [Alkeran]"
          },
          {
            "code" : "371165",
            "display" : "busulfan Oral Tablet"
          },
          {
            "code" : "371664",
            "display" : "cyclophosphamide Oral Tablet"
          },
          {
            "code" : "371676",
            "display" : "cytarabine Injectable Solution"
          },
          {
            "code" : "372132",
            "display" : "etoposide Oral Capsule"
          },
          {
            "code" : "372631",
            "display" : "lomustine Oral Capsule"
          },
          {
            "code" : "372756",
            "display" : "melphalan Oral Tablet"
          },
          {
            "code" : "372866",
            "display" : "methylprednisolone Injectable Suspension"
          },
          {
            "code" : "372868",
            "display" : "methylprednisolone Oral Tablet"
          },
          {
            "code" : "374186",
            "display" : "treosulfan Oral Capsule"
          },
          {
            "code" : "376656",
            "display" : "methylprednisolone Injectable Solution"
          },
          {
            "code" : "376666",
            "display" : "cyclophosphamide Injectable Solution"
          },
          {
            "code" : "376890",
            "display" : "etoposide Injectable Solution"
          },
          {
            "code" : "377198",
            "display" : "treosulfan Injectable Solution"
          },
          {
            "code" : "378363",
            "display" : "carboplatin Injectable Solution"
          },
          {
            "code" : "378774",
            "display" : "carmustine Drug Implant"
          },
          {
            "code" : "38508",
            "display" : "treosulfan"
          },
          {
            "code" : "393413",
            "display" : "fludarabine Oral Tablet"
          },
          {
            "code" : "393483",
            "display" : "treosulfan 50 MG/ML"
          },
          {
            "code" : "40048",
            "display" : "carboplatin"
          },
          {
            "code" : "405951",
            "display" : "carmustine Drug Implant [Gliadel]"
          },
          {
            "code" : "4179",
            "display" : "etoposide"
          },
          {
            "code" : "44151",
            "display" : "clofarabine"
          },
          {
            "code" : "486417",
            "display" : "clofarabine 1 MG/ML"
          },
          {
            "code" : "486419",
            "display" : "20 ML clofarabine 1 MG/ML Injection"
          },
          {
            "code" : "493622",
            "display" : "Clolar"
          },
          {
            "code" : "544913",
            "display" : "clofarabine 1 MG/ML [Clolar]"
          },
          {
            "code" : "544915",
            "display" : "20 ML clofarabine 1 MG/ML Injection [Clolar]"
          },
          {
            "code" : "544939",
            "display" : "cytarabine Injectable Suspension"
          },
          {
            "code" : "544940",
            "display" : "cytarabine 50 MG/ML Injectable Suspension"
          },
          {
            "code" : "564078",
            "display" : "busulfan 2 MG [Myleran]"
          },
          {
            "code" : "564088",
            "display" : "melphalan 2 MG [Alkeran]"
          },
          {
            "code" : "5657",
            "display" : "ifosfamide"
          },
          {
            "code" : "567639",
            "display" : "etoposide 20 MG/ML [Toposar]"
          },
          {
            "code" : "567927",
            "display" : "methylprednisolone 2 MG [Medrol]"
          },
          {
            "code" : "567928",
            "display" : "methylprednisolone 8 MG [Medrol]"
          },
          {
            "code" : "567929",
            "display" : "methylprednisolone 16 MG [Medrol]"
          },
          {
            "code" : "567932",
            "display" : "methylprednisolone 32 MG [Medrol]"
          },
          {
            "code" : "567984",
            "display" : "methylprednisolone 62.5 MG/ML [Solu-Medrol]"
          },
          {
            "code" : "572946",
            "display" : "carmustine 7.7 MG [Gliadel]"
          },
          {
            "code" : "573051",
            "display" : "rituximab 10 MG/ML [Rituxan]"
          },
          {
            "code" : "573495",
            "display" : "carboplatin 10 MG/ML [Paraplatin]"
          },
          {
            "code" : "574125",
            "display" : "methylprednisolone 4 MG [Medrol]"
          },
          {
            "code" : "574864",
            "display" : "busulfan 6 MG/ML [Busulfex]"
          },
          {
            "code" : "597195",
            "display" : "carboplatin 10 MG/ML Injectable Solution"
          },
          {
            "code" : "62136",
            "display" : "methylprednisolone aceponate"
          },
          {
            "code" : "6466",
            "display" : "lomustine"
          },
          {
            "code" : "6718",
            "display" : "melphalan"
          },
          {
            "code" : "686161",
            "display" : "carboplatin 10 MG/ML Injectable Solution [Paraplatin]"
          },
          {
            "code" : "6902",
            "display" : "methylprednisolone"
          },
          {
            "code" : "690313",
            "display" : "cyclophosphamide / mannitol"
          },
          {
            "code" : "741098",
            "display" : "Treanda"
          },
          {
            "code" : "762675",
            "display" : "{21 (methylprednisolone 4 MG Oral Tablet) } Pack"
          },
          {
            "code" : "790322",
            "display" : "bendamustine Injectable Solution"
          },
          {
            "code" : "8011",
            "display" : "pentostatin"
          },
          {
            "code" : "828705",
            "display" : "fludarabine phosphate 10 MG"
          },
          {
            "code" : "828706",
            "display" : "fludarabine phosphate 10 MG Oral Tablet"
          },
          {
            "code" : "834023",
            "display" : "{21 (methylprednisolone 4 MG Oral Tablet [Medrol]) } Pack [Medrol Dosepak]"
          },
          {
            "code" : "876399",
            "display" : "melphalan 50 MG Injection [Alkeran]"
          },
          {
            "code" : "899367",
            "display" : "{10 (20 ML ifosfamide 50 MG/ML Injection) / 10 (mesna 100 MG/ML Injectable Solution) } Pack"
          },
          {
            "code" : "900173",
            "display" : "{2 (60 ML ifosfamide 50 MG/ML Injection) / 6 (mesna 100 MG/ML Injectable Solution) } Pack"
          },
          {
            "code" : "900175",
            "display" : "{5 (20 ML ifosfamide 50 MG/ML Injection) / 3 (mesna 100 MG/ML Injectable Solution) } Pack"
          },
          {
            "code" : "93698",
            "display" : "carboplatin Injectable Solution [Paraplatin]"
          },
          {
            "code" : "968804",
            "display" : "cytarabine liposome"
          }
        ]
      }
    ]
  }
}

```
