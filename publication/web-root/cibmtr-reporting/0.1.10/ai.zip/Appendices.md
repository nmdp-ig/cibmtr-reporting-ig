# Appendices - CIBMTR Reporting Implementation Guide v0.1.10

* [**Table of Contents**](toc.md)
* **Appendices**

## Appendices

### Dependencies










### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (nmdp.fhir.cibmtr-reporting.r4)](package.r4.tgz) and [R4B (nmdp.fhir.cibmtr-reporting.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.4.0/CodeSystem-v3-ucum.html): [Medication/Medication-Cyclophosphamide-Example](Medication-Medication-Cyclophosphamide-Example.md), [Medication/Medication-Etoposide-Example](Medication-Medication-Etoposide-Example.md)... Show 19 more, [Medication/Medication-GVHD-Prophylaxis-Example](Medication-Medication-GVHD-Prophylaxis-Example.md), [Medication/Medication-Mobilizing-Agent-Example](Medication-Medication-Mobilizing-Agent-Example.md), [Medication/Medication-Peri-Transplant-Example](Medication-Medication-Peri-Transplant-Example.md), [Medication/Medication-Post-HCT-Disease-Therapy-Example](Medication-Medication-Post-HCT-Disease-Therapy-Example.md), [Medication/Medication-Prep-Regimen-Example](Medication-Medication-Prep-Regimen-Example.md), [Medication/Medication-PriorExposure-Example](Medication-Medication-PriorExposure-Example.md), [MedicationAdministration/MedicationAdministration-Example1](MedicationAdministration-MedicationAdministration-Example1.md), [MedicationAdministration/MedicationAdministration-Example2](MedicationAdministration-MedicationAdministration-Example2.md), [MedicationRequest/MedicationRequest-Etoposide-Example](MedicationRequest-MedicationRequest-Etoposide-Example.md), [Observation/AlbuminObservation](Observation-AlbuminObservation.md), [Observation/BasophilsObservation](Observation-BasophilsObservation.md), [Observation/BodyHeight](Observation-BodyHeight.md), [Observation/BodyWeight](Observation-BodyWeight.md), [Observation/CMVDNAViralLoadCopiesmL](Observation-CMVDNAViralLoadCopiesmL.md), [Observation/CMVDNAViralLoadIUmL](Observation-CMVDNAViralLoadIUmL.md), [Observation/EosinophilsObservation](Observation-EosinophilsObservation.md), [Observation/HemoglobinObservation](Observation-HemoglobinObservation.md), [Observation/LeukocytesObservation](Observation-LeukocytesObservation.md) and [Observation/NeutrophilsObservation](Observation-NeutrophilsObservation.md)


* The content on the Website including but not limited to the content of ISCN 2020 in whole or in parts, the title, the logo, graphic designs or adverts are the intellectual property of S. Karger AG (Basel) or published with permission from the legal copyright owner. All rights are reserved. Unless otherwise noted, no part of the content on the Website may be translated into other languages, reproduced or utilized in any form or by any means, electronic or mechanical, including photocopying, recording, microcopying, or by any information storage and retrieval system, without permission in writing from Karger.For further information or permission requests please see the explanations under Rights and Permissions ([https://www.karger.com/Services/RightsPermissions)](https://www.karger.com/Services/RightsPermissions)).

* [International System for Human Cytogenomic Nomenclature (ISCN)](http://terminology.hl7.org/6.4.0/CodeSystem-ISCN.html): [Observation/Cytogenetics-Example-1](Observation-Cytogenetics-Example-1.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.4.0/CodeSystem-v3-loinc.html): [AutoDifferentialBloodVS](ValueSet-auto-differential-blood-vs.md), [CBCBloodAutomatedVS](ValueSet-cbc-blood-automated-vs.md)... Show 36 more, [CBCWDifferentialUnspecifiedBloodVS](ValueSet-cbc-w-differential-unspecified-blood-vs.md), [CIBMTRCytogenetics](StructureDefinition-cibmtr-cytogenetics.md), [CIBMTRVitalSignsHeight](StructureDefinition-cibmtr-vital-signs-height.md), [CIBMTRVitalSignsWeight](StructureDefinition-cibmtr-vital-signs-weight.md), [DifferentialUnspecifiedBloodVS](ValueSet-differential-unspecified-blood-vs.md), [ErythrocyteMorphologyBloodVS](ValueSet-erythrocyte-morphology-blood-vs.md), [LeukocyteMorphologyBloodVS](ValueSet-leukocyte-morphology-blood-vs.md), [ManualDifferentialBloodVS](ValueSet-manual-differential-blood-vs.md), [Observation/ABOBloodGroupObservationLOINC](Observation-ABOBloodGroupObservationLOINC.md), [Observation/ABOBloodGroupObservationSNOMED](Observation-ABOBloodGroupObservationSNOMED.md), [Observation/ABORhObservationLOINC](Observation-ABORhObservationLOINC.md), [Observation/ABORhObservationSNOMED](Observation-ABORhObservationSNOMED.md), [Observation/AlbuminObservation](Observation-AlbuminObservation.md), [Observation/BasophilsObservation](Observation-BasophilsObservation.md), [Observation/BodyHeight](Observation-BodyHeight.md), [Observation/BodyWeight](Observation-BodyWeight.md), [Observation/CMVDNAViralLoadCopiesmL](Observation-CMVDNAViralLoadCopiesmL.md), [Observation/CMVDNAViralLoadIUmL](Observation-CMVDNAViralLoadIUmL.md), [Observation/CMVIgAbPresenceSNOMED](Observation-CMVIgAbPresenceSNOMED.md), [Observation/CMVIgGAbPresenceLOINC](Observation-CMVIgGAbPresenceLOINC.md), [Observation/CMVIgMAbPresenceLOINC](Observation-CMVIgMAbPresenceLOINC.md), [Observation/CMVIgMAbPresenceSNOMED](Observation-CMVIgMAbPresenceSNOMED.md), [Observation/Cytogenetics-Example-1](Observation-Cytogenetics-Example-1.md), [Observation/EosinophilsObservation](Observation-EosinophilsObservation.md), [Observation/HemoglobinObservation](Observation-HemoglobinObservation.md), [Observation/LeukocytesObservation](Observation-LeukocytesObservation.md), [Observation/MetamyelocytesObservation](Observation-MetamyelocytesObservation.md), [Observation/NeutrophilsObservation](Observation-NeutrophilsObservation.md), [Patient](ValueSet-patient.md), [PlateletMorphologyBloodVS](ValueSet-platelet-morphology-blood-vs.md), [PresenceValueSet](ValueSet-presence-valueset.md), [PriorityVariables2021](ValueSet-cibmtr-priority-variables-2021.md), [PriorityVariables2022](ValueSet-cibmtr-priority-variables-2022.md), [PriorityVariablesEpic2021](ValueSet-cibmtr-priority-variables-epic-2021.md), [SmearMorphologyBloodVS](ValueSet-smear-morphology-blood-vs.md) and [VitalSigns](ValueSet-vital-signs.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [GVHDSCTVS](ValueSet-gvhd-sct-codes.md), [HematopoieticDisorderVS](ValueSet-hematopoietic-disorder-vs.md)... Show 10 more, [MedicationAdministration/MedicationAdministration-Example1](MedicationAdministration-MedicationAdministration-Example1.md), [MedicationAdministration/MedicationAdministration-Example2](MedicationAdministration-MedicationAdministration-Example2.md), [MedicationRequest/MedicationRequest-Etoposide-Example](MedicationRequest-MedicationRequest-Etoposide-Example.md), [Observation/ABOBloodGroupObservationSNOMED](Observation-ABOBloodGroupObservationSNOMED.md), [Observation/ABORhObservationSNOMED](Observation-ABORhObservationSNOMED.md), [Observation/CMVIgAbPresenceSNOMED](Observation-CMVIgAbPresenceSNOMED.md), [Observation/CMVIgMAbPresenceSNOMED](Observation-CMVIgMAbPresenceSNOMED.md), [Observation/Cytogenetics-Example-1](Observation-Cytogenetics-Example-1.md), [PresenceValueSet](ValueSet-presence-valueset.md) and [SNOMEDMyelodysplasticDiseasesVS](ValueSet-snomed-myelodysplastic-diseases-vs.md)


* Used by permission of HL7 International, all rights reserved Creative Commons License

* [Race & Ethnicity - CDC](http://hl7.org/fhir/us/core/STU4/CodeSystem-cdcrec.html): [Patient/PatientExample3](Patient-PatientExample3.md), [Patient/PatientExample4](Patient-PatientExample4.md) and [Patient/PatientExample5](Patient-PatientExample5.md)


* Using RxNorm codes of type SAB=RXNORM as this specification describes does not require a UMLS license. Access to the full set of RxNorm definitions, and/or additional use of other RxNorm structures and information requires a UMLS license. The use of RxNorm in this specification is pursuant to HL7's status as a licensee of the NLM UMLS. HL7's license does not convey the right to use RxNorm to any users of this specification; implementers must acquire a license to use RxNorm in their own right.

* [RxNorm](http://terminology.hl7.org/6.4.0/CodeSystem-v3-rxNorm.html): [Medication/Medication-Cyclophosphamide-Example](Medication-Medication-Cyclophosphamide-Example.md), [Medication/Medication-Etoposide-Example](Medication-Medication-Etoposide-Example.md)... Show 28 more, [Medication/Medication-GVHD-Prophylaxis-Example](Medication-Medication-GVHD-Prophylaxis-Example.md), [Medication/Medication-Mobilizing-Agent-Example](Medication-Medication-Mobilizing-Agent-Example.md), [Medication/Medication-Peri-Transplant-Example](Medication-Medication-Peri-Transplant-Example.md), [Medication/Medication-Post-HCT-Disease-Therapy-Example](Medication-Medication-Post-HCT-Disease-Therapy-Example.md), [Medication/Medication-Prep-Regimen-Example](Medication-Medication-Prep-Regimen-Example.md), [Medication/Medication-PriorExposure-Example](Medication-Medication-PriorExposure-Example.md), [MedicationAdministration/MedicationAdministration-Example2](MedicationAdministration-MedicationAdministration-Example2.md), [RxNormAdditionalPeriTransplantVS](ValueSet-med-addition-peri-transplant-vs.md), [RxNormAlemtuzumabVS](ValueSet-med-alemtuzumab-vs.md), [RxNormAntiThymocyteGlobulinVS](ValueSet-med-anti-thymocyte-globulin-vs.md), [RxNormBortezomibVS](ValueSet-med-bortezomib-vs.md), [RxNormBusulfanVS](ValueSet-med-busulfan-vs.md), [RxNormCarmustineVS](ValueSet-med-carmustine-vs.md), [RxNormCyclophosphamideVS](ValueSet-med-cyclophosphamide-vs.md), [RxNormCytarabineVS](ValueSet-med-cytarabine-vs.md), [RxNormDefibrotideVS](ValueSet-med-defibrotide-vs.md), [RxNormEtoposideVS](ValueSet-med-etoposide-vs.md), [RxNormFludarabineVS](ValueSet-med-fludarabine-vs.md), [RxNormGVHDProphylaxisVS](ValueSet-med-gvhd-prophylaxis-vs.md), [RxNormMelphalanVS](ValueSet-med-melphalan-vs.md), [RxNormMobilizingAgentsVS](ValueSet-med-mobilizing-agents-vs.md), [RxNormPostHCTDiseaseTherapyPlannedVS](ValueSet-med-post-hct-disease-therapy-planned-vs.md), [RxNormPrepRegimenVS](ValueSet-med-prep-regimen-vs.md), [RxNormPriorExposureVS](ValueSet-med-prior-exposure-vs.md), [RxNormRituximabVS](ValueSet-med-rituximab-vs.md), [RxNormThiotepaVS](ValueSet-med-thiotepa-vs.md), [RxNormTreosulfanVS](ValueSet-med-treosulfan-vs.md) and [RxNormUrsodiolVS](ValueSet-med-ursodiol-vs.md)


