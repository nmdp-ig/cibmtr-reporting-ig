# Home - CIBMTR Reporting Implementation Guide v0.1.10

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ImplementationGuide/nmdp.fhir.cibmtr-reporting | *Version*:0.1.10 |
| Draft as of 2026-05-27 | *Computable Name*:CIBMTRReporting |

> This Implementation Guide is a CIBMTR Standard for Trial Use (STU). It is expected to undergo changes as we learn from experiences with our transplant center partners.

> This Implementation Guide is designed to use the [FHIR Version R4](http://hl7.org/fhir/R4/index.html). For information on submitting to our Direct FHIR endpoints using [FHIR Version STU3](http://hl7.org/fhir/STU3/index.html), see the [Direct FHIR for STU3 Guide](CIBMTR_Direct_FHIR_API_Connection_Guide_STU3.pdf).

This FHIR Implementation Guide (IG) describes how to report transplant-related data to CIBMTR via HL7® FHIR®.

### Introduction

The [Center for International Blood & Marrow Transplant Research® (CIBMTR®)](https://www.cibmtr.org) is a research collaboration between the [National Marrow Donor Program® (NMDP)/Be The Match®](https://bethematch.org) and the [Medical College of Wisconsin (MCW)](https://www.mcw.edu). The CIBMTR collaborates with the global scientific community to advance hematopoietic cell transplantation (HCT) and other cellular therapy worldwide to increase survival and enrich quality of life for patients.

The CIBMTR facilitates critical observational and interventional research through scientific and statistical expertise, a large network of transplant centers, and a unique and extensive clinical outcomes database. CIBMTR collects data for HCT recipients using a web-based manual data entry system ([FormsNet3](https://www.cibmtr.org/DataManagement/SystemApplications/FormsNet3)) and an automated messaging system ([A Growable Network Information System (AGNIS)](https://www.cibmtr.org/DataManagement/SystemApplications/AGNIS/Pages/default.aspx)).

CIBMTR is now collecting data through the [HL7 Fast Healthcare Interoperability Resources® (FHIR®)](http://hl7.org/fhir) standard. This IG describes the technical specification that CIBMTR accepts from third party clients producing FHIR resources for reporting HCT data. It is primarily based on the [US Core FHIR IG](https://www.hl7.org/fhir/us/core/) which defines the minimum conformance requirements for accessing patient data. Profiles from the [minimal Common Oncology Data Elements (mCODE) IG](https://hl7.org/fhir/us/mcode/), which describes the a core set of structured data elements for oncology, are also used.

This IG is focused on information required for sending Patient demographic data that is necessary for creating or retrieving a CIBMTR Research ID (CRID), and for reporting Patient resources with a known CRID. It also includes reporting laboratory observations, focusing on a set of variables that have been identified as a priority for the CIBMTR Data Transformation Initiative in Fiscal Year 2022. And we have begun describing how medication-related resources may be reported, specifically in the context of [CIBMTR Form 2400 (Pre-TED)](https://www.cibmtr.org/manuals/fim/1/en/topic/2400). Future versions of this IG will include other FHIR resources such as Condition, Procedure, Encounter, EpisdoeOfCare, etc.

### Guidance

Guidance on connecting to and sending data to the Direct FHIR API is found in the links below.

* [Connecting and Access](Connection-Guide-R4.md) 
* High-level overview of the recommended workflow to connect to the API
 
* [API Endpoints](Endpoints.md) 
* A table of API endpoint to get access tokens, assign a CRID, and submit FHIR resources to development and production work
 
* [Access Credentials](Access-Credentials.md) 
* Steps to request security tokens necessary for any interaction with the API
 
* [CRID Assignment_FHIR API](CRID-Assignment_FHIR.md) 
* Description of how to assign a CRID for Patient. This uses a FHIR API to submit patient demographic data to CIBMTR.
 
* [Patient](Patient.md) 
* Description of how to send patient information in FHIR resources
 
* [Laboratory Observations](Laboratory-Observations.md) 
* Description of how to send lab values in FHIR Observations.
 
* [Medications](Medications.md) 
* Description of how to send medication-related FHIR resources
 
* [Vital Signs](Vital-Signs.md) 
* Description of how to send vital sign values in FHIR resources
 
* [Bundles](Bundles.md) 
* How to send a FHIR bundle containing multiple FHIR Resources
 
* [Example code](Example-Code.md) 
* Example code, mostly in Python for now
 

### Highlighted Artifacts

#### Profiles

* [CIBMTR Patient](StructureDefinition-cibmtr-patient.md) - derived from US-Core
* [Laboratory Observation Results](StructureDefinition-cibmtr-observation-lab.md) - derived from US-Core 
* [Laboratory Observation for Priority Variables](StructureDefinition-cibmtr-obs-priority-variables.md) - derived from the general CIBMTR lab Observation, but bound to the FY2022 priority ValueSet
 
* Medication-related Profiles 
* [MedicationRequest](StructureDefinition-cibmtr-medication-request.md) - derived from mCode
* [Medication](StructureDefinition-cibmtr-medication.md) - derived from US-Core 
* [Mobilizing Agent Medication](StructureDefinition-cibmtr-mobilizing-agent-medication.md)
* [Preprative Regimen Medications](StructureDefinition-cibmtr-prep-regimen-medication.md)
* [Additional Drugs in Peri-Transplant Period](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.4/expansion/Latest)
* [GVHD Prophylaxis Medication](StructureDefinition-cibmtr-gvhd-prophylaxis-medication.md)
* [Planned Post-HCT Disease Therapy Medication](StructureDefinition-cibmtr-post-hct-disease-therapy-planned-medication.md)
* [Prior Exposure Medication](StructureDefinition-cibmtr-prior-exposure-medication.md)
 
 
* [CIBMTR Vital Signs](StructureDefinition-cibmtr-vital-signs.md) - derived from US-Core 
* [CIBMTR Vital Signs-Height](StructureDefinition-cibmtr-vital-signs-height.md) - derived from US-Core
* [CIBMTR Vital Signs-Weight](StructureDefinition-cibmtr-vital-signs-weight.md) - derived from US-Core
 

#### ValueSets

* Observation Resource 
* Laboratory Observation resource [CIBMTR Priority Variables for FY22](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.7/expansion/Latest)
* Vital Signs Observation resource [Vital Signs Value Set](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.1/expansion/Latest)
 
* Medication Resource 
* [Mobilizing Agents (auto only)](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.2/expansion/Latest)
* [Prep Regimen](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.6/expansion/Latest)
* [Additional Drugs in Peri-Transplant Period](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.4/expansion/Latest)
* [GVHD Prophylaxis](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.8/expansion/Latest)
* [Post-HCT Disease Therapy Planned](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.9/expansion/Latest)
* [Prior Exposure: Potential Study Eligibility](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.10/expansion/Latest)
* [All Form 2400 Medications](https://vsac.nlm.nih.gov/valueset/2.16.840.1.113762.1.4.1295.11/expansion/Latest)
 

