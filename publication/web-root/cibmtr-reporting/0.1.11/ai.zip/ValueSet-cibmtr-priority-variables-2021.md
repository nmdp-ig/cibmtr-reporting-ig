# CIBMTR Priority Variables Value Set (FY21) - CIBMTR Reporting Implementation Guide v0.1.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CIBMTR Priority Variables Value Set (FY21)**

## ValueSet: CIBMTR Priority Variables Value Set (FY21) 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/cibmtr-priority-variables-2021 | *Version*:0.1.11 |
| Draft as of 2026-06-10 | *Computable Name*:PriorityVariables2021 |

 
Priority Variables for CIBMTR (FY21) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Introduction

CIBMTR currently supports submission of lab measurements collected prior to and post-HCT transfusion. When submitting FHIR Observation resources, one of the below supported LOINC codes must be used in the code section of the resource. Selecting the correct LOINC code to use to represent the clinical concept of the lab data should be done by someone clinically trained to understand the lab measurement and corresponding LOINC code. Lab quantities should always include the corresponding unit of measure coded using the UCUM standard vocabulary.

The codes described here represent variables that have been identified as a priority for the CIBMTR Data Transformation Initiative in Fiscal Year 2021. They include codes from LOINC panels describing Complete Blood Count (CBC) (see below) and other codes representing similar concepts but are not found in these panels.

| | |
| :--- | :--- |
| [57782-5](http://details.loinc.org/LOINC/57782-5.html) | CBC W Ordered Manual Differential panel – Blood |
| [57021-8](http://details.loinc.org/LOINC/57021-8.html) | CBC W Auto Differential panel – Blood |
| [69742-5](http://details.loinc.org/LOINC/69742-5.html) | CBC W Differential panel, method unspecified – Blood |

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "cibmtr-priority-variables-2021",
  "url" : "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/cibmtr-priority-variables-2021",
  "version" : "0.1.11",
  "name" : "PriorityVariables2021",
  "title" : "CIBMTR Priority Variables Value Set (FY21)",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-06-10T15:00:38+00:00",
  "publisher" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
  "contact" : [{
    "name" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.cibmtr.org"
    }]
  },
  {
    "name" : "Bob Milius",
    "telecom" : [{
      "system" : "email",
      "value" : "bmilius@nmdp.org"
    }]
  }],
  "description" : "Priority Variables for CIBMTR (FY21)",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "26508-2",
        "display" : "Band form neutrophils/100 leukocytes in Blood"
      },
      {
        "code" : "35332-6",
        "display" : "Band form neutrophils/100 leukocytes in Blood by Automated count"
      },
      {
        "code" : "764-1",
        "display" : "Band form neutrophils/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "30180-4",
        "display" : "Basophils/100 leukocytes in Blood"
      },
      {
        "code" : "706-2",
        "display" : "Basophils/100 leukocytes in Blood by Automated count"
      },
      {
        "code" : "707-0",
        "display" : "Basophils/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "26446-5",
        "display" : "Blasts/100 leukocytes in Blood"
      },
      {
        "code" : "709-6",
        "display" : "Blasts/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "26449-9",
        "display" : "Eosinophils [#/volume] in Blood"
      },
      {
        "code" : "711-2",
        "display" : "Eosinophils [#/volume] in Blood by Automated count"
      },
      {
        "code" : "712-0",
        "display" : "Eosinophils [#/volume] in Blood by Manual count"
      },
      {
        "code" : "26450-7",
        "display" : "Eosinophils/100 leukocytes in Blood"
      },
      {
        "code" : "713-8",
        "display" : "Eosinophils/100 leukocytes in Blood by Automated count"
      },
      {
        "code" : "714-6",
        "display" : "Eosinophils/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "4576-5",
        "display" : "Hemoglobin F/Hemoglobin.total in Blood"
      },
      {
        "code" : "71865-0",
        "display" : "Hemoglobin F/Hemoglobin.total [Pure mass fraction] in Blood by Electrophoresis"
      },
      {
        "code" : "71864-3",
        "display" : "Hemoglobin F/Hemoglobin.total [Pure mass fraction] in Blood by HPLC"
      },
      {
        "code" : "71863-5",
        "display" : "Hemoglobin F/Hemoglobin.total [Pure mass fraction] in Blood by Kleihauer-Betke method"
      },
      {
        "code" : "32682-7",
        "display" : "Hemoglobin F/Hemoglobin.total in Blood by Electrophoresis"
      },
      {
        "code" : "38524-5",
        "display" : "Hemoglobin F/Hemoglobin.total in Blood by Electrophoresis alkaline (pH 8.9)"
      },
      {
        "code" : "42246-9",
        "display" : "Hemoglobin F/Hemoglobin.total in Blood by HPLC"
      },
      {
        "code" : "4633-4",
        "display" : "Hemoglobin F/Hemoglobin.total in Blood by Kleihauer-Betke method"
      },
      {
        "code" : "718-7",
        "display" : "Hemoglobin [Mass/volume] in Blood"
      },
      {
        "code" : "59260-0",
        "display" : "Hemoglobin [Moles/volume] in Blood"
      },
      {
        "code" : "30313-1",
        "display" : "Hemoglobin [Mass/volume] in Arterial blood"
      },
      {
        "code" : "14775-1",
        "display" : "Hemoglobin [Mass/volume] in Arterial blood by Oximetry"
      },
      {
        "code" : "20509-6",
        "display" : "Hemoglobin [Mass/volume] in Blood by calculation"
      },
      {
        "code" : "55782-7",
        "display" : "Hemoglobin [Mass/volume] in Blood by Oximetry"
      },
      {
        "code" : "30351-1",
        "display" : "Hemoglobin [Mass/volume] in Mixed venous blood"
      },
      {
        "code" : "76768-1",
        "display" : "Hemoglobin [Mass/volume] in Mixed venous blood by Oximetry"
      },
      {
        "code" : "30350-3",
        "display" : "Hemoglobin [Mass/volume] in Venous blood"
      },
      {
        "code" : "76769-9",
        "display" : "Hemoglobin [Mass/volume] in Venous blood by Oximetry"
      },
      {
        "code" : "75928-2",
        "display" : "Hemoglobin [Moles/volume] in Arterial blood"
      },
      {
        "code" : "93846-4",
        "display" : "Hemoglobin [Moles/volume] in Venous blood"
      },
      {
        "code" : "20570-8",
        "display" : "Hematocrit [Volume Fraction] of Blood"
      },
      {
        "code" : "71833-8",
        "display" : "Hematocrit [Pure volume fraction] of Blood by Automated count"
      },
      {
        "code" : "71831-2",
        "display" : "Hematocrit [Pure volume fraction] of Capillary blood"
      },
      {
        "code" : "71829-6",
        "display" : "Hematocrit [Pure volume fraction] of Venous blood"
      },
      {
        "code" : "4544-3",
        "display" : "Hematocrit [Volume Fraction] of Blood by Automated count"
      },
      {
        "code" : "4545-0",
        "display" : "Hematocrit [Volume Fraction] of Blood by Centrifugation"
      },
      {
        "code" : "48703-3",
        "display" : "Hematocrit [Volume Fraction] of Blood by Estimated"
      },
      {
        "code" : "31100-1",
        "display" : "Hematocrit [Volume Fraction] of Blood by Impedance"
      },
      {
        "code" : "42908-4",
        "display" : "Hematocrit [Volume Fraction] of Capillary blood"
      },
      {
        "code" : "41654-5",
        "display" : "Hematocrit [Volume Fraction] of Venous blood"
      },
      {
        "code" : "26474-7",
        "display" : "Lymphocytes [#/volume] in Blood"
      },
      {
        "code" : "731-0",
        "display" : "Lymphocytes [#/volume] in Blood by Automated count"
      },
      {
        "code" : "732-8",
        "display" : "Lymphocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "26478-8",
        "display" : "Lymphocytes/100 leukocytes in Blood"
      },
      {
        "code" : "736-9",
        "display" : "Lymphocytes/100 leukocytes in Blood by Automated count"
      },
      {
        "code" : "737-7",
        "display" : "Lymphocytes/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "30433-7",
        "display" : "Metamyelocytes [#/volume] in Blood"
      },
      {
        "code" : "739-3",
        "display" : "Metamyelocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "28541-1",
        "display" : "Metamyelocytes/100 leukocytes in Blood"
      },
      {
        "code" : "740-1",
        "display" : "Metamyelocytes/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "71668-8",
        "display" : "Metamyelocytes/Leukocytes [Pure number fraction] in Blood by Manual count"
      },
      {
        "code" : "40651-2",
        "display" : "Metamyelocytes [Presence] in Blood"
      },
      {
        "code" : "26484-6",
        "display" : "Monocytes [#/volume] in Blood"
      },
      {
        "code" : "742-7",
        "display" : "Monocytes [#/volume] in Blood by Automated count"
      },
      {
        "code" : "743-5",
        "display" : "Monocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "26485-3",
        "display" : "Monocytes/100 leukocytes in Blood"
      },
      {
        "code" : "5905-5",
        "display" : "Monocytes/100 leukocytes in Blood by Automated count"
      },
      {
        "code" : "744-3",
        "display" : "Monocytes/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "30444-4",
        "display" : "Myeloblasts [#/volume] in Blood"
      },
      {
        "code" : "746-8",
        "display" : "Myeloblasts [#/volume] in Blood by Manual count"
      },
      {
        "code" : "30445-1",
        "display" : "Myeloblasts/100 leukocytes in Blood"
      },
      {
        "code" : "747-6",
        "display" : "Myeloblasts/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "30446-9",
        "display" : "Myelocytes [#/volume] in Blood"
      },
      {
        "code" : "748-4",
        "display" : "Myelocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "26498-6",
        "display" : "Myelocytes/100 leukocytes in Blood"
      },
      {
        "code" : "749-2",
        "display" : "Myelocytes/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "71667-0",
        "display" : "Myelocytes/Leukocytes [Pure number fraction] in Blood by Manual count"
      },
      {
        "code" : "26499-4",
        "display" : "Neutrophils [#/volume] in Blood"
      },
      {
        "code" : "751-8",
        "display" : "Neutrophils [#/volume] in Blood by Automated count"
      },
      {
        "code" : "753-4",
        "display" : "Neutrophils [#/volume] in Blood by Manual count"
      },
      {
        "code" : "26511-6",
        "display" : "Neutrophils/100 leukocytes in Blood"
      },
      {
        "code" : "770-8",
        "display" : "Neutrophils/100 leukocytes in Blood by Automated count"
      },
      {
        "code" : "23761-0",
        "display" : "Neutrophils/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "30458-4",
        "display" : "Plasma cells [#/volume] in Blood"
      },
      {
        "code" : "24103-4",
        "display" : "Plasma cells [#/volume] in Blood by Manual count"
      },
      {
        "code" : "13047-6",
        "display" : "Plasma cells/100 leukocytes in Blood"
      },
      {
        "code" : "79426-3",
        "display" : "Plasma cells/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "28542-9",
        "display" : "Platelet mean volume [Entitic volume] in Blood"
      },
      {
        "code" : "32623-1",
        "display" : "Platelet mean volume [Entitic volume] in Blood by Automated count"
      },
      {
        "code" : "26515-7",
        "display" : "Platelets [#/volume] in Blood"
      },
      {
        "code" : "777-3",
        "display" : "Platelets [#/volume] in Blood by Automated count"
      },
      {
        "code" : "49497-1",
        "display" : "Platelets [#/volume] in Blood by Estimate"
      },
      {
        "code" : "778-1",
        "display" : "Platelets [#/volume] in Blood by Manual count"
      },
      {
        "code" : "30465-9",
        "display" : "Prolymphocytes/100 leukocytes in Blood"
      },
      {
        "code" : "6746-2",
        "display" : "Prolymphocytes/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "34926-6",
        "display" : "Promonocytes [#/volume] in Blood"
      },
      {
        "code" : "33855-8",
        "display" : "Promonocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "30466-7",
        "display" : "Promonocytes/100 leukocytes in Blood"
      },
      {
        "code" : "13599-6",
        "display" : "Promonocytes/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "26523-1",
        "display" : "Promyelocytes [#/volume] in Blood"
      },
      {
        "code" : "781-5",
        "display" : "Promyelocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "26524-9",
        "display" : "Promyelocytes/100 leukocytes in Blood"
      },
      {
        "code" : "783-1",
        "display" : "Promyelocytes/100 leukocytes in Blood by Manual count"
      },
      {
        "code" : "71666-2",
        "display" : "Promyelocytes/Leukocytes [Pure number fraction] in Blood by Manual count"
      },
      {
        "code" : "26453-1",
        "display" : "Erythrocytes [#/volume] in Blood"
      },
      {
        "code" : "789-8",
        "display" : "Erythrocytes [#/volume] in Blood by Automated count"
      },
      {
        "code" : "790-6",
        "display" : "Erythrocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "14196-0",
        "display" : "Reticulocytes [#/volume] in Blood"
      },
      {
        "code" : "60474-4",
        "display" : "Reticulocytes [#/volume] in Blood by Automated count"
      },
      {
        "code" : "40665-2",
        "display" : "Reticulocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "26464-8",
        "display" : "Leukocytes [#/volume] in Blood"
      },
      {
        "code" : "6690-2",
        "display" : "Leukocytes [#/volume] in Blood by Automated count"
      },
      {
        "code" : "49498-9",
        "display" : "Leukocytes [#/volume] in Blood by Estimate"
      },
      {
        "code" : "804-5",
        "display" : "Leukocytes [#/volume] in Blood by Manual count"
      },
      {
        "code" : "1751-7",
        "display" : "Albumin [Mass/volume] in Serum or Plasma"
      },
      {
        "code" : "61151-7",
        "display" : "Albumin [Mass/volume] in Serum or Plasma by Bromocresol green (BCG) dye binding method"
      },
      {
        "code" : "61152-5",
        "display" : "Albumin [Mass/volume] in Serum or Plasma by Bromocresol purple (BCP) dye binding method"
      },
      {
        "code" : "2862-1",
        "display" : "Albumin [Mass/volume] in Serum or Plasma by Electrophoresis"
      },
      {
        "code" : "24373-3",
        "display" : "Ferritin [Mass/volume] in Blood"
      },
      {
        "code" : "2276-4",
        "display" : "Ferritin [Mass/volume] in Serum or Plasma"
      },
      {
        "code" : "20567-4",
        "display" : "Ferritin [Mass/volume] in Serum or Plasma by Immunoassay"
      },
      {
        "code" : "11150-0",
        "display" : "Blasts/100 cells in Bone marrow"
      },
      {
        "code" : "26505-8",
        "display" : "Segmented neutrophils/100 leukocytes in Blood"
      },
      {
        "code" : "32200-8",
        "display" : "Segmented neutrophils/100 leukocytes in Blood by Automated count"
      },
      {
        "code" : "769-0",
        "display" : "Segmented neutrophils/100 leukocytes in Blood by Manual count"
      }]
    }]
  }
}

```
