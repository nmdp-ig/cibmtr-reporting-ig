# RxNorm - Mobilizing Agents (auto only) - CIBMTR Reporting Implementation Guide v0.1.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RxNorm - Mobilizing Agents (auto only)**

## ValueSet: RxNorm - Mobilizing Agents (auto only) (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/med-mobilizing-agents-vs | *Version*:0.1.11 |
| Draft as of 2026-06-10 | *Computable Name*:RxNormMobilizingAgentsVS |

 
RxNorm codes for Mobilizing Agents (auto only) 

 **References** 

* Included into [RxNormAll2400VS](ValueSet-med-all-form2400-vs.md)
* [CIBMTR Mobilizing Agents Medication](StructureDefinition-cibmtr-mobilizing-agent-medication.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "med-mobilizing-agents-vs",
  "url" : "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/med-mobilizing-agents-vs",
  "version" : "0.1.11",
  "name" : "RxNormMobilizingAgentsVS",
  "title" : "RxNorm - Mobilizing Agents (auto only)",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-06-10T15:00:38+00:00",
  "publisher" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
  "contact" : [{
    "name" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.cibmtr.org"
    }]
  },
  {
    "name" : "Bob Milius",
    "telecom" : [{
      "system" : "email",
      "value" : "bmilius@nmdp.org"
    }]
  }],
  "description" : "RxNorm codes for Mobilizing Agents (auto only)",
  "compose" : {
    "include" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "concept" : [{
        "code" : "1157967",
        "display" : "rituximab Injectable Product"
      },
      {
        "code" : "1159651",
        "display" : "filgrastim Injectable Product"
      },
      {
        "code" : "1159878",
        "display" : "plerixafor Injectable Product"
      },
      {
        "code" : "1161380",
        "display" : "pegfilgrastim Injectable Product"
      },
      {
        "code" : "1162571",
        "display" : "lenograstim Injectable Product"
      },
      {
        "code" : "1182279",
        "display" : "Neulasta Injectable Product"
      },
      {
        "code" : "1182281",
        "display" : "Neupogen Injectable Product"
      },
      {
        "code" : "1183314",
        "display" : "Mozobil Injectable Product"
      },
      {
        "code" : "1185345",
        "display" : "Rituxan Injectable Product"
      },
      {
        "code" : "121191",
        "display" : "rituximab"
      },
      {
        "code" : "1433764",
        "display" : "tbo-filgrastim"
      },
      {
        "code" : "1433765",
        "display" : "tbo-filgrastim 0.6 MG/ML"
      },
      {
        "code" : "1433768",
        "display" : "0.5 ML tbo-filgrastim 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "1433771",
        "display" : "0.8 ML tbo-filgrastim 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "1440046",
        "display" : "lipegfilgrastim"
      },
      {
        "code" : "1442677",
        "display" : "Granix"
      },
      {
        "code" : "1442678",
        "display" : "tbo-filgrastim 0.6 MG/ML [Granix]"
      },
      {
        "code" : "1442679",
        "display" : "filgrastim Prefilled Syringe [Granix]"
      },
      {
        "code" : "1442680",
        "display" : "Granix Injectable Product"
      },
      {
        "code" : "1442681",
        "display" : "0.5 ML tbo-filgrastim 0.6 MG/ML Prefilled Syringe [Granix]"
      },
      {
        "code" : "1442683",
        "display" : "0.8 ML tbo-filgrastim 0.6 MG/ML Prefilled Syringe [Granix]"
      },
      {
        "code" : "1605064",
        "display" : "filgrastim-sndz"
      },
      {
        "code" : "1605065",
        "display" : "filgrastim-sndz 0.6 MG/ML"
      },
      {
        "code" : "1605066",
        "display" : "0.5 ML filgrastim-sndz 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "1605067",
        "display" : "Zarxio"
      },
      {
        "code" : "1605068",
        "display" : "filgrastim-sndz 0.6 MG/ML [Zarxio]"
      },
      {
        "code" : "1605069",
        "display" : "filgrastim Prefilled Syringe [Zarxio]"
      },
      {
        "code" : "1605070",
        "display" : "Zarxio Injectable Product"
      },
      {
        "code" : "1605071",
        "display" : "0.5 ML filgrastim-sndz 0.6 MG/ML Prefilled Syringe [Zarxio]"
      },
      {
        "code" : "1605074",
        "display" : "0.8 ML filgrastim-sndz 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "1605075",
        "display" : "0.8 ML filgrastim-sndz 0.6 MG/ML Prefilled Syringe [Zarxio]"
      },
      {
        "code" : "1649943",
        "display" : "filgrastim Injection"
      },
      {
        "code" : "1649944",
        "display" : "1 ML filgrastim 0.3 MG/ML Injection"
      },
      {
        "code" : "1649945",
        "display" : "filgrastim Injection [Neupogen]"
      },
      {
        "code" : "1649946",
        "display" : "1 ML filgrastim 0.3 MG/ML Injection [Neupogen]"
      },
      {
        "code" : "1649963",
        "display" : "1.6 ML filgrastim 0.3 MG/ML Injection"
      },
      {
        "code" : "1649964",
        "display" : "1.6 ML filgrastim 0.3 MG/ML Injection [Neupogen]"
      },
      {
        "code" : "1657861",
        "display" : "rituximab Injection"
      },
      {
        "code" : "1657862",
        "display" : "10 ML rituximab 10 MG/ML Injection"
      },
      {
        "code" : "1657863",
        "display" : "rituximab Injection [Rituxan]"
      },
      {
        "code" : "1657864",
        "display" : "10 ML rituximab 10 MG/ML Injection [Rituxan]"
      },
      {
        "code" : "1657867",
        "display" : "50 ML rituximab 10 MG/ML Injection"
      },
      {
        "code" : "1657868",
        "display" : "50 ML rituximab 10 MG/ML Injection [Rituxan]"
      },
      {
        "code" : "1746487",
        "display" : "pegbovigrastim"
      },
      {
        "code" : "1794537",
        "display" : "plerixafor Injection"
      },
      {
        "code" : "1794539",
        "display" : "plerixafor Injection [Mozobil]"
      },
      {
        "code" : "1927881",
        "display" : "rituximab 120 MG/ML"
      },
      {
        "code" : "1927882",
        "display" : "hyaluronidase / rituximab Injectable Product"
      },
      {
        "code" : "1927883",
        "display" : "hyaluronidase / rituximab Injection"
      },
      {
        "code" : "1927884",
        "display" : "hyaluronidase / rituximab"
      },
      {
        "code" : "1927885",
        "display" : "11.7 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection"
      },
      {
        "code" : "1927886",
        "display" : "Rituxan Hycela"
      },
      {
        "code" : "1927887",
        "display" : "hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML [Rituxan Hycela]"
      },
      {
        "code" : "1927888",
        "display" : "hyaluronidase / rituximab Injection [Rituxan Hycela]"
      },
      {
        "code" : "1927889",
        "display" : "Rituxan Hycela Injectable Product"
      },
      {
        "code" : "1927890",
        "display" : "11.7 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection [Rituxan Hycela]"
      },
      {
        "code" : "1927893",
        "display" : "13.4 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection"
      },
      {
        "code" : "1927894",
        "display" : "13.4 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection [Rituxan Hycela]"
      },
      {
        "code" : "2048018",
        "display" : "pegfilgrastim-jmdb"
      },
      {
        "code" : "2048019",
        "display" : "pegfilgrastim-jmdb 10 MG/ML"
      },
      {
        "code" : "2048020",
        "display" : "0.6 ML pegfilgrastim-jmdb 10 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2048021",
        "display" : "Fulphila"
      },
      {
        "code" : "2048022",
        "display" : "pegfilgrastim-jmdb 10 MG/ML [Fulphila]"
      },
      {
        "code" : "2048023",
        "display" : "pegfilgrastim Prefilled Syringe [Fulphila]"
      },
      {
        "code" : "2048024",
        "display" : "Fulphila Injectable Product"
      },
      {
        "code" : "2048025",
        "display" : "0.6 ML pegfilgrastim-jmdb 10 MG/ML Prefilled Syringe [Fulphila]"
      },
      {
        "code" : "2057198",
        "display" : "filgrastim-aafi"
      },
      {
        "code" : "2057199",
        "display" : "filgrastim-aafi 0.6 MG/ML"
      },
      {
        "code" : "2057200",
        "display" : "0.5 ML filgrastim-aafi 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2057201",
        "display" : "Nivestym"
      },
      {
        "code" : "2057202",
        "display" : "filgrastim-aafi 0.6 MG/ML [Nivestym]"
      },
      {
        "code" : "2057203",
        "display" : "filgrastim Prefilled Syringe [Nivestym]"
      },
      {
        "code" : "2057204",
        "display" : "Nivestym Injectable Product"
      },
      {
        "code" : "2057205",
        "display" : "0.5 ML filgrastim-aafi 0.6 MG/ML Prefilled Syringe [Nivestym]"
      },
      {
        "code" : "2057208",
        "display" : "filgrastim-aafi 0.3 MG/ML"
      },
      {
        "code" : "2057209",
        "display" : "1 ML filgrastim-aafi 0.3 MG/ML Injection"
      },
      {
        "code" : "2057210",
        "display" : "filgrastim-aafi 0.3 MG/ML [Nivestym]"
      },
      {
        "code" : "2057211",
        "display" : "filgrastim Injection [Nivestym]"
      },
      {
        "code" : "2057212",
        "display" : "1 ML filgrastim-aafi 0.3 MG/ML Injection [Nivestym]"
      },
      {
        "code" : "2057215",
        "display" : "0.8 ML filgrastim-aafi 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2057216",
        "display" : "0.8 ML filgrastim-aafi 0.6 MG/ML Prefilled Syringe [Nivestym]"
      },
      {
        "code" : "2057218",
        "display" : "1.6 ML filgrastim-aafi 0.3 MG/ML Injection"
      },
      {
        "code" : "2057219",
        "display" : "1.6 ML filgrastim-aafi 0.3 MG/ML Injection [Nivestym]"
      },
      {
        "code" : "2101455",
        "display" : "tbo-filgrastim 0.3 MG/ML"
      },
      {
        "code" : "2101456",
        "display" : "1 ML tbo-filgrastim 0.3 MG/ML Injection"
      },
      {
        "code" : "2101457",
        "display" : "tbo-filgrastim 0.3 MG/ML [Granix]"
      },
      {
        "code" : "2101458",
        "display" : "filgrastim Injection [Granix]"
      },
      {
        "code" : "2101459",
        "display" : "1 ML tbo-filgrastim 0.3 MG/ML Injection [Granix]"
      },
      {
        "code" : "2101464",
        "display" : "1.6 ML tbo-filgrastim 0.3 MG/ML Injection"
      },
      {
        "code" : "2101465",
        "display" : "1.6 ML tbo-filgrastim 0.3 MG/ML Injection [Granix]"
      },
      {
        "code" : "2102692",
        "display" : "pegfilgrastim-cbqv"
      },
      {
        "code" : "2102695",
        "display" : "Udenyca"
      },
      {
        "code" : "2102697",
        "display" : "pegfilgrastim Prefilled Syringe [Udenyca]"
      },
      {
        "code" : "2102698",
        "display" : "Udenyca Injectable Product"
      },
      {
        "code" : "2102702",
        "display" : "pegfilgrastim-cbqv 10 MG/ML"
      },
      {
        "code" : "2102703",
        "display" : "0.6 ML pegfilgrastim-cbqv 10 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2102704",
        "display" : "pegfilgrastim-cbqv 10 MG/ML [Udenyca]"
      },
      {
        "code" : "2102705",
        "display" : "0.6 ML pegfilgrastim-cbqv 10 MG/ML Prefilled Syringe [Udenyca]"
      },
      {
        "code" : "2105824",
        "display" : "rituximab-abbs"
      },
      {
        "code" : "2105825",
        "display" : "rituximab-abbs 10 MG/ML"
      },
      {
        "code" : "2105826",
        "display" : "10 ML rituximab-abbs 10 MG/ML Injection"
      },
      {
        "code" : "2105827",
        "display" : "Truxima"
      },
      {
        "code" : "2105828",
        "display" : "rituximab-abbs 10 MG/ML [Truxima]"
      },
      {
        "code" : "2105829",
        "display" : "rituximab Injection [Truxima]"
      },
      {
        "code" : "2105830",
        "display" : "Truxima Injectable Product"
      },
      {
        "code" : "2105831",
        "display" : "10 ML rituximab-abbs 10 MG/ML Injection [Truxima]"
      },
      {
        "code" : "2105834",
        "display" : "50 ML rituximab-abbs 10 MG/ML Injection"
      },
      {
        "code" : "2105835",
        "display" : "50 ML rituximab-abbs 10 MG/ML Injection [Truxima]"
      },
      {
        "code" : "2260702",
        "display" : "pegfilgrastim-bmez"
      },
      {
        "code" : "2260703",
        "display" : "pegfilgrastim-bmez 10 MG/ML"
      },
      {
        "code" : "2260704",
        "display" : "0.6 ML pegfilgrastim-bmez 10 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2260705",
        "display" : "Ziextenzo"
      },
      {
        "code" : "2260706",
        "display" : "pegfilgrastim-bmez 10 MG/ML [Ziextenzo]"
      },
      {
        "code" : "2260707",
        "display" : "pegfilgrastim Prefilled Syringe [Ziextenzo]"
      },
      {
        "code" : "2260708",
        "display" : "Ziextenzo Injectable Product"
      },
      {
        "code" : "2260709",
        "display" : "0.6 ML pegfilgrastim-bmez 10 MG/ML Prefilled Syringe [Ziextenzo]"
      },
      {
        "code" : "226754",
        "display" : "Rituxan"
      },
      {
        "code" : "227304",
        "display" : "Neupogen"
      },
      {
        "code" : "2273510",
        "display" : "rituximab-pvvr"
      },
      {
        "code" : "2273511",
        "display" : "rituximab-pvvr 10 MG/ML"
      },
      {
        "code" : "2273512",
        "display" : "10 ML rituximab-pvvr 10 MG/ML Injection"
      },
      {
        "code" : "2273513",
        "display" : "Ruxience"
      },
      {
        "code" : "2273514",
        "display" : "rituximab-pvvr 10 MG/ML [Ruxience]"
      },
      {
        "code" : "2273515",
        "display" : "rituximab Injection [Ruxience]"
      },
      {
        "code" : "2273516",
        "display" : "Ruxience Injectable Product"
      },
      {
        "code" : "2273517",
        "display" : "10 ML rituximab-pvvr 10 MG/ML Injection [Ruxience]"
      },
      {
        "code" : "2273520",
        "display" : "50 ML rituximab-pvvr 10 MG/ML Injection"
      },
      {
        "code" : "2273521",
        "display" : "50 ML rituximab-pvvr 10 MG/ML Injection [Ruxience]"
      },
      {
        "code" : "2469333",
        "display" : "pegfilgrastim-apgf"
      },
      {
        "code" : "2469334",
        "display" : "pegfilgrastim-apgf 10 MG/ML"
      },
      {
        "code" : "2469335",
        "display" : "0.6 ML pegfilgrastim-apgf 10 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2469336",
        "display" : "Nyvepria"
      },
      {
        "code" : "2469337",
        "display" : "pegfilgrastim-apgf 10 MG/ML [Nyvepria]"
      },
      {
        "code" : "2469338",
        "display" : "pegfilgrastim Prefilled Syringe [Nyvepria]"
      },
      {
        "code" : "2469339",
        "display" : "Nyvepria Injectable Product"
      },
      {
        "code" : "2469340",
        "display" : "0.6 ML pegfilgrastim-apgf 10 MG/ML Prefilled Syringe [Nyvepria]"
      },
      {
        "code" : "2472325",
        "display" : "rituximab-arrx"
      },
      {
        "code" : "2472326",
        "display" : "rituximab-arrx 10 MG/ML"
      },
      {
        "code" : "2472327",
        "display" : "10 ML rituximab-arrx 10 MG/ML Injection"
      },
      {
        "code" : "2472328",
        "display" : "Riabni"
      },
      {
        "code" : "2472329",
        "display" : "rituximab-arrx 10 MG/ML [Riabni]"
      },
      {
        "code" : "2472330",
        "display" : "rituximab Injection [Riabni]"
      },
      {
        "code" : "2472331",
        "display" : "Riabni Injectable Product"
      },
      {
        "code" : "2472332",
        "display" : "10 ML rituximab-arrx 10 MG/ML Injection [Riabni]"
      },
      {
        "code" : "2472335",
        "display" : "50 ML rituximab-arrx 10 MG/ML Injection"
      },
      {
        "code" : "2472336",
        "display" : "50 ML rituximab-arrx 10 MG/ML Injection [Riabni]"
      },
      {
        "code" : "2549330",
        "display" : "pegfilgrastim Injection"
      },
      {
        "code" : "2549331",
        "display" : "0.6 ML pegfilgrastim 10 MG/ML Injection"
      },
      {
        "code" : "2549332",
        "display" : "pegfilgrastim Injection [Neulasta]"
      },
      {
        "code" : "2549333",
        "display" : "0.6 ML pegfilgrastim 10 MG/ML Injection [Neulasta]"
      },
      {
        "code" : "2595942",
        "display" : "filgrastim-ayow"
      },
      {
        "code" : "2595943",
        "display" : "filgrastim-ayow 0.6 MG/ML"
      },
      {
        "code" : "2595944",
        "display" : "0.5 ML filgrastim-ayow 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2595946",
        "display" : "Releuko"
      },
      {
        "code" : "2595947",
        "display" : "filgrastim-ayow 0.6 MG/ML [Releuko]"
      },
      {
        "code" : "2595948",
        "display" : "Releuko Injectable Product"
      },
      {
        "code" : "2595949",
        "display" : "filgrastim Prefilled Syringe [Releuko]"
      },
      {
        "code" : "2595950",
        "display" : "0.5 ML filgrastim-ayow 0.6 MG/ML Prefilled Syringe [Releuko]"
      },
      {
        "code" : "2595952",
        "display" : "filgrastim-ayow 0.3 MG/ML"
      },
      {
        "code" : "2595953",
        "display" : "1 ML filgrastim-ayow 0.3 MG/ML Injection"
      },
      {
        "code" : "2595955",
        "display" : "filgrastim-ayow 0.3 MG/ML [Releuko]"
      },
      {
        "code" : "2595956",
        "display" : "filgrastim Injection [Releuko]"
      },
      {
        "code" : "2595957",
        "display" : "1 ML filgrastim-ayow 0.3 MG/ML Injection [Releuko]"
      },
      {
        "code" : "2595959",
        "display" : "1.6 ML filgrastim-ayow 0.3 MG/ML Injection"
      },
      {
        "code" : "2595960",
        "display" : "1.6 ML filgrastim-ayow 0.3 MG/ML Injection [Releuko]"
      },
      {
        "code" : "2595961",
        "display" : "0.8 ML filgrastim-ayow 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2595962",
        "display" : "0.8 ML filgrastim-ayow 0.6 MG/ML Prefilled Syringe [Releuko]"
      },
      {
        "code" : "2602779",
        "display" : "pegfilgrastim-pbbk"
      },
      {
        "code" : "2602780",
        "display" : "pegfilgrastim-pbbk 10 MG/ML"
      },
      {
        "code" : "2602781",
        "display" : "0.6 ML pegfilgrastim-pbbk 10 MG/ML Prefilled Syringe"
      },
      {
        "code" : "2602783",
        "display" : "Fylnetra"
      },
      {
        "code" : "2602784",
        "display" : "pegfilgrastim-pbbk 10 MG/ML [Fylnetra]"
      },
      {
        "code" : "2602785",
        "display" : "Fylnetra Injectable Product"
      },
      {
        "code" : "2602786",
        "display" : "pegfilgrastim Prefilled Syringe [Fylnetra]"
      },
      {
        "code" : "2602787",
        "display" : "0.6 ML pegfilgrastim-pbbk 10 MG/ML Prefilled Syringe [Fylnetra]"
      },
      {
        "code" : "315932",
        "display" : "filgrastim 0.3 MG/ML"
      },
      {
        "code" : "316648",
        "display" : "rituximab 10 MG/ML"
      },
      {
        "code" : "331527",
        "display" : "filgrastim 0.6 MG/ML"
      },
      {
        "code" : "338036",
        "display" : "pegfilgrastim"
      },
      {
        "code" : "350977",
        "display" : "pegfilgrastim 10 MG/ML"
      },
      {
        "code" : "353501",
        "display" : "Neulasta"
      },
      {
        "code" : "567845",
        "display" : "filgrastim 0.3 MG/ML [Neupogen]"
      },
      {
        "code" : "573051",
        "display" : "rituximab 10 MG/ML [Rituxan]"
      },
      {
        "code" : "574887",
        "display" : "filgrastim 0.6 MG/ML [Neupogen]"
      },
      {
        "code" : "575870",
        "display" : "pegfilgrastim 10 MG/ML [Neulasta]"
      },
      {
        "code" : "68442",
        "display" : "filgrastim"
      },
      {
        "code" : "70167",
        "display" : "lenograstim"
      },
      {
        "code" : "727534",
        "display" : "filgrastim Prefilled Syringe"
      },
      {
        "code" : "727535",
        "display" : "0.5 ML filgrastim 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "727536",
        "display" : "filgrastim Prefilled Syringe [Neupogen]"
      },
      {
        "code" : "727537",
        "display" : "0.5 ML filgrastim 0.6 MG/ML Prefilled Syringe [Neupogen]"
      },
      {
        "code" : "727538",
        "display" : "pegfilgrastim Prefilled Syringe"
      },
      {
        "code" : "727539",
        "display" : "0.6 ML pegfilgrastim 10 MG/ML Prefilled Syringe"
      },
      {
        "code" : "727541",
        "display" : "pegfilgrastim Prefilled Syringe [Neulasta]"
      },
      {
        "code" : "727542",
        "display" : "0.6 ML pegfilgrastim 10 MG/ML Prefilled Syringe [Neulasta]"
      },
      {
        "code" : "727544",
        "display" : "0.8 ML filgrastim 0.6 MG/ML Prefilled Syringe"
      },
      {
        "code" : "727545",
        "display" : "0.8 ML filgrastim 0.6 MG/ML Prefilled Syringe [Neupogen]"
      },
      {
        "code" : "733003",
        "display" : "plerixafor"
      },
      {
        "code" : "735381",
        "display" : "Mozobil"
      },
      {
        "code" : "828698",
        "display" : "plerixafor 20 MG/ML"
      },
      {
        "code" : "828700",
        "display" : "1.2 ML plerixafor 20 MG/ML Injection"
      },
      {
        "code" : "828701",
        "display" : "plerixafor 20 MG/ML [Mozobil]"
      },
      {
        "code" : "828703",
        "display" : "1.2 ML plerixafor 20 MG/ML Injection [Mozobil]"
      }]
    }]
  }
}

```
