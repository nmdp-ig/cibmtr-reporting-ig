# RxNorm - Post-HCT Disease Therapy Planned - CIBMTR Reporting Implementation Guide v0.1.11

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RxNorm - Post-HCT Disease Therapy Planned**

## ValueSet: RxNorm - Post-HCT Disease Therapy Planned (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/med-post-hct-disease-therapy-planned-vs | *Version*:0.1.11 |
| Draft as of 2026-06-10 | *Computable Name*:RxNormPostHCTDiseaseTherapyPlannedVS |

 
RxNorm codes for Post-HCT Disease Therapy Planned 

 **References** 

* Included into [RxNormAll2400VS](ValueSet-med-all-form2400-vs.md)
* [CIBMTR Planned Post-HCT Disease Therapy Medication](StructureDefinition-cibmtr-post-hct-disease-therapy-planned-medication.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "med-post-hct-disease-therapy-planned-vs",
  "url" : "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/med-post-hct-disease-therapy-planned-vs",
  "version" : "0.1.11",
  "name" : "RxNormPostHCTDiseaseTherapyPlannedVS",
  "title" : "RxNorm - Post-HCT Disease Therapy Planned",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-06-10T15:00:38+00:00",
  "publisher" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
  "contact" : [{
    "name" : "The Medical College of Wisconsin, Inc. and the National Marrow Donor Program",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.cibmtr.org"
    }]
  },
  {
    "name" : "Bob Milius",
    "telecom" : [{
      "system" : "email",
      "value" : "bmilius@nmdp.org"
    }]
  }],
  "description" : "RxNorm codes for Post-HCT Disease Therapy Planned",
  "compose" : {
    "include" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "concept" : [{
        "code" : "10432",
        "display" : "thalidomide"
      },
      {
        "code" : "1045401",
        "display" : "dasatinib 140 MG"
      },
      {
        "code" : "1045402",
        "display" : "dasatinib 140 MG Oral Tablet"
      },
      {
        "code" : "1045403",
        "display" : "dasatinib 140 MG [Sprycel]"
      },
      {
        "code" : "1045404",
        "display" : "dasatinib 140 MG Oral Tablet [Sprycel]"
      },
      {
        "code" : "1045405",
        "display" : "dasatinib 80 MG"
      },
      {
        "code" : "1045406",
        "display" : "dasatinib 80 MG Oral Tablet"
      },
      {
        "code" : "1045407",
        "display" : "dasatinib 80 MG [Sprycel]"
      },
      {
        "code" : "1045408",
        "display" : "dasatinib 80 MG Oral Tablet [Sprycel]"
      },
      {
        "code" : "1147320",
        "display" : "brentuximab vedotin"
      },
      {
        "code" : "1147323",
        "display" : "brentuximab vedotin 50 MG Injection"
      },
      {
        "code" : "1147324",
        "display" : "Adcetris"
      },
      {
        "code" : "1147327",
        "display" : "brentuximab vedotin 50 MG Injection [Adcetris]"
      },
      {
        "code" : "1154999",
        "display" : "azacitidine Injectable Product"
      },
      {
        "code" : "1157186",
        "display" : "dasatinib Oral Product"
      },
      {
        "code" : "1157187",
        "display" : "dasatinib Pill"
      },
      {
        "code" : "1157195",
        "display" : "decitabine Injectable Product"
      },
      {
        "code" : "1157967",
        "display" : "rituximab Injectable Product"
      },
      {
        "code" : "1159691",
        "display" : "sorafenib Oral Product"
      },
      {
        "code" : "1159692",
        "display" : "sorafenib Pill"
      },
      {
        "code" : "1160679",
        "display" : "imatinib Oral Product"
      },
      {
        "code" : "1160680",
        "display" : "imatinib Pill"
      },
      {
        "code" : "1160852",
        "display" : "sunitinib Oral Product"
      },
      {
        "code" : "1160853",
        "display" : "sunitinib Pill"
      },
      {
        "code" : "1162569",
        "display" : "lenalidomide Oral Product"
      },
      {
        "code" : "1162570",
        "display" : "lenalidomide Pill"
      },
      {
        "code" : "1163075",
        "display" : "bortezomib Injectable Product"
      },
      {
        "code" : "1163087",
        "display" : "brentuximab vedotin Injectable Product"
      },
      {
        "code" : "1164873",
        "display" : "thalidomide Oral Product"
      },
      {
        "code" : "1164874",
        "display" : "thalidomide Pill"
      },
      {
        "code" : "1166941",
        "display" : "Dacogen Injectable Product"
      },
      {
        "code" : "1170611",
        "display" : "Adcetris Injectable Product"
      },
      {
        "code" : "1171230",
        "display" : "Gleevec Oral Product"
      },
      {
        "code" : "1171231",
        "display" : "Gleevec Pill"
      },
      {
        "code" : "1177781",
        "display" : "Sprycel Oral Product"
      },
      {
        "code" : "1177782",
        "display" : "Sprycel Pill"
      },
      {
        "code" : "1182522",
        "display" : "Revlimid Oral Product"
      },
      {
        "code" : "1182529",
        "display" : "Revlimid Pill"
      },
      {
        "code" : "1182862",
        "display" : "Nexavar Oral Product"
      },
      {
        "code" : "1182863",
        "display" : "Nexavar Pill"
      },
      {
        "code" : "1184929",
        "display" : "Thalomid Oral Product"
      },
      {
        "code" : "1184930",
        "display" : "Thalomid Pill"
      },
      {
        "code" : "1185345",
        "display" : "Rituxan Injectable Product"
      },
      {
        "code" : "1185474",
        "display" : "Sutent Oral Product"
      },
      {
        "code" : "1185475",
        "display" : "Sutent Pill"
      },
      {
        "code" : "1186581",
        "display" : "Vidaza Injectable Product"
      },
      {
        "code" : "1187756",
        "display" : "Velcade Injectable Product"
      },
      {
        "code" : "121191",
        "display" : "rituximab"
      },
      {
        "code" : "1242230",
        "display" : "lenalidomide 2.5 MG"
      },
      {
        "code" : "1242231",
        "display" : "lenalidomide 2.5 MG Oral Capsule"
      },
      {
        "code" : "1242232",
        "display" : "lenalidomide 2.5 MG [Revlimid]"
      },
      {
        "code" : "1242233",
        "display" : "lenalidomide 2.5 MG Oral Capsule [Revlimid]"
      },
      {
        "code" : "1251",
        "display" : "azacitidine"
      },
      {
        "code" : "1302966",
        "display" : "carfilzomib"
      },
      {
        "code" : "1302968",
        "display" : "carfilzomib Injectable Product"
      },
      {
        "code" : "1302971",
        "display" : "Kyprolis"
      },
      {
        "code" : "1302974",
        "display" : "Kyprolis Injectable Product"
      },
      {
        "code" : "1307619",
        "display" : "bosutinib"
      },
      {
        "code" : "1307620",
        "display" : "bosutinib 100 MG"
      },
      {
        "code" : "1307621",
        "display" : "bosutinib Oral Product"
      },
      {
        "code" : "1307622",
        "display" : "bosutinib Pill"
      },
      {
        "code" : "1307623",
        "display" : "bosutinib Oral Tablet"
      },
      {
        "code" : "1307624",
        "display" : "bosutinib 100 MG Oral Tablet"
      },
      {
        "code" : "1307625",
        "display" : "Bosulif"
      },
      {
        "code" : "1307626",
        "display" : "bosutinib 100 MG [Bosulif]"
      },
      {
        "code" : "1307627",
        "display" : "bosutinib Oral Tablet [Bosulif]"
      },
      {
        "code" : "1307628",
        "display" : "Bosulif Oral Product"
      },
      {
        "code" : "1307629",
        "display" : "Bosulif Pill"
      },
      {
        "code" : "1307630",
        "display" : "bosutinib 100 MG Oral Tablet [Bosulif]"
      },
      {
        "code" : "1307632",
        "display" : "bosutinib 500 MG"
      },
      {
        "code" : "1307633",
        "display" : "bosutinib 500 MG Oral Tablet"
      },
      {
        "code" : "1307634",
        "display" : "bosutinib 500 MG [Bosulif]"
      },
      {
        "code" : "1307635",
        "display" : "bosutinib 500 MG Oral Tablet [Bosulif]"
      },
      {
        "code" : "1314319",
        "display" : "bosutinib monohydrate"
      },
      {
        "code" : "1428946",
        "display" : "lenalidomide 20 MG"
      },
      {
        "code" : "1428947",
        "display" : "lenalidomide 20 MG Oral Capsule"
      },
      {
        "code" : "1429366",
        "display" : "lenalidomide 20 MG [Revlimid]"
      },
      {
        "code" : "1429367",
        "display" : "lenalidomide 20 MG Oral Capsule [Revlimid]"
      },
      {
        "code" : "1442690",
        "display" : "obinutuzumab 25 MG/ML"
      },
      {
        "code" : "1442691",
        "display" : "obinutuzumab Injectable Product"
      },
      {
        "code" : "1442693",
        "display" : "40 ML obinutuzumab 25 MG/ML Injection"
      },
      {
        "code" : "1442694",
        "display" : "Gazyva"
      },
      {
        "code" : "1442695",
        "display" : "obinutuzumab 25 MG/ML [Gazyva]"
      },
      {
        "code" : "1442697",
        "display" : "Gazyva Injectable Product"
      },
      {
        "code" : "1442698",
        "display" : "40 ML obinutuzumab 25 MG/ML Injection [Gazyva]"
      },
      {
        "code" : "1442981",
        "display" : "ibrutinib"
      },
      {
        "code" : "1442982",
        "display" : "ibrutinib 140 MG"
      },
      {
        "code" : "1442983",
        "display" : "ibrutinib Oral Product"
      },
      {
        "code" : "1442984",
        "display" : "ibrutinib Pill"
      },
      {
        "code" : "1442985",
        "display" : "ibrutinib Oral Capsule"
      },
      {
        "code" : "1442986",
        "display" : "ibrutinib 140 MG Oral Capsule"
      },
      {
        "code" : "1442987",
        "display" : "Imbruvica"
      },
      {
        "code" : "1442988",
        "display" : "ibrutinib 140 MG [Imbruvica]"
      },
      {
        "code" : "1442989",
        "display" : "ibrutinib Oral Capsule [Imbruvica]"
      },
      {
        "code" : "1442990",
        "display" : "Imbruvica Oral Product"
      },
      {
        "code" : "1442991",
        "display" : "Imbruvica Pill"
      },
      {
        "code" : "1442992",
        "display" : "ibrutinib 140 MG Oral Capsule [Imbruvica]"
      },
      {
        "code" : "1541889",
        "display" : "sunitinib 37.5 MG"
      },
      {
        "code" : "1541890",
        "display" : "sunitinib 37.5 MG Oral Capsule"
      },
      {
        "code" : "1541927",
        "display" : "sunitinib 37.5 MG [Sutent]"
      },
      {
        "code" : "1541928",
        "display" : "sunitinib 37.5 MG Oral Capsule [Sutent]"
      },
      {
        "code" : "1546019",
        "display" : "dasatinib anhydrous"
      },
      {
        "code" : "15657",
        "display" : "decitabine"
      },
      {
        "code" : "1597258",
        "display" : "blinatumomab"
      },
      {
        "code" : "1597260",
        "display" : "blinatumomab Injectable Product"
      },
      {
        "code" : "1597262",
        "display" : "blinatumomab 0.035 MG Injection"
      },
      {
        "code" : "1597263",
        "display" : "Blincyto"
      },
      {
        "code" : "1597266",
        "display" : "Blincyto Injectable Product"
      },
      {
        "code" : "1597267",
        "display" : "blinatumomab 0.035 MG Injection [Blincyto]"
      },
      {
        "code" : "1651249",
        "display" : "blinatumomab 0.035 MG"
      },
      {
        "code" : "1651250",
        "display" : "blinatumomab Injection"
      },
      {
        "code" : "1651252",
        "display" : "blinatumomab 0.035 MG [Blincyto]"
      },
      {
        "code" : "1651253",
        "display" : "blinatumomab Injection [Blincyto]"
      },
      {
        "code" : "1655961",
        "display" : "brentuximab vedotin 50 MG"
      },
      {
        "code" : "1655962",
        "display" : "brentuximab vedotin Injection"
      },
      {
        "code" : "1655964",
        "display" : "brentuximab vedotin 50 MG [Adcetris]"
      },
      {
        "code" : "1655965",
        "display" : "brentuximab vedotin Injection [Adcetris]"
      },
      {
        "code" : "1656294",
        "display" : "obinutuzumab Injection"
      },
      {
        "code" : "1656296",
        "display" : "obinutuzumab Injection [Gazyva]"
      },
      {
        "code" : "1657861",
        "display" : "rituximab Injection"
      },
      {
        "code" : "1657862",
        "display" : "10 ML rituximab 10 MG/ML Injection"
      },
      {
        "code" : "1657863",
        "display" : "rituximab Injection [Rituxan]"
      },
      {
        "code" : "1657864",
        "display" : "10 ML rituximab 10 MG/ML Injection [Rituxan]"
      },
      {
        "code" : "1657867",
        "display" : "50 ML rituximab 10 MG/ML Injection"
      },
      {
        "code" : "1657868",
        "display" : "50 ML rituximab 10 MG/ML Injection [Rituxan]"
      },
      {
        "code" : "1721947",
        "display" : "daratumumab"
      },
      {
        "code" : "1721948",
        "display" : "daratumumab 20 MG/ML"
      },
      {
        "code" : "1721949",
        "display" : "daratumumab Injectable Product"
      },
      {
        "code" : "1721950",
        "display" : "daratumumab Injection"
      },
      {
        "code" : "1721951",
        "display" : "5 ML daratumumab 20 MG/ML Injection"
      },
      {
        "code" : "1721952",
        "display" : "Darzalex"
      },
      {
        "code" : "1721953",
        "display" : "daratumumab 20 MG/ML [Darzalex]"
      },
      {
        "code" : "1721954",
        "display" : "daratumumab Injection [Darzalex]"
      },
      {
        "code" : "1721955",
        "display" : "Darzalex Injectable Product"
      },
      {
        "code" : "1721956",
        "display" : "5 ML daratumumab 20 MG/ML Injection [Darzalex]"
      },
      {
        "code" : "1723734",
        "display" : "ixazomib citrate"
      },
      {
        "code" : "1723735",
        "display" : "ixazomib"
      },
      {
        "code" : "1723753",
        "display" : "ixazomib 2.3 MG"
      },
      {
        "code" : "1723754",
        "display" : "ixazomib Oral Product"
      },
      {
        "code" : "1723755",
        "display" : "ixazomib Pill"
      },
      {
        "code" : "1723756",
        "display" : "ixazomib Oral Capsule"
      },
      {
        "code" : "1723757",
        "display" : "ixazomib 2.3 MG Oral Capsule"
      },
      {
        "code" : "1723758",
        "display" : "Ninlaro"
      },
      {
        "code" : "1723759",
        "display" : "ixazomib 2.3 MG [Ninlaro]"
      },
      {
        "code" : "1723760",
        "display" : "ixazomib Oral Capsule [Ninlaro]"
      },
      {
        "code" : "1723761",
        "display" : "Ninlaro Oral Product"
      },
      {
        "code" : "1723762",
        "display" : "Ninlaro Pill"
      },
      {
        "code" : "1723763",
        "display" : "ixazomib 2.3 MG Oral Capsule [Ninlaro]"
      },
      {
        "code" : "1723764",
        "display" : "ixazomib 3 MG"
      },
      {
        "code" : "1723765",
        "display" : "ixazomib 3 MG Oral Capsule"
      },
      {
        "code" : "1723766",
        "display" : "ixazomib 3 MG [Ninlaro]"
      },
      {
        "code" : "1723767",
        "display" : "ixazomib 3 MG Oral Capsule [Ninlaro]"
      },
      {
        "code" : "1723769",
        "display" : "ixazomib 4 MG"
      },
      {
        "code" : "1723770",
        "display" : "ixazomib 4 MG Oral Capsule"
      },
      {
        "code" : "1723771",
        "display" : "ixazomib 4 MG [Ninlaro]"
      },
      {
        "code" : "1723772",
        "display" : "ixazomib 4 MG Oral Capsule [Ninlaro]"
      },
      {
        "code" : "1726104",
        "display" : "elotuzumab"
      },
      {
        "code" : "1726107",
        "display" : "elotuzumab 300 MG"
      },
      {
        "code" : "1726108",
        "display" : "elotuzumab Injectable Product"
      },
      {
        "code" : "1726109",
        "display" : "elotuzumab Injection"
      },
      {
        "code" : "1726110",
        "display" : "elotuzumab 300 MG Injection"
      },
      {
        "code" : "1726111",
        "display" : "Empliciti"
      },
      {
        "code" : "1726112",
        "display" : "elotuzumab 300 MG [Empliciti]"
      },
      {
        "code" : "1726113",
        "display" : "elotuzumab Injection [Empliciti]"
      },
      {
        "code" : "1726114",
        "display" : "Empliciti Injectable Product"
      },
      {
        "code" : "1726115",
        "display" : "elotuzumab 300 MG Injection [Empliciti]"
      },
      {
        "code" : "1726116",
        "display" : "elotuzumab 400 MG"
      },
      {
        "code" : "1726117",
        "display" : "elotuzumab 400 MG Injection"
      },
      {
        "code" : "1726118",
        "display" : "elotuzumab 400 MG [Empliciti]"
      },
      {
        "code" : "1726119",
        "display" : "elotuzumab 400 MG Injection [Empliciti]"
      },
      {
        "code" : "1726439",
        "display" : "20 ML daratumumab 20 MG/ML Injection"
      },
      {
        "code" : "1726440",
        "display" : "20 ML daratumumab 20 MG/ML Injection [Darzalex]"
      },
      {
        "code" : "1726496",
        "display" : "azacitidine 100 MG"
      },
      {
        "code" : "1726497",
        "display" : "azacitidine Injection"
      },
      {
        "code" : "1726499",
        "display" : "azacitidine 100 MG [Vidaza]"
      },
      {
        "code" : "1726500",
        "display" : "azacitidine Injection [Vidaza]"
      },
      {
        "code" : "1804993",
        "display" : "bortezomib 3.5 MG"
      },
      {
        "code" : "1804994",
        "display" : "bortezomib Injection"
      },
      {
        "code" : "1804996",
        "display" : "bortezomib 3.5 MG [Velcade]"
      },
      {
        "code" : "1804997",
        "display" : "bortezomib Injection [Velcade]"
      },
      {
        "code" : "1806906",
        "display" : "decitabine 50 MG"
      },
      {
        "code" : "1806907",
        "display" : "decitabine Injection"
      },
      {
        "code" : "1806909",
        "display" : "decitabine 50 MG [Dacogen]"
      },
      {
        "code" : "1806910",
        "display" : "decitabine Injection [Dacogen]"
      },
      {
        "code" : "1806932",
        "display" : "carfilzomib 30 MG"
      },
      {
        "code" : "1806933",
        "display" : "carfilzomib Injection"
      },
      {
        "code" : "1806934",
        "display" : "carfilzomib 30 MG Injection"
      },
      {
        "code" : "1806935",
        "display" : "carfilzomib 30 MG [Kyprolis]"
      },
      {
        "code" : "1806936",
        "display" : "carfilzomib Injection [Kyprolis]"
      },
      {
        "code" : "1806937",
        "display" : "carfilzomib 30 MG Injection [Kyprolis]"
      },
      {
        "code" : "1806939",
        "display" : "carfilzomib 60 MG"
      },
      {
        "code" : "1806940",
        "display" : "carfilzomib 60 MG Injection"
      },
      {
        "code" : "1806941",
        "display" : "carfilzomib 60 MG [Kyprolis]"
      },
      {
        "code" : "1806942",
        "display" : "carfilzomib 60 MG Injection [Kyprolis]"
      },
      {
        "code" : "1919083",
        "display" : "midostaurin"
      },
      {
        "code" : "1919084",
        "display" : "midostaurin 25 MG"
      },
      {
        "code" : "1919085",
        "display" : "midostaurin Oral Product"
      },
      {
        "code" : "1919086",
        "display" : "midostaurin Pill"
      },
      {
        "code" : "1919087",
        "display" : "midostaurin Oral Capsule"
      },
      {
        "code" : "1919088",
        "display" : "midostaurin 25 MG Oral Capsule"
      },
      {
        "code" : "1919089",
        "display" : "Rydapt"
      },
      {
        "code" : "1919090",
        "display" : "midostaurin 25 MG [Rydapt]"
      },
      {
        "code" : "1919091",
        "display" : "midostaurin Oral Capsule [Rydapt]"
      },
      {
        "code" : "1919092",
        "display" : "Rydapt Oral Product"
      },
      {
        "code" : "1919093",
        "display" : "Rydapt Pill"
      },
      {
        "code" : "1919094",
        "display" : "midostaurin 25 MG Oral Capsule [Rydapt]"
      },
      {
        "code" : "1927881",
        "display" : "rituximab 120 MG/ML"
      },
      {
        "code" : "1927882",
        "display" : "hyaluronidase / rituximab Injectable Product"
      },
      {
        "code" : "1927883",
        "display" : "hyaluronidase / rituximab Injection"
      },
      {
        "code" : "1927884",
        "display" : "hyaluronidase / rituximab"
      },
      {
        "code" : "1927885",
        "display" : "11.7 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection"
      },
      {
        "code" : "1927886",
        "display" : "Rituxan Hycela"
      },
      {
        "code" : "1927887",
        "display" : "hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML [Rituxan Hycela]"
      },
      {
        "code" : "1927888",
        "display" : "hyaluronidase / rituximab Injection [Rituxan Hycela]"
      },
      {
        "code" : "1927889",
        "display" : "Rituxan Hycela Injectable Product"
      },
      {
        "code" : "1927890",
        "display" : "11.7 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection [Rituxan Hycela]"
      },
      {
        "code" : "1927893",
        "display" : "13.4 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection"
      },
      {
        "code" : "1927894",
        "display" : "13.4 ML hyaluronidase, human recombinant 2000 UNT/ML / rituximab 120 MG/ML Injection [Rituxan Hycela]"
      },
      {
        "code" : "1940331",
        "display" : "enasidenib mesylate"
      },
      {
        "code" : "1940332",
        "display" : "enasidenib"
      },
      {
        "code" : "1940334",
        "display" : "enasidenib Oral Product"
      },
      {
        "code" : "1940335",
        "display" : "enasidenib Pill"
      },
      {
        "code" : "1940336",
        "display" : "enasidenib Oral Tablet"
      },
      {
        "code" : "1940338",
        "display" : "Idhifa"
      },
      {
        "code" : "1940340",
        "display" : "enasidenib Oral Tablet [Idhifa]"
      },
      {
        "code" : "1940341",
        "display" : "Idhifa Oral Product"
      },
      {
        "code" : "1940342",
        "display" : "Idhifa Pill"
      },
      {
        "code" : "1940369",
        "display" : "enasidenib 100 MG"
      },
      {
        "code" : "1940370",
        "display" : "enasidenib 100 MG Oral Tablet"
      },
      {
        "code" : "1940371",
        "display" : "enasidenib 100 MG [Idhifa]"
      },
      {
        "code" : "1940372",
        "display" : "enasidenib 100 MG Oral Tablet [Idhifa]"
      },
      {
        "code" : "1940373",
        "display" : "enasidenib 50 MG"
      },
      {
        "code" : "1940374",
        "display" : "enasidenib 50 MG Oral Tablet"
      },
      {
        "code" : "1940375",
        "display" : "enasidenib 50 MG [Idhifa]"
      },
      {
        "code" : "1940376",
        "display" : "enasidenib 50 MG Oral Tablet [Idhifa]"
      },
      {
        "code" : "1987732",
        "display" : "bosutinib 400 MG Oral Tablet"
      },
      {
        "code" : "1987734",
        "display" : "bosutinib 400 MG Oral Tablet [Bosulif]"
      },
      {
        "code" : "1988983",
        "display" : "bosutinib 400 MG"
      },
      {
        "code" : "1988985",
        "display" : "bosutinib 400 MG [Bosulif]"
      },
      {
        "code" : "1994359",
        "display" : "ibrutinib 70 MG"
      },
      {
        "code" : "1994360",
        "display" : "ibrutinib 70 MG Oral Capsule"
      },
      {
        "code" : "1994361",
        "display" : "ibrutinib 70 MG [Imbruvica]"
      },
      {
        "code" : "1994362",
        "display" : "ibrutinib 70 MG Oral Capsule [Imbruvica]"
      },
      {
        "code" : "2000016",
        "display" : "ibrutinib Oral Tablet"
      },
      {
        "code" : "2000017",
        "display" : "ibrutinib 140 MG Oral Tablet"
      },
      {
        "code" : "2000018",
        "display" : "ibrutinib Oral Tablet [Imbruvica]"
      },
      {
        "code" : "2000019",
        "display" : "ibrutinib 140 MG Oral Tablet [Imbruvica]"
      },
      {
        "code" : "2000020",
        "display" : "ibrutinib 280 MG"
      },
      {
        "code" : "2000021",
        "display" : "ibrutinib 280 MG Oral Tablet"
      },
      {
        "code" : "2000022",
        "display" : "ibrutinib 280 MG [Imbruvica]"
      },
      {
        "code" : "2000023",
        "display" : "ibrutinib 280 MG Oral Tablet [Imbruvica]"
      },
      {
        "code" : "2000024",
        "display" : "ibrutinib 420 MG"
      },
      {
        "code" : "2000025",
        "display" : "ibrutinib 420 MG Oral Tablet"
      },
      {
        "code" : "2000026",
        "display" : "ibrutinib 420 MG [Imbruvica]"
      },
      {
        "code" : "2000027",
        "display" : "ibrutinib 420 MG Oral Tablet [Imbruvica]"
      },
      {
        "code" : "2000028",
        "display" : "ibrutinib 560 MG"
      },
      {
        "code" : "2000029",
        "display" : "ibrutinib 560 MG Oral Tablet"
      },
      {
        "code" : "2000030",
        "display" : "ibrutinib 560 MG [Imbruvica]"
      },
      {
        "code" : "2000031",
        "display" : "ibrutinib 560 MG Oral Tablet [Imbruvica]"
      },
      {
        "code" : "200390",
        "display" : "thalidomide 50 MG Oral Capsule"
      },
      {
        "code" : "2046641",
        "display" : "carfilzomib 10 MG"
      },
      {
        "code" : "2046642",
        "display" : "carfilzomib 10 MG Injection"
      },
      {
        "code" : "2046643",
        "display" : "carfilzomib 10 MG [Kyprolis]"
      },
      {
        "code" : "2046644",
        "display" : "carfilzomib 10 MG Injection [Kyprolis]"
      },
      {
        "code" : "2049873",
        "display" : "ivosidenib"
      },
      {
        "code" : "2049874",
        "display" : "ivosidenib 250 MG"
      },
      {
        "code" : "2049875",
        "display" : "ivosidenib Oral Product"
      },
      {
        "code" : "2049876",
        "display" : "ivosidenib Pill"
      },
      {
        "code" : "2049877",
        "display" : "ivosidenib Oral Tablet"
      },
      {
        "code" : "2049878",
        "display" : "ivosidenib 250 MG Oral Tablet"
      },
      {
        "code" : "2049879",
        "display" : "Tibsovo"
      },
      {
        "code" : "2049880",
        "display" : "ivosidenib 250 MG [Tibsovo]"
      },
      {
        "code" : "2049881",
        "display" : "ivosidenib Oral Tablet [Tibsovo]"
      },
      {
        "code" : "2049882",
        "display" : "Tibsovo Oral Product"
      },
      {
        "code" : "2049883",
        "display" : "Tibsovo Pill"
      },
      {
        "code" : "2049884",
        "display" : "ivosidenib 250 MG Oral Tablet [Tibsovo]"
      },
      {
        "code" : "2105806",
        "display" : "gilteritinib"
      },
      {
        "code" : "2105807",
        "display" : "gilteritinib 40 MG"
      },
      {
        "code" : "2105808",
        "display" : "gilteritinib Oral Product"
      },
      {
        "code" : "2105809",
        "display" : "gilteritinib Pill"
      },
      {
        "code" : "2105810",
        "display" : "gilteritinib Oral Tablet"
      },
      {
        "code" : "2105811",
        "display" : "gilteritinib 40 MG Oral Tablet"
      },
      {
        "code" : "2105812",
        "display" : "Xospata"
      },
      {
        "code" : "2105813",
        "display" : "gilteritinib 40 MG [Xospata]"
      },
      {
        "code" : "2105814",
        "display" : "gilteritinib Oral Tablet [Xospata]"
      },
      {
        "code" : "2105815",
        "display" : "Xospata Oral Product"
      },
      {
        "code" : "2105816",
        "display" : "Xospata Pill"
      },
      {
        "code" : "2105817",
        "display" : "gilteritinib 40 MG Oral Tablet [Xospata]"
      },
      {
        "code" : "2105823",
        "display" : "gilteritinib fumarate"
      },
      {
        "code" : "2105824",
        "display" : "rituximab-abbs"
      },
      {
        "code" : "2105825",
        "display" : "rituximab-abbs 10 MG/ML"
      },
      {
        "code" : "2105826",
        "display" : "10 ML rituximab-abbs 10 MG/ML Injection"
      },
      {
        "code" : "2105827",
        "display" : "Truxima"
      },
      {
        "code" : "2105828",
        "display" : "rituximab-abbs 10 MG/ML [Truxima]"
      },
      {
        "code" : "2105829",
        "display" : "rituximab Injection [Truxima]"
      },
      {
        "code" : "2105830",
        "display" : "Truxima Injectable Product"
      },
      {
        "code" : "2105831",
        "display" : "10 ML rituximab-abbs 10 MG/ML Injection [Truxima]"
      },
      {
        "code" : "2105834",
        "display" : "50 ML rituximab-abbs 10 MG/ML Injection"
      },
      {
        "code" : "2105835",
        "display" : "50 ML rituximab-abbs 10 MG/ML Injection [Truxima]"
      },
      {
        "code" : "213360",
        "display" : "thalidomide 50 MG Oral Capsule [Thalomid]"
      },
      {
        "code" : "220239",
        "display" : "Thalomid"
      },
      {
        "code" : "226754",
        "display" : "Rituxan"
      },
      {
        "code" : "2273510",
        "display" : "rituximab-pvvr"
      },
      {
        "code" : "2273511",
        "display" : "rituximab-pvvr 10 MG/ML"
      },
      {
        "code" : "2273512",
        "display" : "10 ML rituximab-pvvr 10 MG/ML Injection"
      },
      {
        "code" : "2273513",
        "display" : "Ruxience"
      },
      {
        "code" : "2273514",
        "display" : "rituximab-pvvr 10 MG/ML [Ruxience]"
      },
      {
        "code" : "2273515",
        "display" : "rituximab Injection [Ruxience]"
      },
      {
        "code" : "2273516",
        "display" : "Ruxience Injectable Product"
      },
      {
        "code" : "2273517",
        "display" : "10 ML rituximab-pvvr 10 MG/ML Injection [Ruxience]"
      },
      {
        "code" : "2273520",
        "display" : "50 ML rituximab-pvvr 10 MG/ML Injection"
      },
      {
        "code" : "2273521",
        "display" : "50 ML rituximab-pvvr 10 MG/ML Injection [Ruxience]"
      },
      {
        "code" : "2372199",
        "display" : "daratumumab / hyaluronidase"
      },
      {
        "code" : "2375130",
        "display" : "daratumumab-fihj"
      },
      {
        "code" : "2375131",
        "display" : "daratumumab-fihj 120 MG/ML"
      },
      {
        "code" : "2375134",
        "display" : "daratumumab / hyaluronidase Injectable Product"
      },
      {
        "code" : "2375135",
        "display" : "daratumumab / hyaluronidase Injection"
      },
      {
        "code" : "2375136",
        "display" : "15 ML daratumumab-fihj 120 MG/ML / hyaluronidase-fihj 2000 UNT/ML Injection"
      },
      {
        "code" : "2375137",
        "display" : "Darzalex Faspro"
      },
      {
        "code" : "2375138",
        "display" : "daratumumab-fihj 120 MG/ML / hyaluronidase-fihj 2000 UNT/ML [Darzalex Faspro]"
      },
      {
        "code" : "2375139",
        "display" : "daratumumab / hyaluronidase Injection [Darzalex Faspro]"
      },
      {
        "code" : "2375140",
        "display" : "Darzalex Faspro Injectable Product"
      },
      {
        "code" : "2375141",
        "display" : "15 ML daratumumab-fihj 120 MG/ML / hyaluronidase-fihj 2000 UNT/ML Injection [Darzalex Faspro]"
      },
      {
        "code" : "2384452",
        "display" : "decitabine 35 MG"
      },
      {
        "code" : "2384453",
        "display" : "cedazuridine / decitabine Oral Product"
      },
      {
        "code" : "2384454",
        "display" : "cedazuridine / decitabine Pill"
      },
      {
        "code" : "2384455",
        "display" : "cedazuridine / decitabine Oral Tablet"
      },
      {
        "code" : "2384456",
        "display" : "cedazuridine / decitabine"
      },
      {
        "code" : "2384457",
        "display" : "cedazuridine 100 MG / decitabine 35 MG Oral Tablet"
      },
      {
        "code" : "2384458",
        "display" : "{5 (cedazuridine 100 MG / decitabine 35 MG Oral Tablet) } Pack"
      },
      {
        "code" : "2384459",
        "display" : "Inqovi"
      },
      {
        "code" : "2384460",
        "display" : "cedazuridine 100 MG / decitabine 35 MG [Inqovi]"
      },
      {
        "code" : "2384461",
        "display" : "cedazuridine / decitabine Oral Tablet [Inqovi]"
      },
      {
        "code" : "2384462",
        "display" : "Inqovi Oral Product"
      },
      {
        "code" : "2384463",
        "display" : "Inqovi Pill"
      },
      {
        "code" : "2384464",
        "display" : "cedazuridine 100 MG / decitabine 35 MG Oral Tablet [Inqovi]"
      },
      {
        "code" : "2384465",
        "display" : "{5 (cedazuridine 100 MG / decitabine 35 MG Oral Tablet [Inqovi]) } Pack [Inqovi 5 Tablet Pack]"
      },
      {
        "code" : "2396760",
        "display" : "azacitidine 200 MG"
      },
      {
        "code" : "2396761",
        "display" : "azacitidine Oral Product"
      },
      {
        "code" : "2396762",
        "display" : "azacitidine Pill"
      },
      {
        "code" : "2396763",
        "display" : "azacitidine Oral Tablet"
      },
      {
        "code" : "2396764",
        "display" : "azacitidine 200 MG Oral Tablet"
      },
      {
        "code" : "2396765",
        "display" : "Onureg"
      },
      {
        "code" : "2396766",
        "display" : "azacitidine 200 MG [Onureg]"
      },
      {
        "code" : "2396767",
        "display" : "azacitidine Oral Tablet [Onureg]"
      },
      {
        "code" : "2396768",
        "display" : "Onureg Oral Product"
      },
      {
        "code" : "2396769",
        "display" : "Onureg Pill"
      },
      {
        "code" : "2396770",
        "display" : "azacitidine 200 MG Oral Tablet [Onureg]"
      },
      {
        "code" : "2396771",
        "display" : "azacitidine 300 MG"
      },
      {
        "code" : "2396772",
        "display" : "azacitidine 300 MG Oral Tablet"
      },
      {
        "code" : "2396773",
        "display" : "azacitidine 300 MG [Onureg]"
      },
      {
        "code" : "2396774",
        "display" : "azacitidine 300 MG Oral Tablet [Onureg]"
      },
      {
        "code" : "2472325",
        "display" : "rituximab-arrx"
      },
      {
        "code" : "2472326",
        "display" : "rituximab-arrx 10 MG/ML"
      },
      {
        "code" : "2472327",
        "display" : "10 ML rituximab-arrx 10 MG/ML Injection"
      },
      {
        "code" : "2472328",
        "display" : "Riabni"
      },
      {
        "code" : "2472329",
        "display" : "rituximab-arrx 10 MG/ML [Riabni]"
      },
      {
        "code" : "2472330",
        "display" : "rituximab Injection [Riabni]"
      },
      {
        "code" : "2472331",
        "display" : "Riabni Injectable Product"
      },
      {
        "code" : "2472332",
        "display" : "10 ML rituximab-arrx 10 MG/ML Injection [Riabni]"
      },
      {
        "code" : "2472335",
        "display" : "50 ML rituximab-arrx 10 MG/ML Injection"
      },
      {
        "code" : "2472336",
        "display" : "50 ML rituximab-arrx 10 MG/ML Injection [Riabni]"
      },
      {
        "code" : "2595242",
        "display" : "pacritinib citrate"
      },
      {
        "code" : "2595243",
        "display" : "pacritinib"
      },
      {
        "code" : "2595244",
        "display" : "pacritinib 100 MG"
      },
      {
        "code" : "2595245",
        "display" : "pacritinib Oral Product"
      },
      {
        "code" : "2595246",
        "display" : "pacritinib Pill"
      },
      {
        "code" : "2595247",
        "display" : "pacritinib Oral Capsule"
      },
      {
        "code" : "2595248",
        "display" : "pacritinib 100 MG Oral Capsule"
      },
      {
        "code" : "2595249",
        "display" : "Vonjo"
      },
      {
        "code" : "2595250",
        "display" : "pacritinib 100 MG [Vonjo]"
      },
      {
        "code" : "2595251",
        "display" : "Vonjo Oral Product"
      },
      {
        "code" : "2595252",
        "display" : "Vonjo Pill"
      },
      {
        "code" : "2595253",
        "display" : "pacritinib Oral Capsule [Vonjo]"
      },
      {
        "code" : "2595254",
        "display" : "pacritinib 100 MG Oral Capsule [Vonjo]"
      },
      {
        "code" : "2601541",
        "display" : "bortezomib 1 MG"
      },
      {
        "code" : "2601542",
        "display" : "bortezomib 1 MG Injection"
      },
      {
        "code" : "2601543",
        "display" : "bortezomib 2.5 MG"
      },
      {
        "code" : "2601544",
        "display" : "bortezomib 2.5 MG Injection"
      },
      {
        "code" : "282386",
        "display" : "Gleevec"
      },
      {
        "code" : "282388",
        "display" : "imatinib"
      },
      {
        "code" : "284206",
        "display" : "imatinib 100 MG Oral Capsule"
      },
      {
        "code" : "316648",
        "display" : "rituximab 10 MG/ML"
      },
      {
        "code" : "316784",
        "display" : "thalidomide 50 MG"
      },
      {
        "code" : "331600",
        "display" : "imatinib 100 MG"
      },
      {
        "code" : "337535",
        "display" : "Revlimid"
      },
      {
        "code" : "342369",
        "display" : "lenalidomide"
      },
      {
        "code" : "356733",
        "display" : "Velcade"
      },
      {
        "code" : "357977",
        "display" : "sunitinib"
      },
      {
        "code" : "358258",
        "display" : "bortezomib"
      },
      {
        "code" : "360176",
        "display" : "thalidomide 100 MG Oral Capsule"
      },
      {
        "code" : "360177",
        "display" : "thalidomide 200 MG Oral Capsule"
      },
      {
        "code" : "360321",
        "display" : "thalidomide 100 MG"
      },
      {
        "code" : "360322",
        "display" : "thalidomide 200 MG"
      },
      {
        "code" : "366451",
        "display" : "thalidomide Oral Capsule [Thalomid]"
      },
      {
        "code" : "374072",
        "display" : "thalidomide Oral Capsule"
      },
      {
        "code" : "376335",
        "display" : "imatinib Oral Capsule"
      },
      {
        "code" : "402243",
        "display" : "bortezomib 3.5 MG Injection"
      },
      {
        "code" : "402244",
        "display" : "bortezomib 3.5 MG Injection [Velcade]"
      },
      {
        "code" : "403878",
        "display" : "imatinib 100 MG Oral Tablet"
      },
      {
        "code" : "403879",
        "display" : "imatinib 400 MG Oral Tablet"
      },
      {
        "code" : "404449",
        "display" : "thalidomide 100 MG Oral Capsule [Thalomid]"
      },
      {
        "code" : "404450",
        "display" : "thalidomide 200 MG Oral Capsule [Thalomid]"
      },
      {
        "code" : "404588",
        "display" : "imatinib 100 MG Oral Tablet [Gleevec]"
      },
      {
        "code" : "404589",
        "display" : "imatinib 400 MG Oral Tablet [Gleevec]"
      },
      {
        "code" : "406050",
        "display" : "imatinib Oral Tablet"
      },
      {
        "code" : "406051",
        "display" : "imatinib 400 MG"
      },
      {
        "code" : "406060",
        "display" : "imatinib Oral Tablet [Gleevec]"
      },
      {
        "code" : "411240",
        "display" : "imatinib 50 MG Oral Capsule"
      },
      {
        "code" : "440549",
        "display" : "imatinib 50 MG"
      },
      {
        "code" : "475342",
        "display" : "dasatinib"
      },
      {
        "code" : "483431",
        "display" : "imatinib 400 MG Oral Capsule"
      },
      {
        "code" : "485246",
        "display" : "azacitidine 100 MG Injection"
      },
      {
        "code" : "495881",
        "display" : "sorafenib"
      },
      {
        "code" : "545203",
        "display" : "Vidaza"
      },
      {
        "code" : "545206",
        "display" : "azacitidine 100 MG Injection [Vidaza]"
      },
      {
        "code" : "573051",
        "display" : "rituximab 10 MG/ML [Rituxan]"
      },
      {
        "code" : "573254",
        "display" : "thalidomide 50 MG [Thalomid]"
      },
      {
        "code" : "575017",
        "display" : "imatinib 100 MG [Gleevec]"
      },
      {
        "code" : "576406",
        "display" : "thalidomide 100 MG [Thalomid]"
      },
      {
        "code" : "576407",
        "display" : "thalidomide 200 MG [Thalomid]"
      },
      {
        "code" : "576514",
        "display" : "imatinib 400 MG [Gleevec]"
      },
      {
        "code" : "597744",
        "display" : "sorafenib tosylate"
      },
      {
        "code" : "597745",
        "display" : "sorafenib 200 MG"
      },
      {
        "code" : "597746",
        "display" : "sorafenib Oral Tablet"
      },
      {
        "code" : "597747",
        "display" : "sorafenib 200 MG Oral Tablet"
      },
      {
        "code" : "602908",
        "display" : "lenalidomide 10 MG"
      },
      {
        "code" : "602909",
        "display" : "lenalidomide Oral Capsule"
      },
      {
        "code" : "602910",
        "display" : "lenalidomide 10 MG Oral Capsule"
      },
      {
        "code" : "602911",
        "display" : "lenalidomide 5 MG"
      },
      {
        "code" : "602912",
        "display" : "lenalidomide 5 MG Oral Capsule"
      },
      {
        "code" : "615977",
        "display" : "sorafenib 200 MG [Nexavar]"
      },
      {
        "code" : "615978",
        "display" : "sorafenib Oral Tablet [Nexavar]"
      },
      {
        "code" : "615979",
        "display" : "sorafenib 200 MG Oral Tablet [Nexavar]"
      },
      {
        "code" : "616112",
        "display" : "lenalidomide 10 MG [Revlimid]"
      },
      {
        "code" : "616113",
        "display" : "lenalidomide Oral Capsule [Revlimid]"
      },
      {
        "code" : "616114",
        "display" : "lenalidomide 10 MG Oral Capsule [Revlimid]"
      },
      {
        "code" : "616115",
        "display" : "lenalidomide 5 MG [Revlimid]"
      },
      {
        "code" : "616116",
        "display" : "lenalidomide 5 MG Oral Capsule [Revlimid]"
      },
      {
        "code" : "616274",
        "display" : "Sutent"
      },
      {
        "code" : "616275",
        "display" : "sunitinib malate"
      },
      {
        "code" : "616277",
        "display" : "sunitinib 12.5 MG"
      },
      {
        "code" : "616278",
        "display" : "sunitinib Oral Capsule"
      },
      {
        "code" : "616279",
        "display" : "sunitinib 12.5 MG Oral Capsule"
      },
      {
        "code" : "616281",
        "display" : "sunitinib 12.5 MG [Sutent]"
      },
      {
        "code" : "616282",
        "display" : "sunitinib Oral Capsule [Sutent]"
      },
      {
        "code" : "616283",
        "display" : "sunitinib 12.5 MG Oral Capsule [Sutent]"
      },
      {
        "code" : "616284",
        "display" : "sunitinib 25 MG"
      },
      {
        "code" : "616285",
        "display" : "sunitinib 25 MG Oral Capsule"
      },
      {
        "code" : "616286",
        "display" : "sunitinib 25 MG [Sutent]"
      },
      {
        "code" : "616287",
        "display" : "sunitinib 25 MG Oral Capsule [Sutent]"
      },
      {
        "code" : "616288",
        "display" : "sunitinib 50 MG"
      },
      {
        "code" : "616289",
        "display" : "sunitinib 50 MG Oral Capsule"
      },
      {
        "code" : "616291",
        "display" : "sunitinib 50 MG [Sutent]"
      },
      {
        "code" : "616292",
        "display" : "sunitinib 50 MG Oral Capsule [Sutent]"
      },
      {
        "code" : "619985",
        "display" : "Nexavar"
      },
      {
        "code" : "636242",
        "display" : "Dacogen"
      },
      {
        "code" : "636631",
        "display" : "decitabine 50 MG Injection"
      },
      {
        "code" : "643103",
        "display" : "dasatinib 20 MG"
      },
      {
        "code" : "643104",
        "display" : "dasatinib Oral Tablet"
      },
      {
        "code" : "643105",
        "display" : "dasatinib 20 MG Oral Tablet"
      },
      {
        "code" : "643106",
        "display" : "dasatinib 50 MG"
      },
      {
        "code" : "643107",
        "display" : "dasatinib 50 MG Oral Tablet"
      },
      {
        "code" : "643108",
        "display" : "dasatinib 70 MG"
      },
      {
        "code" : "643109",
        "display" : "dasatinib 70 MG Oral Tablet"
      },
      {
        "code" : "643170",
        "display" : "Sprycel"
      },
      {
        "code" : "643171",
        "display" : "dasatinib 20 MG [Sprycel]"
      },
      {
        "code" : "643172",
        "display" : "dasatinib Oral Tablet [Sprycel]"
      },
      {
        "code" : "643173",
        "display" : "dasatinib 20 MG Oral Tablet [Sprycel]"
      },
      {
        "code" : "643174",
        "display" : "dasatinib 50 MG [Sprycel]"
      },
      {
        "code" : "643175",
        "display" : "dasatinib 50 MG Oral Tablet [Sprycel]"
      },
      {
        "code" : "643176",
        "display" : "dasatinib 70 MG [Sprycel]"
      },
      {
        "code" : "643177",
        "display" : "dasatinib 70 MG Oral Tablet [Sprycel]"
      },
      {
        "code" : "643711",
        "display" : "lenalidomide 15 MG"
      },
      {
        "code" : "643712",
        "display" : "lenalidomide 15 MG Oral Capsule"
      },
      {
        "code" : "643713",
        "display" : "lenalidomide 15 MG [Revlimid]"
      },
      {
        "code" : "643714",
        "display" : "lenalidomide 15 MG Oral Capsule [Revlimid]"
      },
      {
        "code" : "643719",
        "display" : "lenalidomide 25 MG"
      },
      {
        "code" : "643720",
        "display" : "lenalidomide 25 MG Oral Capsule"
      },
      {
        "code" : "643721",
        "display" : "lenalidomide 25 MG [Revlimid]"
      },
      {
        "code" : "643722",
        "display" : "lenalidomide 25 MG Oral Capsule [Revlimid]"
      },
      {
        "code" : "644989",
        "display" : "decitabine 50 MG Injection [Dacogen]"
      },
      {
        "code" : "700415",
        "display" : "thalidomide 150 MG"
      },
      {
        "code" : "700416",
        "display" : "thalidomide 150 MG Oral Capsule"
      },
      {
        "code" : "700417",
        "display" : "thalidomide 150 MG [Thalomid]"
      },
      {
        "code" : "700418",
        "display" : "thalidomide 150 MG Oral Capsule [Thalomid]"
      },
      {
        "code" : "799046",
        "display" : "dasatinib 100 MG"
      },
      {
        "code" : "799047",
        "display" : "dasatinib 100 MG Oral Tablet"
      },
      {
        "code" : "799829",
        "display" : "dasatinib 100 MG [Sprycel]"
      },
      {
        "code" : "799830",
        "display" : "dasatinib 100 MG Oral Tablet [Sprycel]"
      },
      {
        "code" : "974779",
        "display" : "obinutuzumab"
      }]
    }]
  }
}

```
