# CIBMTR Vital Signs Value Set - CIBMTR Reporting Implementation Guide v0.1.12

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CIBMTR Vital Signs Value Set**

## ValueSet: CIBMTR Vital Signs Value Set 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/vital-signs | *Version*:0.1.12 |
| Draft as of 2026-10-01 | *Computable Name*:VitalSigns |

 
CIBMTR Vital Signs Value Set 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "vital-signs",
  "url" : "http://fhir.nmdp.org/ig/cibmtr-reporting/ValueSet/vital-signs",
  "version" : "0.1.12",
  "name" : "VitalSigns",
  "title" : "CIBMTR Vital Signs Value Set",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-10-01T20:34:29+00:00",
  "publisher" : "The Medical College of Wisconsin, Inc. and NMDP",
  "contact" : [{
    "name" : "The Medical College of Wisconsin, Inc. and NMDP",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.cibmtr.org"
    }]
  },
  {
    "name" : "Bob Milius",
    "telecom" : [{
      "system" : "email",
      "value" : "bmilius@nmdp.org"
    }]
  }],
  "description" : "CIBMTR Vital Signs Value Set",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "29463-7",
        "display" : "Body weight Patient Mass Pt Qn"
      },
      {
        "code" : "8302-2",
        "display" : "Body height Patient Len Pt Qn"
      }]
    }]
  }
}

```
